# Orchestration and internal roles

These are **logical roles**. Do not claim to have launched separate agents if multi-agent tools aren't available.

| Role | Input | Output | Acceptance gate |
|---|---|---|---|
| Director / Orchestrator | user request | brief, mode, capability matrix | mode chosen deterministically |
| Historical researcher | topic and official archives | source-log, claim ledger, timeline | each consequential claim has corroboration or uncertainty flag |
| Arabic writer | verified claims | narrated script, beats, hook | natural Arabic, no uncited fact inserted |
| Cartographer | time-specific geography + claims | GeoJSON/coordinates, map sequence | historical boundaries separate from present-day boundaries |
| Visual director | storyboard + styles | shot plan, transition plan | designs match style references; all graphics editable |
| Asset hunter | topic, script, asset-sources list | found pictures, icons and clips, registered in the manifest | wow-rule minimums met; each picture shows what it is used for |
| Free compositor | free assets + storyboard | Remotion project and render logs | verified dependency/license + playback review |
| Higgs producer | shot list + Higgsfield tools | generated pictures, clips, voice, music, effects | free generation for impact; keyframes shown before video; talking clips use their own audio |
| Arabic typesetter | narration | properly shaped RTL captions | timing / spelling / crop checks |
| Audio director (FREE) | Arabic narration + scene beats | optional Edge TTS MP3/SRT, original coded WAV score, FFmpeg ducked mix | network/rights checked, actual audio file and unclipped levels |
| QA auditor | all output and rendered frames | pass/fail report | provenance, safe areas, exports, no invented success |

### Human review points

1. Resolve material conflicts or gaps in historical claims before scripting.
2. In the HIGGS route no cost approval is needed; show keyframes and the video prompt before generating video.
3. Check each found picture shows what the narration claims.
4. Inspect render/captions and ensure illustrative footage is labeled where appropriate.

Use `schemas/` and `templates/` as stable interfaces between roles. Preserve `claim_ids`, `asset_ids` and `shot_ids` across revisions.
