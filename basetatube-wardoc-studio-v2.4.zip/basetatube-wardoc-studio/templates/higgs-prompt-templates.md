# Higgsfield prompt templates (HIGGS route)

Fill the brackets from the approved shot plan. These prompts make **atmosphere and cutaways only**. Maps, dates, place names and captions are added later in Remotion, so no prompt here asks for readable text or geography.

Model facts below were read from the live catalog on 2026-11-12. Re-check them before generating; the catalog can change.

## Order of work

1. Generate freely: there is no cost estimate or approval step in this route.
2. For video, make the **keyframe still** first with `gpt_image_2_6`, show it with the final video prompt, and get the user's go-ahead.
3. Generate video from the approved stills; one test shot first, then the rest.

## 1. Keyframe still — `gpt_image_2_6`

Settings: aspect ratio from the brief (16:9 / 9:16 / 1:1), resolution 2k, output png.

```
[Subject and action in one sentence: who or what, doing what, where].
Setting: [terrain, weather, time of day, period-correct equipment and clothing for YEAR, described generically].
Camera: [wide establishing | medium | low angle], [lens feel], [depth of field].
Light and palette: [e.g. low dusty sunlight, desaturated ochre and steel blue].
Style: cinematic documentary still, photographic realism, natural film grain.
Leave the [lower third | right third] calm and uncluttered for captions added later.
No text, no letters, no numbers, no maps, no flags or insignia with readable detail, no logos, no watermarks.
No identifiable real person. No graphic injury.
```

For a second shot in the same scene, attach the first approved still as a reference and start the prompt with: `Same location, lighting and colour grade as @Image1.`

## 2. Image-to-video from an approved keyframe — `wan3_0_prime` (fallback `wan3_0`)

Settings: resolution 720p; attach the approved still as `start_image`; aspect ratio matching the still; duration 4–6 s per cut (allowed 2–30 s); `generate_audio: false` because narration and music are added in Remotion.

`start_image` cannot be combined with reference images in the same job. Use either this template or template 3 for a shot, not both.

```
Start exactly from the provided first frame and keep its composition, subject and colour grade.
Motion: [one clear motion, e.g. dust drifting left to right, column of vehicles rolling slowly forward].
Camera: [slow push in | slow lateral drift | locked off], steady, no cuts.
Pace: slow and documentary, [N] seconds, one continuous shot.
Nothing new enters the frame. No text, captions, maps, numbers or logos appear at any point.
```

## 3. Reference-driven video (consistent presenter or prop) — `wan3_0_prime`

Settings: attach up to 10 images as `image_references` and name each one in the prompt by its order.

```
@Image1 is the presenter: keep the same face, hair, clothing and build in every frame.
@Image2 is the setting: [plain green screen | studio wall | desert backdrop].
The presenter [stands waist-up facing camera | turns and gestures to the right], [calm, explaining expression].
Camera: locked off, waist-up framing, even soft light, no colour spill on hair or shoulders.
[N] seconds, one continuous shot. No text, no captions, no logos.
```

Use a real person's photo only when the user supplied it and authorised that use.

## 4. When a reference image already contains Arabic text

Avoid this where possible: text belongs in Remotion. If an approved reference unavoidably contains Arabic lettering (for example the user's own title card), name the image and freeze the text explicitly:

```
@Image1 is the title card. All Arabic text in @Image1 remains PERFECTLY FROZEN: same letters, same shapes, same position, no redrawing, no morphing, no new characters.
Only [the background light | the dust | the camera] moves: [describe motion].
```

Inspect every frame of the result. If any letter changed, discard the clip and composite the text in Remotion instead.

## 5. Presenter GIF loop — `gpt_image_2_6`

Settings: output_format gif, transparent background if offered; check live frame count and frame duration controls.

```
Short seamless loop of the presenter from @Image1, waist-up, facing camera: [blink, small nod, hand gesture to the right].
Same face, clothing and lighting as @Image1 in every frame. Plain transparent background, no border, no text.
```

## 6. Voice — `elevenlabs_v4`

The user picks the voice first. Generate a one-sentence sample with each candidate voice, let them choose, then generate the narration shot by shot (one audio file per talking shot makes lip sync and re-takes cheap) or as one file for voice-over only.

- Text: the approved Egyptian Arabic script, exactly as written; numbers and names spelled the way they must be pronounced.
- Keep each request within the model's text limit (10,000 characters in the 2026-11-12 catalog).
- Save as `audio/narration.mp3` (or `audio/lines/S-00X.mp3` per shot) and record voice id, text and job id in the queue.

## 7. Talking character — `wan3_0_prime` / `wan3_0` or `minimax_h3_max`, with picture and voice references

Settings: resolution 720p; `image_references`: the character picture; `audio_references`: the generated voice line for this shot; duration = length of that line (2 to 30 s). No `start_image` in the same job.

```
@Image1 is the character: keep exactly the same design, colours and proportions in every frame.
The character says in Egyptian Arabic, exactly these words: «[اكتب الجملة هنا بالعربي حرفيًا كما في السكريبت والملف الصوتي]»
The voice is @Audio1: mouth movement follows @Audio1 precisely, with natural blinks and small gestures that fit the tone.
Framing: [waist-up, centred | lower-left third], camera locked off, [plain green screen | simple studio backdrop].
One continuous shot. No text, no captions, no logos.
```

The Arabic line between «» is mandatory: write it in Arabic script, word for word, never transliterated or summarised in English.

Watch the result with sound before using it. If the lips drift, shorten the line and regenerate; in the edit this clip's own audio is played for its shot (put it in `assets/presenter/talk/<shot_id>.webm`).

## 8. Supporting clip — `wan3_0_prime`

For cutaways and establishing shots that carry no facts. Use template 2 (from an approved still) or text only:

```
[One continuous atmospheric shot: place, weather, time of day, slow motion in the scene].
Camera: [slow push in | slow drift], steady, no cuts. [N] seconds.
No people in close-up, no readable text, no maps, no flags or insignia, no logos.
```

Settings: 720p, 4 to 6 s, `generate_audio: false`. It enters the film as an `ai_illustration` shot with the AI notice.

## 9. Music — `elevenlabs_music_v2_5`

```
Instrumental documentary score, no vocals. [Mood per section with timings, e.g. 0-15 s tense low strings and pulse; 15-40 s driving percussion and brass swells; 40-60 s sparse, reflective piano and strings].
[Middle Eastern colour if it fits the topic: oud, ney, frame drum.] Cinematic, wide, leaves room for a narrator.
```
Duration = the film's length. Save as `audio/music.mp3`.

## 10. Sound effects — a Higgsfield text-to-audio model from the live catalog

One short prompt per effect, 0.3 to 2 s, saved under the built-in names in `audio/sfx/` (.wav): `whoosh` (fast cinematic transition whoosh), `hit` (deep sub impact), `pop` (soft interface pop), `swish` (quick airy sweep), `pulse` (low soft boom), `ping` (radar ping), `typewriter` (three key clicks), `riser` (two-second rising tension).

## 11. Topic icons and cut-outs — `gpt_image_2_6`, transparent background

```
Single isometric 3D icon of [object specific to this film], clean stylised miniature, soft matte materials, gentle top-left light, centred with margin, fully transparent background. No text, no logos.
```
Register it and place it with an `icon` layer and `asset_id`, or `icon_asset_id` on a card. A portrait for the map: same, plus `"framed": true`.

## Queue entry

Record each job in `production/higgs-generation-queue.yaml` with: id, shot_id, role, prompt, model, settings, reference files, `submitted_job_id`, status and result URL. On a timeout, look up the existing job before submitting again.
