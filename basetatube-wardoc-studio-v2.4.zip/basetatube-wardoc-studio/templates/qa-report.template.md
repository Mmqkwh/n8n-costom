# QA Report

- Project: [slug]
- Route: [free|higgs|both]
- Runtime: [claude_web|claude_code]
- Result status: [RESEARCH_REQUIRED|PLAN_ONLY|READY_FOR_RENDER|RENDERED|REVIEW_REQUIRED|GENERATION_PENDING|COMPLETED]

| Gate | PASS/FAIL/PENDING | Evidence / issue |
|---|---|---|
| Sources | PENDING | |
| Maps | PENDING | |
| Assets recorded in manifest | PENDING | |
| Arabic & subtitles | PENDING | |
| Style match (style_check.py) | PENDING | |
| Map quality gate (builder) | PENDING | |
| Wow check: measured (wow_check.py measure) | PENDING | |
| Wow check: verdict by eye, scores (wow_check.py verdict) | PENDING | film average: |
| Visual/audio output | PENDING | |
| Route / wow rule | PENDING | |
| Artifact integrity | PENDING | |

## Required next action

[exact action; do not claim MP4 exists unless verified]
