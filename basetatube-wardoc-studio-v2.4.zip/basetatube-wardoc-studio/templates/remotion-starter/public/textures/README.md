# Bundled pictures

Everything in `public/textures`, `public/atmosphere` and `public/silhouettes` was generated once for this skill (GPT Image 2.6, 2026-11-12) and is shipped as static files. Using them costs nothing at render time.

- `textures/parchment.webp`, `textures/desk.webp`: empty surfaces, no text or map data.
- `atmosphere/*.webp`: six generic, era-neutral backdrops with no people, vehicles, flags or text. They are illustrations, not footage of any real event; the video shows a notice whenever one is used.
- `silhouettes/*.png`: five generic black silhouettes with transparent background, tinted by the map's side colour. They do not depict a specific vehicle model and carry no markings.
- `icons/military.webp`, `icons/civil.webp`: two sprite sheets of 16 isometric 3D icons each (256 px cells, transparent). Generic objects, no markings.
