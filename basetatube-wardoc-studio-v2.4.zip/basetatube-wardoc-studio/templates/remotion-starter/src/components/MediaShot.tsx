import React from 'react';
import {AbsoluteFill, Img, OffthreadVideo, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import build from '../data/build.json';
import {styleTheme} from '../theme';
import {fontFor} from '../fonts';
import {DateCard} from './MapFurniture';
import {ClippingBoard} from './Clipping';
import {Desk, FilmOverlay, FilmStrip, HudFrame, Paperclip, Tape, Vignette, weave} from './Texture';

// Archival (rights-cleared) or AI-illustration shot. Only assets that passed the rights gate in
// scripts/build_remotion_project.py are present in build.json; anything else shows a placeholder.
export const MediaShot: React.FC<{shot: any; durationInFrames: number}> = ({shot, durationInFrames}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const unit = Math.min(width, height);
  const theme = styleTheme(shot.style_id);
  const assets = (build as any).assets ?? {};
  const list = (shot.asset_ids ?? []).map((id: string) => assets[id]).filter(Boolean);
  const asset = list[0];
  const cam = shot.camera ?? {};
  const scale = interpolate(frame, [0, durationInFrames], [cam.scale_start ?? 1.04, cam.scale_end ?? 1.14], {extrapolateRight: 'clamp'});
  const drift = interpolate(frame, [0, durationInFrames], [-1.2, 1.2]);
  const fill: React.CSSProperties = {width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${scale}) translateX(${drift}%)`};
  const archival = shot.shot_type === 'archival_licensed';
  const aged = archival && theme.kind !== 'tactical' ? 'sepia(0.28) contrast(1.06) saturate(0.85)' : 'none';

  const media = (a: any, style: React.CSSProperties) =>
    a.kind === 'video' ? <OffthreadVideo src={staticFile(a.file)} style={style} muted /> : <Img src={staticFile(a.file)} style={style} />;

  const placeholder = (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', background: 'repeating-linear-gradient(45deg,#1d1a15,#1d1a15 24px,#24201a 24px,#24201a 48px)'}}>
      <div style={{direction: 'rtl', fontFamily: fontFor('IBM Plex Sans Arabic'), fontSize: unit * 0.035, color: '#d8cfbd', textAlign: 'center'}}>
        لا يوجد أصل مرخَّص لهذا المشهد بعد<br />
        <span style={{fontSize: unit * 0.024, opacity: 0.7}}>{shot.shot_id}</span>
      </div>
    </AbsoluteFill>
  );

  // Archival atlas: prints lying on the desk, white borders, slight rotations, tape. Up to three assets.
  if (theme.kind === 'archival' && asset) {
    const j = weave(frame);
    const heroZoom = 1 + (Number(scale) - 1) * 0.4;
    const slots = [
      {l: 0.2, t: 0.08, w: 0.6, r: -1.6},
      {l: 0.04, t: 0.2, w: 0.3, r: -5},
      {l: 0.68, t: 0.3, w: 0.28, r: 4},
    ];
    const hasClip = Boolean(shot.clipping) || (Array.isArray(shot.clippings) && shot.clippings.length > 0);
    const order: any[] = list.slice(0, hasClip ? 2 : 3).map((a: any, i: number) => ({a, s: hasClip ? [{l: 0.1, t: 0.08, w: 0.52, r: -1.6}, {l: 0.02, t: 0.5, w: 0.25, r: -5}][i] : list.length === 1 ? {l: 0.17, t: 0.07, w: 0.66, r: -1.4} : slots[i], i}));
    return (
      <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#14110d'}}>
        <Desk />
        {order.reverse().map(({a, s, i}: any) => {
          const p = interpolate(frame, [i * 8, i * 8 + 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
          const w = width * s.w;
          return (
            <div key={i} style={{position: 'absolute', left: width * s.l + j.x, top: height * s.t + j.y - (1 - p) * 40, width: w, opacity: p, zIndex: i === 0 ? 0 : 1, background: '#EFE8D8',
              padding: unit * 0.012, transform: `rotate(${s.r + (1 - p) * 3}deg) scale(${i === 0 ? heroZoom : 1})`, boxShadow: '0 10px 26px rgba(0,0,0,0.7)'}}>
              <div style={{overflow: 'hidden', aspectRatio: '3 / 2'}}>{media(a, {width: '100%', height: '100%', objectFit: 'cover', filter: aged})}</div>
              <Tape size={unit * 0.032} style={{left: '42%', top: -unit * 0.018, transform: `rotate(${Number(s.r) * -2}deg)`}} />
            </div>
          );
        })}
        {hasClip ? <ClippingBoard shot={shot} durationInFrames={durationInFrames} compact /> : null}
        <Vignette strength={0.75} />
        <FilmStrip />
        {shot.date_label_ar ? <DateCard text={shot.date_label_ar} theme={theme} /> : null}
        <FilmOverlay grain={0.2} />
      </AbsoluteFill>
    );
  }

  return (
    <AbsoluteFill style={{backgroundColor: '#15130f', overflow: 'hidden'}}>
      {asset ? <AbsoluteFill style={{filter: aged}}>{media(asset, fill)}</AbsoluteFill> : placeholder}
      <Vignette strength={theme.kind === 'cinematic' ? 0.65 : 0.5} warm={theme.kind === 'cinematic'} />
      {theme.kind === 'tactical' ? <HudFrame theme={theme} grid={false} /> : <FilmOverlay grain={archival ? 0.2 : 0.1} scratches={archival} />}
      {theme.kind === 'cinematic' ? (
        <>
          <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: '6%', background: '#000'}} />
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: '6%', background: '#000'}} />
        </>
      ) : null}
      {shot.date_label_ar ? <DateCard text={shot.date_label_ar} theme={theme} style={theme.kind === 'cinematic' ? {top: height * 0.09} : undefined} /> : null}
    </AbsoluteFill>
  );
};
