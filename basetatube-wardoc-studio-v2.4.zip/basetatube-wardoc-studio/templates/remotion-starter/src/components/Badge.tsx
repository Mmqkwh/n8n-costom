import React from 'react';
import {useVideoConfig} from 'remotion';
import {fontFor} from '../fonts';

// Small honesty notices, stacked in the top-left corner (unverified data, AI illustration, modern basemap, credits).
export const Notices: React.FC<{items: string[]}> = ({items}) => {
  const {width, height} = useVideoConfig();
  const unit = Math.min(width, height);
  if (!items.length) return null;
  return (
    <div style={{position: 'absolute', top: unit * 0.03, left: unit * 0.03, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: unit * 0.008, maxWidth: '46%'}}>
      {items.map((text, i) => (
        <div key={i} dir="rtl" style={{direction: 'rtl', fontFamily: fontFor('IBM Plex Sans Arabic'), fontWeight: 700, fontSize: Math.round(unit * 0.019), color: '#fff',
          background: 'rgba(0,0,0,0.6)', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 6, padding: '3px 12px'}}>
          {text}
        </div>
      ))}
    </div>
  );
};
