import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {niceScale} from '../geo';
import {StyleTheme, sideColors} from '../theme';
import {fontFor} from '../fonts';
import {Icon, Sprite} from './Icon';
import {Tape, tornClip} from './Texture';

// Date card in the look of each style. Used by map shots and cards.
export const DateCard: React.FC<{text: string; theme: StyleTheme; style?: React.CSSProperties}> = ({text, theme, style}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const unit = Math.min(width, height);
  const p = interpolate(frame, [4, 18], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const base: React.CSSProperties = {position: 'absolute', top: height * 0.045, right: width * 0.03, direction: 'rtl', opacity: p, whiteSpace: 'nowrap',
    fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: unit * 0.036, ...style};
  if (theme.kind === 'cinematic') {
    return (
      <div style={{...base, transform: `rotate(-1.5deg) translateY(${(1 - p) * -12}px)`, filter: 'drop-shadow(0 6px 10px rgba(0,0,0,0.5))'}}>
        <div style={{background: `linear-gradient(180deg, ${theme.card}, #D9C39B)`, color: theme.cardText, padding: `${unit * 0.014}px ${unit * 0.04}px`, clipPath: tornClip(11, 30, 9)}}>{text}</div>
      </div>
    );
  }
  if (theme.kind === 'tactical') {
    const blink = Math.floor(frame / 15) % 2 === 0;
    return (
      <div style={{...base, background: theme.card, border: `1px solid ${theme.cardBorder}`, color: theme.cardText, padding: `${unit * 0.008}px ${unit * 0.022}px`,
        fontSize: unit * 0.03, display: 'flex', alignItems: 'center', gap: unit * 0.012, clipPath: `inset(0 ${(1 - p) * 100}% 0 0)`}}>
        <span style={{width: unit * 0.012, height: unit * 0.012, borderRadius: '50%', background: theme.red, opacity: blink ? 1 : 0.25, boxShadow: `0 0 8px ${theme.red}`}} />
        {text}
      </div>
    );
  }
  return (
    <div style={{...base, transform: 'rotate(2deg)', background: theme.card, color: theme.cardText, padding: `${unit * 0.008}px ${unit * 0.03}px`, boxShadow: '0 4px 10px rgba(0,0,0,0.5)'}}>
      {text}
      <Tape size={unit * 0.026} style={{left: '38%', top: -unit * 0.016, transform: 'rotate(-3deg)'}} />
    </div>
  );
};

// Big headline and counting number over a map shot (shot.title_ar, shot.stat), so facts land without leaving the map.
// overlay_at_sec moves the moment they pop in (seconds from the start of the shot).
export const MapOverlay: React.FC<{shot: any; theme: StyleTheme}> = ({shot, theme}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const unit = Math.min(width, height);
  const stat = shot.stat;
  if (shot.shot_type !== 'map_graphic' || (!shot.title_ar && !stat)) return null;
  const start = (shot.overlay_at_sec ?? 0.3) * fps;
  const local = frame - start;
  if (local < 0) return null;
  const pop = spring({frame: local, fps, config: {damping: 14, mass: 0.6}, durationInFrames: 16});
  const count = stat ? interpolate(local, [4, fps * 1.2], [0, Number(stat.value) || 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  const number = stat ? `${stat.prefix_ar ?? ''}${count.toLocaleString('en-US', {maximumFractionDigits: stat.decimals ?? 0, minimumFractionDigits: stat.decimals ?? 0})}` : '';
  const dark = theme.kind === 'tactical';
  const ink = dark ? '#FFFFFF' : theme.cardText;
  const shadow = dark ? '0 2px 0 rgba(0,0,0,0.9), 0 0 14px rgba(0,0,0,0.9), 0 0 30px rgba(0,0,0,0.6)' : '0 0 8px #F6EBD0, 0 0 14px #F6EBD0';
  return (
    <div dir="rtl" style={{position: 'absolute', left: '14%', right: '14%', top: height * 0.12, textAlign: 'center', direction: 'rtl', opacity: Math.min(1, pop * 1.4),
      transform: `scale(${0.7 + 0.3 * pop})`, pointerEvents: 'none'}}>
      {stat ? (
        <div style={{textShadow: shadow}}>
          <span style={{fontFamily: fontFor('Cairo'), fontWeight: 900, fontSize: unit * 0.13, lineHeight: 1.1, color: dark ? theme.highlight : theme.red, direction: 'ltr', display: 'inline-block'}}>{number}</span>
          {stat.unit_ar ? <span style={{fontFamily: fontFor('Cairo'), fontWeight: 900, fontSize: unit * 0.055, color: ink, marginRight: unit * 0.015}}>{stat.unit_ar}</span> : null}
          {stat.label_ar ? <div style={{fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: unit * 0.036, color: ink}}>{stat.label_ar}</div> : null}
        </div>
      ) : null}
      {shot.title_ar ? <div style={{fontFamily: fontFor('Cairo'), fontWeight: 900, fontSize: unit * 0.062, lineHeight: 1.3, color: ink, textShadow: shadow}}>{shot.title_ar}</div> : null}
    </div>
  );
};

const Swatch: React.FC<{layer: any; theme: StyleTheme; size: number}> = ({layer, theme, size}) => {
  const [c, cDark] = sideColors(layer.color, theme);
  const w = size * 2.2, h = size;
  if (layer.type === 'icon') return <Sprite name={layer.icon} size={size * 1.5} />;
  if (layer.type === 'unit' || layer.type === 'event') return <Icon group={layer.type === 'unit' ? 'units' : 'events'} name={layer.symbol} color={c} size={layer.type === 'unit' ? w * 0.8 : h * 1.1} />;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      {layer.type === 'route' ? (
        layer.arrow_style === 'retreat' || theme.kind !== 'cinematic' ? (
          <path d={`M2 ${h / 2} H${w - 4} M${w - h * 0.5} ${h * 0.2} L${w - 3} ${h / 2} L${w - h * 0.5} ${h * 0.8}`} stroke={c} strokeWidth={h * 0.14} fill="none"
            strokeDasharray={layer.arrow_style === 'retreat' || theme.kind === 'tactical' ? `${h * 0.3} ${h * 0.2}` : undefined} strokeLinecap="round" />
        ) : (
          <path d={`M2 ${h * 0.42} L${w * 0.62} ${h * 0.3} L${w * 0.62} ${h * 0.08} L${w - 2} ${h / 2} L${w * 0.62} ${h * 0.92} L${w * 0.62} ${h * 0.7} L2 ${h * 0.58} Z`} fill={c} stroke={cDark} strokeWidth={1} />
        )
      ) : null}
      {layer.type === 'front_line' ? (
        <>
          <path d={`M2 ${h * 0.6} H${w - 2}`} stroke={theme.kind === 'cinematic' ? cDark : c} strokeWidth={h * 0.16} strokeDasharray={theme.kind === 'archival' ? `${h * 0.5} ${h * 0.15}` : undefined} />
          {theme.kind === 'cinematic' ? <path d={Array.from({length: 5}).map((_, i) => `M${4 + (i * (w - 8)) / 4} ${h * 0.6} v${-h * 0.4}`).join(' ')} stroke={cDark} strokeWidth={h * 0.12} /> : null}
        </>
      ) : null}
      {layer.type === 'arc' ? <path d={`M2 ${h * 0.8} Q${w / 2} ${-h * 0.3} ${w - 4} ${h * 0.7}`} stroke={c} strokeWidth={h * 0.12} fill="none" strokeDasharray={`${h * 0.3} ${h * 0.2}`} /> : null}
      {layer.type === 'range' ? <circle cx={w / 2} cy={h / 2} r={h * 0.42} fill={c} fillOpacity={0.12} stroke={c} strokeWidth={1.5} strokeDasharray="4 3" /> : null}
      {layer.type === 'country' ? <rect x={2} y={2} width={w - 4} height={h - 4} rx={3} fill={c} fillOpacity={0.35} stroke="#fff" strokeWidth={1.2} /> : null}
      {layer.type === 'zone' ? <rect x={2} y={2} width={w - 4} height={h - 4} fill={c} fillOpacity={0.3} stroke={c} strokeWidth={1.5} /> : null}
      {layer.type === 'pin' ? (
        theme.kind === 'tactical' ? <rect x={w / 2 - h * 0.2} y={h * 0.3} width={h * 0.4} height={h * 0.4} fill="#fff" /> : <circle cx={w / 2} cy={h / 2} r={h * 0.24} fill={theme.kind === 'cinematic' ? '#fff' : c} stroke="#222" strokeWidth={theme.kind === 'cinematic' ? 2 : 0} />
      ) : null}
    </svg>
  );
};

// Compass, legend and scale bar. The legend lists only layers that carry legend_ar; nothing is invented.
export const MapFurniture: React.FC<{shot: any; theme: StyleTheme; layers: any[]; pxPerKm: number; showScale: boolean; credit?: string | null}> = ({shot, theme, layers, pxPerKm, showScale, credit}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const unit = Math.min(width, height);
  const p = interpolate(frame, [10, 26], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rows: any[] = [];
  for (const l of layers) if (l.legend_ar && !rows.some((r) => r.legend_ar === l.legend_ar)) rows.push(l);
  const scale = niceScale(pxPerKm, width * 0.14);
  const cardLook: React.CSSProperties =
    theme.kind === 'cinematic'
      ? {background: `linear-gradient(180deg, ${theme.card}, #D9C39B)`, border: `2px solid ${theme.cardBorder}`, boxShadow: '0 6px 14px rgba(0,0,0,0.5)'}
      : theme.kind === 'tactical'
        ? {background: theme.card, border: `1px solid ${theme.cardBorder}`}
        : {background: theme.card, boxShadow: '0 5px 12px rgba(0,0,0,0.55)', transform: 'rotate(1.2deg)'};
  const ink = theme.cardText;
  const cs = unit * 0.075;
  return (
    <>
      {shot.date_label_ar ? <DateCard text={shot.date_label_ar} theme={theme} /> : null}
      <MapOverlay shot={shot} theme={theme} />
      {credit ? (
        <div style={{position: 'absolute', right: width * 0.012, bottom: height * 0.008, fontFamily: fontFor('IBM Plex Sans Arabic'), fontSize: unit * 0.014, color: 'rgba(255,255,255,0.75)',
          textShadow: '0 1px 2px #000', direction: 'ltr'}}>{credit}</div>
      ) : null}
      {/* North marker (ش = شمال). The projection is always north-up. */}
      <div style={{position: 'absolute', top: height * (shot.date_label_ar ? 0.15 : 0.05), right: width * 0.035, width: cs, height: cs, opacity: p}}>
        <svg viewBox="0 0 60 60" width={cs} height={cs}>
          {theme.kind === 'cinematic' ? <circle cx="30" cy="34" r="21" fill="rgba(234,216,186,0.85)" stroke={theme.cardBorder} strokeWidth="2" /> : null}
          {theme.kind === 'tactical' ? <path d="M12 16 V10 H18 M42 10 H48 V16" stroke={theme.accent} strokeWidth="2" fill="none" /> : null}
          <path d="M30 14 L37 40 L30 35 L23 40 Z" fill={theme.kind === 'tactical' ? theme.accent : theme.kind === 'archival' ? theme.red : '#3a2c1b'} />
          <text x="30" y="56" textAnchor="middle" fontSize="13" fontWeight="700" fontFamily={fontFor(theme.font)} fill={theme.kind === 'tactical' ? '#fff' : theme.kind === 'archival' ? '#EFE4CE' : '#3a2c1b'}>ش</text>
        </svg>
      </div>
      {rows.length || showScale ? (
        <div style={{position: 'absolute', right: width * 0.03, bottom: height * 0.29, direction: 'rtl', opacity: p, padding: `${unit * 0.012}px ${unit * 0.018}px`,
          fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: unit * 0.021, color: ink, ...cardLook}}>
          {rows.map((l, i) => (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: unit * 0.012, marginBottom: unit * 0.006}}>
              <Swatch layer={l} theme={theme} size={unit * 0.024} />
              <span>{l.legend_ar}</span>
            </div>
          ))}
          {showScale ? (
            <div style={{display: 'flex', alignItems: 'center', gap: unit * 0.01, marginTop: rows.length ? unit * 0.008 : 0, direction: 'ltr'}}>
              <div style={{width: scale.px, height: unit * 0.008, borderLeft: `2px solid ${ink}`, borderRight: `2px solid ${ink}`, borderBottom: `2px solid ${ink}`}} />
              <span style={{direction: 'rtl'}}>{scale.km.toLocaleString('en-US')} كم</span>
            </div>
          ) : null}
        </div>
      ) : null}
    </>
  );
};
