import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import captions from '../data/captions.json';
import build from '../data/build.json';
import {CaptionTheme, captionTheme} from '../theme';
import {fontFor} from '../fonts';

const bare = (w: string) => w.replace(/[.,،؛:!?؟…"«»()]/g, '');

// Arabic RTL captions as real text (never baked into images), in the three looks measured from the
// style-04/05/06 references. Whole words animate; letters are never split, so Arabic joining stays intact.
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const segments: any[] = (captions as any).segments ?? [];
  const seg = segments.find((s) => t >= s.start_sec && t < s.end_sec);
  if (!seg) return null;

  const theme: CaptionTheme = captionTheme(seg.style_id);
  const unit = Math.min(width, height);
  const local = (t - seg.start_sec) * fps;
  const remaining = (seg.end_sec - t) * fps;
  const appear = interpolate(local, [0, theme.enter], [0, 1], {extrapolateRight: 'clamp'});
  const vanish = interpolate(remaining, [0, theme.exit], [0, 1], {extrapolateRight: 'clamp'});
  const opacity = Math.min(appear, vanish);
  const size = unit * theme.sizeFactor;

  const keywords: string[] = seg.highlight_ar ? String(seg.highlight_ar).split(/\s+/).map(bare) : [];
  const words: any[] = Array.isArray(seg.words) && seg.words.length ? seg.words : String(seg.text_ar).split(/\s+/).map((text: string) => ({text, start_sec: null, end_sec: null}));
  const timed = words[0]?.start_sec != null;

  const renderWord = (w: any, i: number) => {
    const active = timed && t >= w.start_sec && t < w.end_sec;
    const spoken = !timed || t >= w.end_sec;
    const keyword = keywords.includes(bare(w.text));
    const hot = active || keyword;
    const since = timed ? (t - w.start_sec) * fps : 99;
    const bump = active ? 1 + 0.1 * interpolate(since, [0, 3, 7], [0, 1, 0.4], {extrapolateRight: 'clamp'}) : 1;
    const common: React.CSSProperties = {display: 'inline-block', margin: `0 ${size * 0.14}px`, opacity: hot || spoken ? 1 : 0.6};
    if (theme.kind === 'kinetic') {
      // Hot word: black text on a skewed yellow block.
      return (
        <span key={i} style={{...common, position: 'relative', transform: `scale(${bump})`, color: hot ? '#0F0F0F' : theme.primary, padding: `0 ${size * 0.16}px`}}>
          {hot ? <span style={{position: 'absolute', inset: `${size * 0.08}px 0`, background: theme.keyword, transform: 'skewX(-12deg)', zIndex: 0}} /> : null}
          <span style={{position: 'relative', zIndex: 1}}>{w.text}</span>
        </span>
      );
    }
    if (theme.kind === 'infographic') {
      // Keyword: red gradient badge with orange corner brackets. Active word: orange text.
      if (keyword) {
        return (
          <span key={i} style={{...common, position: 'relative', transform: `scale(${bump})`, color: '#fff', padding: `0 ${size * 0.3}px`, borderRadius: 4,
            background: 'linear-gradient(135deg, #FF3B14 0%, #B81E00 100%)', boxShadow: '0 4px 15px rgba(230,40,10,0.5)'}}>
            <span style={{position: 'absolute', inset: -size * 0.09, border: `${Math.max(2, size * 0.045)}px solid #FF9900`,
              clipPath: 'polygon(0 0, 18% 0, 18% 100%, 0 100%, 0 0, 82% 0, 100% 0, 100% 100%, 82% 100%, 82% 0)'}} />
            {w.text}
          </span>
        );
      }
      return <span key={i} style={{...common, transform: `scale(${bump})`, color: active ? '#FF9900' : theme.primary}}>{w.text}</span>;
    }
    return <span key={i} style={{...common, color: hot ? theme.keyword : theme.primary, fontWeight: hot ? 800 : theme.weight}}>{w.text}</span>;
  };

  const text = <div style={{position: 'relative', zIndex: 2}}>{words.map(renderWord)}</div>;
  const typo: React.CSSProperties = {direction: 'rtl', textAlign: 'center', fontFamily: fontFor(theme.font), fontWeight: theme.weight, fontSize: size, lineHeight: 1.5,
    color: theme.primary, textShadow: '0 2px 6px rgba(0,0,0,0.6)'};
  let box: React.ReactNode;

  if (theme.kind === 'kinetic') {
    const stripes = (pos: React.CSSProperties) => (
      <span style={{position: 'absolute', width: size * 1.1, height: size * 0.26, ...pos,
        background: `repeating-linear-gradient(-45deg, ${theme.keyword}, ${theme.keyword} ${size * 0.11}px, transparent ${size * 0.11}px, transparent ${size * 0.22}px)`}} />
    );
    box = (
      <div style={{...typo, position: 'relative', background: theme.backing, padding: `${size * 0.16}px ${size * 0.9}px`, boxShadow: '0 14px 28px rgba(0,0,0,0.7)',
        borderLeft: `${Math.max(3, size * 0.09)}px solid #fff`, borderRight: `${Math.max(3, size * 0.09)}px solid #fff`,
        transform: `scale(${0.92 + 0.08 * appear})`}}>
        {stripes({left: size * 0.2, bottom: -size * 0.36})}
        {stripes({right: size * 0.2, top: -size * 0.36})}
        {text}
      </div>
    );
  } else if (theme.kind === 'minimal') {
    const tick = (pos: React.CSSProperties) => <span style={{position: 'absolute', left: '50%', marginLeft: -size * 0.55, width: size * 1.1, height: Math.max(3, size * 0.09), background: theme.keyword, borderRadius: 2, ...pos}} />;
    box = (
      <div style={{...typo, position: 'relative', background: theme.backing, border: '1px solid rgba(255,255,255,0.14)', borderRadius: size * 0.32,
        padding: `${size * 0.26}px ${size * 1.5}px`, boxShadow: '0 10px 30px rgba(0,0,0,0.5)', backdropFilter: 'blur(12px)', textShadow: '0 3px 8px rgba(0,0,0,0.85)',
        transform: `translateY(${(1 - appear) * size * 0.4}px)`}}>
        {tick({top: -Math.max(2, size * 0.045)})}
        {tick({bottom: -Math.max(2, size * 0.045)})}
        {text}
      </div>
    );
  } else {
    box = (
      <div style={{position: 'relative', filter: 'drop-shadow(0 12px 24px rgba(0,0,0,0.65))', transform: `translateX(${(1 - appear) * size * 0.8}px)`}}>
        {seg.callout_ar ? (
          <div style={{position: 'absolute', bottom: '108%', right: '12%', direction: 'rtl', background: '#fff', color: '#0F0F0F', fontFamily: fontFor(theme.font), fontWeight: 700,
            fontSize: size * 0.5, padding: `${size * 0.06}px ${size * 0.4}px`, borderRadius: size * 0.16, borderBottom: '3px solid #E63B20', whiteSpace: 'nowrap'}}>
            {seg.callout_ar}
          </div>
        ) : null}
        <div style={{...typo, position: 'relative', background: 'linear-gradient(90deg, #1A1C20 0%, #2A2D34 100%)', padding: `${size * 0.18}px ${size * 1.4}px ${size * 0.18}px ${size * 2.2}px`,
          clipPath: 'polygon(2.5% 0%, 97.5% 0%, 100% 50%, 97.5% 100%, 0% 100%, 0% 0%)', borderTop: '2px solid #6E727A', borderBottom: '2px solid #6E727A'}}>
          <span style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: size * 1.5, background: '#73281E', borderRight: '3px solid #E63B20', clipPath: 'polygon(0 0, 100% 0, 72% 100%, 0 100%)'}} />
          {text}
        </div>
      </div>
    );
  }

  return (
    <div style={{position: 'absolute', left: (build as any).presenter ? '22%' : '6%', right: '6%', bottom: `${height > width ? theme.bottomPct + 6 : theme.bottomPct}%`,
      display: 'flex', justifyContent: 'center', opacity}}>
      <div dir="rtl" lang="ar" style={{maxWidth: '100%'}}>{box}</div>
    </div>
  );
};
