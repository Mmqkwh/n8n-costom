import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {rand} from '../geo';

export const TRANSITION_FRAMES = 14;
export const TRANSITIONS = ['none', 'cross_dissolve', 'paper_slide', 'paper_rip', 'radar_wipe', 'film_flash'];

// Entry transition of a shot. The previous shot keeps playing underneath for TRANSITION_FRAMES.
export const TransitionIn: React.FC<{type: string; children: React.ReactNode}> = ({type, children}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const p = interpolate(frame, [0, TRANSITION_FRAMES], [0, 1], {extrapolateRight: 'clamp'});
  const e = 1 - Math.pow(1 - p, 3);
  if (type === 'none' || p >= 1) return <AbsoluteFill>{children}</AbsoluteFill>;
  if (type === 'paper_slide') {
    return <AbsoluteFill style={{transform: `translateX(${(1 - e) * 104}%) rotate(${(1 - e) * 3}deg)`, boxShadow: '-30px 0 60px rgba(0,0,0,0.6)'}}>{children}</AbsoluteFill>;
  }
  if (type === 'paper_rip') {
    // A ragged vertical edge sweeps from right to left (RTL reading direction).
    const edge = (1 - e) * 112 - 6;
    const pts = ['100% 0%'];
    for (let i = 0; i <= 24; i++) pts.push(`${(edge + rand(i + 7) * 6).toFixed(2)}% ${((i / 24) * 100).toFixed(2)}%`);
    pts.push('100% 100%');
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{clipPath: `polygon(${pts.join(', ')})`}}>{children}</AbsoluteFill>
        <div style={{position: 'absolute', top: 0, bottom: 0, left: `${edge + 2}%`, width: '1.2%', background: 'rgba(245,238,220,0.9)', filter: 'blur(1px)', opacity: 1 - p}} />
      </AbsoluteFill>
    );
  }
  if (type === 'radar_wipe') {
    const r = e * Math.hypot(width, height) * 0.6;
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{clipPath: `circle(${r}px at 50% 50%)`}}>{children}</AbsoluteFill>
        <svg width={width} height={height} style={{position: 'absolute', inset: 0}}>
          <circle cx={width / 2} cy={height / 2} r={r} fill="none" stroke="#00E5FF" strokeWidth={4} opacity={1 - p} style={{filter: 'drop-shadow(0 0 12px #00E5FF)'}} />
        </svg>
      </AbsoluteFill>
    );
  }
  if (type === 'film_flash') {
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{opacity: Math.min(1, p * 2.5)}}>{children}</AbsoluteFill>
        <AbsoluteFill style={{background: '#FFF6E0', opacity: interpolate(p, [0, 0.25, 1], [0, 0.85, 0])}} />
      </AbsoluteFill>
    );
  }
  return <AbsoluteFill style={{opacity: p}}>{children}</AbsoluteFill>;
};
