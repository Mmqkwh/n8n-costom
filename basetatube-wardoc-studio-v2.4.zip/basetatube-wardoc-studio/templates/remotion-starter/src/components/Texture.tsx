import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {rand} from '../geo';
import {StyleTheme} from '../theme';

export const Parchment: React.FC<{style?: React.CSSProperties}> = ({style}) => (
  <Img src={staticFile('textures/parchment.webp')} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', ...style}} />
);

export const Desk: React.FC = () => (
  <Img src={staticFile('textures/desk.webp')} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} />
);

export const Vignette: React.FC<{strength: number; warm?: boolean}> = ({strength, warm}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 52%, rgba(${warm ? '28,18,8' : '0,0,0'},${strength}) 100%)`, pointerEvents: 'none'}} />
);

// Film grain + occasional vertical scratches + tiny gate weave. Procedural and seeded by frame number.
export const FilmOverlay: React.FC<{grain?: number; scratches?: boolean}> = ({grain = 0.16, scratches = true}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const id = `grain-${frame % 8}`;
  const lines = scratches ? [0, 1, 2].filter((i) => rand(Math.floor(frame / 3) * 7 + i) > 0.62) : [];
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={width} height={height} style={{mixBlendMode: 'overlay', opacity: grain * 2}}>
        <filter id={id}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={(frame % 8) + 1} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#${id})`} />
      </svg>
      <svg width={width} height={height} style={{position: 'absolute', inset: 0}}>
        {lines.map((i) => {
          const x = rand(Math.floor(frame / 3) * 13 + i * 5) * width;
          return <line key={i} x1={x} y1={0} x2={x + 2} y2={height} stroke="rgba(255,255,255,0.22)" strokeWidth={1} />;
        })}
      </svg>
    </AbsoluteFill>
  );
};

// Gate weave for archival material: a sub-pixel-to-2px drift, never enough to hurt readability.
export const weave = (frame: number) => ({x: (rand(Math.floor(frame / 2)) - 0.5) * 2.4, y: (rand(Math.floor(frame / 2) + 99) - 0.5) * 1.8});

// Tactical HUD: grid with crosshair ticks, scanlines, corner brackets and a slow sweep line.
export const HudFrame: React.FC<{theme: StyleTheme; grid?: boolean}> = ({theme, grid = true}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const unit = Math.min(width, height);
  const step = unit / 13;
  const m = unit * 0.03, L = unit * 0.07;
  const sweep = ((frame / fps) * 0.22 % 1) * height;
  const cols = Math.ceil(width / step), rows = Math.ceil(height / step);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={width} height={height}>
        {grid ? (
          <g stroke={theme.accent} strokeOpacity={0.08} strokeWidth={1}>
            {Array.from({length: cols + 1}).map((_, i) => <line key={`v${i}`} x1={i * step} y1={0} x2={i * step} y2={height} />)}
            {Array.from({length: rows + 1}).map((_, i) => <line key={`h${i}`} x1={0} y1={i * step} x2={width} y2={i * step} />)}
          </g>
        ) : null}
        {grid ? (
          <g stroke={theme.accent} strokeOpacity={0.35} strokeWidth={1.2}>
            {Array.from({length: Math.ceil(cols / 2) + 1}).flatMap((_, i) =>
              Array.from({length: Math.ceil(rows / 2) + 1}).map((__, j) => (
                <path key={`${i}-${j}`} d={`M${i * step * 2 - 5} ${j * step * 2} h10 M${i * step * 2} ${j * step * 2 - 5} v10`} />
              )),
            )}
          </g>
        ) : null}
        <rect x={0} y={sweep} width={width} height={unit * 0.004} fill={theme.accent} opacity={0.18} />
        <g stroke={theme.accent} strokeWidth={unit * 0.004} fill="none" opacity={0.9}>
          <path d={`M${m} ${m + L} V${m} H${m + L}`} />
          <path d={`M${width - m - L} ${m} H${width - m} V${m + L}`} />
          <path d={`M${m} ${height - m - L} V${height - m} H${m + L}`} />
          <path d={`M${width - m - L} ${height - m} H${width - m} V${height - m - L}`} />
        </g>
      </svg>
      <AbsoluteFill style={{background: 'repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0px, rgba(0,0,0,0.22) 2px, rgba(0,0,0,0) 4px)'}} />
    </AbsoluteFill>
  );
};

// Ragged torn-paper edge as a clip-path polygon (deterministic).
export const tornClip = (seed: number, teeth = 46, depth = 5) => {
  const top: string[] = [], bottom: string[] = [];
  for (let i = 0; i <= teeth; i++) {
    const x = (i / teeth) * 100;
    top.push(`${x.toFixed(2)}% ${(rand(seed + i) * depth).toFixed(2)}%`);
    bottom.push(`${(100 - x).toFixed(2)}% ${(100 - rand(seed + 200 + i) * depth).toFixed(2)}%`);
  }
  return `polygon(${[...top, ...bottom].join(', ')})`;
};

// A strip of masking tape.
export const Tape: React.FC<{style: React.CSSProperties; size: number}> = ({style, size}) => (
  <div style={{position: 'absolute', width: size * 2.6, height: size, background: 'rgba(225,210,175,0.72)', boxShadow: '0 1px 3px rgba(0,0,0,0.35)', ...style}} />
);

// 35mm film strip edge (archival style), procedural.
export const FilmStrip: React.FC<{heightPct?: number}> = ({heightPct = 5.2}) => {
  const {width, height} = useVideoConfig();
  const h = (height * heightPct) / 100;
  const hole = h * 0.36, gap = hole * 1.9;
  const n = Math.ceil(width / gap) + 1;
  return (
    <svg width={width} height={h} style={{position: 'absolute', left: 0, bottom: 0, pointerEvents: 'none'}}>
      <rect width={width} height={h} fill="#0B0907" />
      {Array.from({length: n}).map((_, i) => (
        <rect key={i} x={i * gap + gap * 0.25} y={h * 0.32} width={hole * 1.15} height={hole} rx={hole * 0.18} fill="#2A241D" stroke="#3A332A" strokeWidth={1} />
      ))}
      <rect y={0} width={width} height={h * 0.1} fill="#1A1611" />
    </svg>
  );
};

// A metal paperclip, drawn in code.
export const Paperclip: React.FC<{size: number; style: React.CSSProperties}> = ({size, style}) => (
  <svg viewBox="0 0 40 100" width={size * 0.4} height={size} style={{position: 'absolute', filter: 'drop-shadow(1px 2px 2px rgba(0,0,0,0.5))', ...style}}>
    <path d="M12 26 V78 A9 9 0 0 0 30 78 V16 A11 11 0 0 0 8 16 V84 A13 13 0 0 0 34 84 V34" fill="none" stroke="#B9BDC2" strokeWidth="3.4" strokeLinecap="round" />
    <path d="M12 26 V78 A9 9 0 0 0 30 78 V16" fill="none" stroke="#E9ECEF" strokeWidth="1" strokeLinecap="round" opacity="0.7" />
  </svg>
);

// Faded round archive stamp. Purely decorative ("أرشيف" = archive); it asserts nothing about a source.
export const ArchiveStamp: React.FC<{size: number; style: React.CSSProperties; font: string}> = ({size, style, font}) => (
  <svg viewBox="0 0 120 120" width={size} height={size} style={{position: 'absolute', opacity: 0.55, ...style}}>
    <g fill="none" stroke="#7A2525" strokeWidth="3">
      <circle cx="60" cy="60" r="52" strokeDasharray="150 6 60 4 90 8" />
      <circle cx="60" cy="60" r="40" strokeWidth="1.6" />
    </g>
    <text x="60" y="70" textAnchor="middle" fontFamily={font} fontWeight="700" fontSize="27" fill="#7A2525">أرشيف</text>
  </svg>
);

// Newsprint halftone dots as a CSS background.
export const HALFTONE = 'radial-gradient(rgba(40,32,22,0.2) 1px, transparent 1.4px)';

// Soft drifting cloud cover and its shadow over a satellite picture. Rendered small and stretched, so it stays cheap.
export const Clouds: React.FC<{opacity?: number}> = ({opacity = 0.1}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const drift = (frame / fps) * 0.9;   // percent of the frame per second
  const layer = (dx: number, dy: number, style: React.CSSProperties) => (
    <svg viewBox="0 0 480 270" preserveAspectRatio="none" width={width * 1.3} height={height * 1.3}
      style={{position: 'absolute', left: `${-15 + ((drift + dx) % 12)}%`, top: `${-15 + dy}%`, ...style}}>
      <filter id="wd-clouds" x="0" y="0" width="100%" height="100%">
        <feTurbulence type="fractalNoise" baseFrequency="0.011 0.018" numOctaves="4" seed="7" />
        <feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  3.4 0 0 0 -2.0" />
      </filter>
      <rect width="480" height="270" filter="url(#wd-clouds)" />
    </svg>
  );
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden'}}>
      {layer(1.2, 1.6, {opacity: opacity * 0.9, filter: 'brightness(0)', mixBlendMode: 'multiply'})}
      {layer(0, 0, {opacity, mixBlendMode: 'screen'})}
    </AbsoluteFill>
  );
};
