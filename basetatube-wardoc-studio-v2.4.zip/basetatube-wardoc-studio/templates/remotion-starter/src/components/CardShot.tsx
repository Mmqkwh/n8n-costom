import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import build from '../data/build.json';
import {styleTheme} from '../theme';
import {fontFor} from '../fonts';
import {DateCard} from './MapFurniture';
import {Desk, FilmOverlay, FilmStrip, HudFrame, Parchment, Vignette, tornClip} from './Texture';
import {AtmospherePlate} from './Atmosphere';
import {ClippingBoard} from './Clipping';
import {Sprite} from './Icon';

// Title, statistic, quote and transition cards, plus the backdrop of a presenter shot.
// Shows only the shot's own on-screen fields (title_ar, date_label_ar, stat, quote).
// The narration text (script_ar) is never auto-printed here.
export const CardShot: React.FC<{shot: any; durationInFrames: number; variant: 'card' | 'presenter'}> = ({shot, durationInFrames, variant}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const unit = Math.min(width, height);
  const theme = styleTheme(shot.style_id);
  const kind = theme.kind;
  const enter = spring({frame, fps, config: {damping: 200}, durationInFrames: 18});
  const exit = interpolate(frame, [durationInFrames - 8, durationInFrames], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rule = interpolate(frame, [6, 26], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const side = variant === 'presenter';
  const ink = kind === 'tactical' ? '#FFFFFF' : kind === 'cinematic' ? '#F4E9D2' : theme.cardText;
  const titleSize = unit * (side ? 0.064 : 0.085);

  const stat = shot.stat;
  const count = stat ? interpolate(frame, [8, Math.min(durationInFrames - 10, 8 + fps * 1.4)], [0, Number(stat.value) || 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  const statText = stat ? `${stat.prefix_ar ?? ''}${count.toLocaleString('en-US', {maximumFractionDigits: stat.decimals ?? 0, minimumFractionDigits: stat.decimals ?? 0})}` : '';
  const quote = shot.quote;
  const hasClips = Boolean(shot.clipping) || (Array.isArray(shot.clippings) && shot.clippings.length > 0);
  const hasText = Boolean(shot.title_ar || stat || quote || shot.icon || shot.icon_asset_id);
  const plate = shot.atmosphere;

  const content = (
    <>
      {shot.icon_asset_id && ((build as any).assets ?? {})[shot.icon_asset_id] ? (
        <div style={{display: 'flex', justifyContent: side ? 'flex-start' : 'center', marginBottom: unit * 0.015}}>
          <Img src={staticFile((build as any).assets[shot.icon_asset_id].file)} style={{height: unit * 0.26, maxWidth: '70%', objectFit: 'contain', transform: `scale(${0.6 + 0.4 * enter})`,
            filter: 'drop-shadow(0 10px 14px rgba(0,0,0,0.5))'}} />
        </div>
      ) : shot.icon ? (
        <div style={{display: 'flex', justifyContent: side ? 'flex-start' : 'center', marginBottom: unit * 0.015}}>
          <Sprite name={shot.icon} size={unit * 0.24} style={{transform: `scale(${0.6 + 0.4 * enter})`, filter: kind === 'archival' ? 'sepia(0.85)' : 'drop-shadow(0 10px 14px rgba(0,0,0,0.5))'}} />
        </div>
      ) : null}
      {shot.title_ar ? <div style={{fontFamily: fontFor(theme.titleFont), fontWeight: 900, fontSize: titleSize, lineHeight: 1.3, color: ink}}>{shot.title_ar}</div> : null}
      {stat ? (
        <div style={{marginTop: shot.title_ar ? unit * 0.02 : 0}}>
          <div style={{fontFamily: fontFor('Cairo'), fontWeight: 900, fontSize: unit * 0.17, lineHeight: 1.1, color: theme.accent, direction: 'ltr', display: 'inline-block'}}>{statText}</div>
          {stat.unit_ar ? <span style={{fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: unit * 0.05, color: ink, marginRight: unit * 0.02}}>{stat.unit_ar}</span> : null}
          {stat.label_ar ? <div style={{fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: unit * 0.042, color: ink, opacity: 0.9}}>{stat.label_ar}</div> : null}
        </div>
      ) : null}
      {quote ? (
        <div style={{marginTop: shot.title_ar ? unit * 0.03 : 0}}>
          <div style={{fontFamily: fontFor('Cairo'), fontWeight: 900, fontSize: unit * 0.13, lineHeight: 0.6, color: theme.accent}}>”</div>
          <div style={{fontFamily: fontFor(theme.titleFont), fontWeight: 700, fontSize: unit * 0.052, lineHeight: 1.6, color: ink}}>{quote.text_ar}</div>
          {quote.source_ar ? <div style={{fontFamily: fontFor(theme.font), fontWeight: 400, fontSize: unit * 0.03, color: ink, opacity: 0.8, marginTop: unit * 0.014}}>— {quote.source_ar}</div> : null}
        </div>
      ) : null}
      <div style={{height: Math.max(3, unit * 0.006), width: `${rule * 100}%`, background: kind === 'tactical' ? theme.accent : theme.red, margin: `${unit * 0.03}px ${side ? 0 : 'auto'} 0`,
        boxShadow: kind === 'tactical' ? `0 0 10px ${theme.accent}` : undefined}} />
    </>
  );

  const place: React.CSSProperties = side
    ? {position: 'absolute', right: width * 0.06, width: width * 0.42, top: '50%', marginTop: -unit * 0.16, textAlign: 'right'}
    : {position: 'absolute', left: '50%', top: '46%', width: width * 0.76, marginLeft: -width * 0.38, textAlign: 'center', transform: 'translateY(-50%)'};
  const anim: React.CSSProperties = {opacity: enter * exit};
  const paper = kind === 'archival';

  return (
    <AbsoluteFill style={{background: kind === 'tactical' ? `radial-gradient(ellipse at 50% 40%, #12202B 0%, ${theme.seaDeep} 100%)` : '#14110d', overflow: 'hidden'}}>
      {plate ? <AtmospherePlate name={plate} kind={kind} durationInFrames={durationInFrames} dim={paper ? 0.25 : 0.5} /> : null}
      {kind === 'cinematic' && !plate ? <Parchment style={{filter: 'brightness(0.34) saturate(0.8)'}} /> : null}
      {kind === 'cinematic' ? <Vignette strength={0.8} warm /> : null}
      {kind === 'tactical' ? <HudFrame theme={theme} grid={!plate} /> : null}
      {paper && !plate ? <Desk /> : null}
      {paper ? <><Vignette strength={0.7} /><FilmStrip /></> : null}
      {hasClips ? <div style={{position: 'absolute', inset: 0, opacity: exit}}><ClippingBoard shot={shot} durationInFrames={durationInFrames} /></div> : null}
      {hasClips && !hasText ? null : <div dir="rtl" style={{direction: 'rtl', ...place, ...anim}}>
        {paper ? (
          <div style={{background: theme.card, padding: `${unit * 0.05}px ${unit * 0.06}px`, transform: `rotate(${side ? 1.2 : -1.2}deg) translateY(${(1 - enter) * 30}px)`,
            boxShadow: '0 12px 30px rgba(0,0,0,0.7)', clipPath: tornClip(5, 60, 3)}}>
            {content}
          </div>
        ) : (
          <div style={{transform: `translateY(${(1 - enter) * 30}px)`}}>{content}</div>
        )}
      </div>}
      {shot.date_label_ar ? <DateCard text={shot.date_label_ar} theme={theme} /> : null}
      {kind !== 'tactical' ? <FilmOverlay grain={0.14} scratches={paper} /> : null}
    </AbsoluteFill>
  );
};
