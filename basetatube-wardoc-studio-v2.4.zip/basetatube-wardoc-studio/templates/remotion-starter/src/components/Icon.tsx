import React from 'react';
import {staticFile} from 'remotion';
import icons from '../icons.json';

// Original, generic map symbols (unit frames follow the common rectangle convention; no national insignia).
// Single source: src/icons.json. scripts/export_map_symbols.py writes the same shapes as standalone SVG files.
export const UNIT_SYMBOLS = Object.keys((icons as any).units.items);
export const EVENT_SYMBOLS = Object.keys((icons as any).events.items);

export const Icon: React.FC<{group: 'units' | 'events'; name: string; color: string; size: number; style?: React.CSSProperties}> = ({group, name, color, size, style}) => {
  const set = (icons as any)[group];
  const body = set.items[name];
  if (!body) return null;
  const [, , vw, vh] = set.viewBox.split(' ').map(Number);
  return (
    <svg viewBox={set.viewBox} width={size} height={(size * vh) / vw} style={{color, overflow: 'visible', ...style}} dangerouslySetInnerHTML={{__html: body}} />
  );
};

// 3D icons cut from two sprite sheets (public/icons/military.webp, civil.webp): one picture per sheet instead of
// one file per icon. The index lives in src/icons.json under "_sprites".
const SPRITES = (icons as any)._sprites;
export const SPRITE_NAMES: string[] = Object.keys(SPRITES.items);

export const Sprite: React.FC<{name: string; size: number; style?: React.CSSProperties}> = ({name, size, style}) => {
  const item = SPRITES.items[name];
  if (!item) return null;
  const [sheet, col, row] = item;
  return (
    <div style={{width: size, height: size, backgroundImage: `url(${staticFile(SPRITES.sheets[sheet])})`, backgroundRepeat: 'no-repeat',
      backgroundSize: `${SPRITES.cols * 100}% ${SPRITES.rows * 100}%`,
      backgroundPosition: `${(col / (SPRITES.cols - 1)) * 100}% ${(row / (SPRITES.rows - 1)) * 100}%`, ...style}} />
  );
};
