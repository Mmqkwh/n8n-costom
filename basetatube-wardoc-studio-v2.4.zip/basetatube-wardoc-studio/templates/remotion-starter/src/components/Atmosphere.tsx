import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {rand} from '../geo';
import {StyleKind} from '../theme';

// Generic, era-neutral backdrops generated once for this skill and bundled (public/atmosphere).
// They are illustrations, never footage of a real event: Documentary.tsx shows a notice whenever one is on screen.
export const ATMOSPHERES = ['desert', 'winter', 'city', 'sea', 'war_room', 'mountain'];
const GRADE: Record<StyleKind, string> = {
  cinematic: 'none',
  tactical: 'grayscale(1) brightness(0.6)',
  archival: 'sepia(0.75)',
};

// Slow drifting dust / snow / spray so a still plate reads as a living shot. Seeded: identical on every render.
export const Drift: React.FC<{name: string; count?: number}> = ({name, count = 28}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const t = frame / fps;
  const snow = name === 'winter';
  const color = snow ? '255,255,255' : name === 'sea' ? '225,235,240' : name === 'city' ? '200,200,200' : '255,226,170';
  return (
    <svg width={width} height={height} style={{position: 'absolute', inset: 0, pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const speed = 0.02 + rand(i + 1) * 0.05;
        const x = ((rand(i * 3 + 2) + t * speed * (snow ? 0.4 : 1)) % 1) * width;
        const y = snow ? ((rand(i * 5 + 4) + t * (0.06 + rand(i) * 0.05)) % 1) * height : (0.35 + rand(i * 5 + 4) * 0.65) * height + Math.sin(t * 0.7 + i) * 8;
        const r = (snow ? 1.5 : 1) + rand(i * 7 + 6) * (snow ? 2.5 : 3);
        return <circle key={i} cx={x} cy={y} r={r} fill={`rgba(${color},${0.12 + rand(i * 11) * 0.3})`} />;
      })}
    </svg>
  );
};

// Full-frame plate with a slow push. `dim` darkens it so text on top stays readable.
export const AtmospherePlate: React.FC<{name: string; kind: StyleKind; durationInFrames: number; dim?: number}> = ({name, kind, durationInFrames, dim = 0}) => {
  const frame = useCurrentFrame();
  if (!ATMOSPHERES.includes(name)) return null;
  const scale = interpolate(frame, [0, durationInFrames], [1.04, 1.12], {extrapolateRight: 'clamp'});
  const drift = interpolate(frame, [0, durationInFrames], [-0.8, 0.8], {extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <Img src={staticFile(`atmosphere/${name}.webp`)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${scale}) translateX(${drift}%)`, filter: GRADE[kind]}} />
      {name !== 'war_room' ? <Drift name={name} /> : null}
      {kind === 'tactical' ? <AbsoluteFill style={{background: 'rgba(0,60,90,0.35)'}} /> : null}
      {dim ? <AbsoluteFill style={{background: `rgba(${kind === 'tactical' ? '5,8,12' : '12,9,6'},${dim})`}} /> : null}
    </AbsoluteFill>
  );
};

// The lower band of a cinematic map dissolving into a battlefield plate, as in style reference 01.
export const AtmosphereBand: React.FC<{name: string; kind: StyleKind; durationInFrames: number; heightPct?: number}> = ({name, kind, durationInFrames, heightPct = 40}) => {
  const frame = useCurrentFrame();
  if (!ATMOSPHERES.includes(name)) return null;
  const scale = interpolate(frame, [0, durationInFrames], [1.03, 1.1], {extrapolateRight: 'clamp'});
  // The fade into the map is baked into the *-band.webp files (alpha), so no mask is computed per frame.
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: `${heightPct}%`, overflow: 'hidden', pointerEvents: 'none'}}>
      <Img src={staticFile(`atmosphere/${name}-band.webp`)} style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 100%',
        transform: `scale(${scale})`, transformOrigin: '50% 100%'}} />
      {name !== 'war_room' ? <Drift name={name} count={30} /> : null}
    </div>
  );
};
