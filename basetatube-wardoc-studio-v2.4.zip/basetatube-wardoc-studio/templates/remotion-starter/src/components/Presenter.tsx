import React from 'react';
import {Img, OffthreadVideo, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import captions from '../data/captions.json';
import build from '../data/build.json';

// Two kinds of host, chosen by the builder (build.json presenter_mode):
//   "layered"  the radio mascot: one body image + an eyes overlay + a mouth overlay, so any gesture can be
//              combined with any eye and mouth state (public/presenter/body_*, eyes_*, mouth_*).
//   "poses"    twelve whole-figure pose files (the classic SVG man, or a custom host).
// Mouth movement follows caption word timing as an approximation. It is NOT true lip sync.
export const POSES = ['neutral', 'speaking_closed', 'speaking_mid', 'speaking_open', 'pointing_left', 'pointing_right', 'pointing_up',
  'explaining', 'thinking', 'holding_paper', 'surprised', 'blinking'];
export const BODIES = ['neutral', 'point_left', 'point_right', 'point_up', 'explaining', 'holding_paper', 'thinking'];
export const EYES = ['blink', 'left', 'right', 'up', 'wide'];
export const MOUTHS = ['mid', 'open'];
const BODY_OF: Record<string, string> = {pointing_left: 'point_left', pointing_right: 'point_right', pointing_up: 'point_up', explaining: 'explaining',
  holding_paper: 'holding_paper', thinking: 'thinking'};

export const Presenter: React.FC<{shot: any; shotStartSec: number}> = ({shot, shotStartSec}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const b = build as any;
  const t = shotStartSec + frame / fps;
  const segments: any[] = (captions as any).segments ?? [];
  const seg = segments.find((s) => t >= s.start_sec && t < s.end_sec);
  const big = shot.shot_type === 'presenter';
  const globalFrame = Math.round(t * fps);
  const named: string | null = shot.presenter_pose && POSES.includes(shot.presenter_pose) ? shot.presenter_pose : null;

  // Mouth: closed -> mid -> open -> mid inside each spoken word; closed between words.
  let mouth: 'closed' | 'mid' | 'open' = 'closed';
  if (seg) {
    const word = Array.isArray(seg.words) ? seg.words.find((w: any) => t >= w.start_sec && t < w.end_sec) : null;
    if (word) {
      const u = (t - word.start_sec) / Math.max(0.05, word.end_sec - word.start_sec);
      const cycle = Math.abs(Math.sin(u * Math.PI * Math.max(1, Math.round((word.end_sec - word.start_sec) * 5))));
      mouth = cycle > 0.66 ? 'open' : cycle > 0.25 ? 'mid' : 'closed';
    } else if (!Array.isArray(seg.words) || !seg.words.length) {
      mouth = (['mid', 'open', 'mid', 'closed'] as const)[Math.floor(globalFrame / 3) % 4];
    }
  }
  const blinkNow = globalFrame % Math.round(fps * 3.2) < 4;
  const pointing = shot.shot_type === 'map_graphic' && frame < fps * 1.4;
  const paper = Boolean(shot.stat || shot.quote || shot.clipping || shot.clippings?.length);

  const h = (big ? 0.72 : 0.3) * height;
  const enter = interpolate(frame, [0, 10], [0, 1], {extrapolateRight: 'clamp'});
  const bob = Math.sin((globalFrame / fps) * Math.PI * 0.8) * height * 0.004;
  const ext = b.presenter_ext ?? 'svg';
  const box: React.CSSProperties = {position: 'absolute', left: big ? width * 0.07 : width * 0.015, bottom: bob - (big ? 0 : height * 0.01), height: h, width: h * 0.8,
    opacity: big ? enter : 1, filter: 'drop-shadow(0 10px 24px rgba(0,0,0,0.45))'};
  const layer: React.CSSProperties = {position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain'};

  // A generated talking clip for this shot (HIGGS route) replaces the drawn host. Its own voice is played (so lips and sound match exactly) and the narration track is silenced for that shot.
  const talk = (b.talk ?? {})[shot.shot_id];
  if (talk) {
    return (
      <div style={box}>
        <OffthreadVideo src={staticFile(talk.file)} transparent={Boolean(talk.transparent)} muted={!talk.audio} style={{...layer, objectFit: talk.transparent ? 'contain' : 'cover', borderRadius: talk.transparent ? 0 : h * 0.04}} />
      </div>
    );
  }

  if (b.presenter_mode === 'layered') {
    let body = 'neutral';
    if (named && BODY_OF[named]) body = BODY_OF[named];
    else if (!named && pointing) body = 'point_right';
    else if (!named && paper) body = 'holding_paper';
    else if (!named && big && seg && Math.floor(t / 2.4) % 2 === 0) body = 'explaining';

    let eyes: string | null = null;
    if (named === 'blinking' || (blinkNow && named !== 'surprised')) eyes = 'blink';
    else if (named === 'surprised') eyes = 'wide';
    else if (body === 'thinking') eyes = 'up';
    else if (body === 'point_right') eyes = 'right';
    else if (body === 'point_left') eyes = 'left';

    let lips: string | null = mouth === 'closed' ? null : mouth;
    if (named === 'speaking_mid') lips = 'mid';
    if (named === 'speaking_open' || named === 'surprised') lips = 'open';
    if (named === 'speaking_closed' || body === 'thinking') lips = null; // the thinking hand rests over the mouth corner

    // Every layer stays mounted so switching never flashes; only the chosen ones are visible.
    return (
      <div style={box}>
        {BODIES.map((n) => <Img key={`b${n}`} src={staticFile(`presenter/body_${n}.${ext}`)} style={{...layer, opacity: n === body ? 1 : 0}} />)}
        {EYES.map((n) => <Img key={`e${n}`} src={staticFile(`presenter/eyes_${n}.${ext}`)} style={{...layer, opacity: n === eyes ? 1 : 0}} />)}
        {MOUTHS.map((n) => <Img key={`m${n}`} src={staticFile(`presenter/mouth_${n}.${ext}`)} style={{...layer, opacity: n === lips ? 1 : 0}} />)}
      </div>
    );
  }

  let pose = 'neutral';
  if (named) pose = named;
  else if (pointing) pose = 'pointing_right';
  else if (mouth !== 'closed') pose = `speaking_${mouth}`;
  else if (seg && Array.isArray(seg.words) && seg.words.length) pose = 'speaking_closed';
  else if (blinkNow) pose = 'blinking';
  else if (paper) pose = 'holding_paper';
  else if (big && seg) pose = 'explaining';
  return (
    <div style={box}>
      {POSES.map((p) => <Img key={p} src={staticFile(`presenter/${p}.${ext}`)} style={{...layer, opacity: p === pose ? 1 : 0}} />)}
    </div>
  );
};
