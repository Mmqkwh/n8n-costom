import React from 'react';
import {Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import build from '../data/build.json';
import {fontFor} from '../fonts';
import {ArchiveStamp, HALFTONE, Paperclip, Tape, tornClip} from './Texture';
import {ATMOSPHERES} from './Atmosphere';

// Editable Arabic newspaper clippings in the look of mid-century print (libraries/clipping-templates.yaml).
// These are DESIGNED cards that typeset the words given in the shot plan. They are not scans of real
// newspapers; Documentary.tsx shows a notice whenever one is on screen. Every text field is optional
// except headline_ar, so nothing is invented when a field is left out.
export const CLIPPING_TEMPLATES = ['front_page', 'banner', 'column', 'photo_report', 'telegram'];

const PAPER: Record<string, string> = {aged: '#D9CDB8', yellowed: '#E2D2A6', grey: '#CFCBC2', white: '#E9E4D8'};
const INK = '#1d1812';
const RED = '#8E1B16';
// Width of each template as a fraction of the layout base, and its default decoration.
const SPEC: Record<string, {w: number; maxH: number; decor: string[]}> = {
  front_page: {w: 0.5, maxH: 0.74, decor: ['paperclip', 'fold']},
  banner: {w: 0.54, maxH: 0.72, decor: ['fold']},
  column: {w: 0.24, maxH: 0.76, decor: ['tape']},
  photo_report: {w: 0.42, maxH: 0.74, decor: ['tape']},
  telegram: {w: 0.44, maxH: 0.6, decor: ['stamp']},
};

const paragraphs = (body: any): string[] => (Array.isArray(body) ? body : body ? String(body).split(/\n\s*\n|\n/) : []).map((p: string) => p.trim()).filter(Boolean);

const Rule: React.FC<{double?: boolean; m: number; color?: string}> = ({double, m, color = INK}) => (
  <div style={{borderTop: `${double ? 3 : 1}px ${double ? 'double' : 'solid'} ${color}`, margin: `${m}px 0`}} />
);

// Photo slot: a rights-cleared asset, or a bundled backdrop printed as a halftone. Nothing is shown when neither is given.
const Photo: React.FC<{image: any; u: number; ratio?: string}> = ({image, u, ratio = '3 / 2'}) => {
  if (!image) return null;
  const asset = image.asset_id ? ((build as any).assets ?? {})[image.asset_id] : null;
  const plate = !asset && ATMOSPHERES.includes(image.atmosphere) ? `atmosphere/${image.atmosphere}.webp` : null;
  const src = asset?.kind === 'image' ? asset.file : plate;
  if (!src) return null;
  return (
    <div style={{marginBottom: u * 0.5}}>
      <div style={{position: 'relative', aspectRatio: image.ratio ?? ratio, overflow: 'hidden', border: `1px solid ${INK}`}}>
        <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'grayscale(1) contrast(1.35) brightness(1.05)'}} />
        <div style={{position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(rgba(20,16,10,0.5) 35%, transparent 48%)', backgroundSize: `${Math.max(2.4, u * 0.13)}px ${Math.max(2.4, u * 0.13)}px`, mixBlendMode: 'multiply'}} />
        <div style={{position: 'absolute', inset: 0, background: 'rgba(217,205,184,0.18)'}} />
      </div>
      {image.caption_ar ? <div style={{fontFamily: fontFor('Amiri'), fontSize: u * 0.62, lineHeight: 1.5, textAlign: 'center', marginTop: u * 0.2, opacity: 0.9}}>{image.caption_ar}</div> : null}
    </div>
  );
};

const Body: React.FC<{clip: any; u: number; columns: number; size?: number}> = ({clip, u, columns, size = 0.7}) => {
  const paras = paragraphs(clip.body_ar);
  if (!paras.length) {
    if (clip.filler_lines === false) return null;
    // No body text given: neutral grey lines stand in for print. They carry no words.
    return (
      <div style={{display: 'grid', gridTemplateColumns: `repeat(${columns}, 1fr)`, gap: u * 0.8}}>
        {Array.from({length: columns}).map((_, c) => (
          <div key={c}>{Array.from({length: 7}).map((__, r) => <div key={r} style={{height: u * 0.16, margin: `${u * 0.3}px 0`, background: 'rgba(29,24,18,0.3)', width: `${97 - ((c * 2 + r) % 4) * 7}%`}} />)}</div>
        ))}
      </div>
    );
  }
  return (
    <div style={{columnCount: columns, columnGap: u * 0.9, columnRule: columns > 1 ? `1px solid rgba(29,24,18,0.35)` : undefined, fontFamily: fontFor('Amiri'),
      fontSize: u * size, lineHeight: 1.62, textAlign: 'justify'}}>
      {clip.dateline_ar ? <span style={{fontWeight: 700}}>{clip.dateline_ar} — </span> : null}
      {paras.map((p, i) => <p key={i} style={{margin: 0, marginBottom: u * 0.35, textIndent: i ? u * 0.8 : 0, display: i ? 'block' : 'inline'}}>{p}</p>)}
      {clip.byline_ar ? <div style={{fontWeight: 700, textAlign: 'left', marginTop: u * 0.2}}>{clip.byline_ar}</div> : null}
    </div>
  );
};

// Headline with an optional grease-pencil underline under highlight_ar, drawn in over time.
const Headline: React.FC<{clip: any; size: number; color?: string; align?: 'center' | 'right'; local: number}> = ({clip, size, color = INK, align = 'center', local}) => {
  const text: string = clip.headline_ar ?? '';
  const mark: string | null = clip.highlight_ar && text.includes(clip.highlight_ar) ? clip.highlight_ar : null;
  const p = interpolate(local, [14, 30], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const style: React.CSSProperties = {fontFamily: fontFor('Amiri'), fontWeight: 700, fontSize: size, lineHeight: 1.28, color, textAlign: align};
  if (!mark) return <div style={style}>{text}</div>;
  const [before, ...rest] = text.split(mark);
  return (
    <div style={style}>
      {before}
      <span style={{position: 'relative', display: 'inline-block'}}>
        {mark}
        <span style={{position: 'absolute', right: '-3%', bottom: '-2%', height: size * 0.09, width: `${p * 106}%`, background: '#B3201A', borderRadius: size, transform: 'rotate(-1.2deg)', opacity: 0.85}} />
      </span>
      {rest.join(mark)}
    </div>
  );
};

const Meta: React.FC<{right?: string; left?: string; u: number}> = ({right, left, u}) =>
  right || left ? (
    <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: fontFor('Amiri'), fontSize: u * 0.62, lineHeight: 1.5}}>
      <span>{right ?? ''}</span>
      <span>{left ?? ''}</span>
    </div>
  ) : null;

const Kicker: React.FC<{text?: string; u: number; boxed?: boolean}> = ({text, u, boxed}) =>
  text ? (
    <div style={{textAlign: boxed ? 'right' : 'center', marginBottom: u * 0.2}}>
      <span style={{fontFamily: fontFor('Amiri'), fontWeight: 700, fontSize: u * (boxed ? 0.95 : 0.85), ...(boxed ? {background: RED, color: '#F3E9D4', padding: `0 ${u * 0.6}px`} : {borderBottom: `1px solid ${INK}`})}}>{text}</span>
    </div>
  ) : null;

const Layout: React.FC<{clip: any; template: string; u: number; local: number}> = ({clip, template, u, local}) => {
  const img = clip.image;
  const pos = img?.position ?? (template === 'photo_report' ? 'top' : 'right');
  const side = img && (pos === 'right' || pos === 'left');
  const cols = Math.min(3, Math.max(1, clip.columns ?? (template === 'column' || template === 'telegram' ? 1 : side ? 2 : 3)));

  if (template === 'telegram') {
    // Wire dispatch slip: ruled lines, boxed header fields.
    return (
      <div style={{border: `2px dashed rgba(29,24,18,0.55)`, padding: u * 0.9, fontFamily: fontFor('IBM Plex Sans Arabic')}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: `2px solid ${INK}`, paddingBottom: u * 0.3}}>
          <span style={{fontFamily: fontFor('Aref Ruqaa'), fontWeight: 700, fontSize: u * 1.7}}>{clip.masthead_ar ?? 'برقية'}</span>
          <span style={{fontSize: u * 0.62, textAlign: 'left', lineHeight: 1.5}}>{clip.issue_ar ?? ''}<br />{clip.date_ar ?? ''}</span>
        </div>
        {clip.dateline_ar ? <div style={{fontSize: u * 0.7, fontWeight: 700, marginTop: u * 0.4}}>{clip.dateline_ar}</div> : null}
        <div style={{margin: `${u * 0.4}px 0`}}><Headline clip={clip} size={u * 1.25} align="right" local={local} /></div>
        <div style={{fontSize: u * 0.78, lineHeight: 2.1, fontWeight: 400, backgroundImage: `repeating-linear-gradient(to bottom, transparent 0, transparent ${u * 0.78 * 2.1 - 1}px, rgba(29,24,18,0.3) ${u * 0.78 * 2.1 - 1}px, rgba(29,24,18,0.3) ${u * 0.78 * 2.1}px)`,
          minHeight: u * 0.78 * 2.1 * 3}}>
          {paragraphs(clip.body_ar).map((p, i) => <div key={i}>{p}</div>)}
        </div>
        {clip.byline_ar ? <div style={{fontSize: u * 0.66, fontWeight: 700, textAlign: 'left', marginTop: u * 0.3}}>{clip.byline_ar}</div> : null}
      </div>
    );
  }

  if (template === 'column') {
    // A single column cut out of a page.
    return (
      <>
        {img && !side ? <Photo image={img} u={u} ratio="4 / 3" /> : null}
        <Kicker text={clip.kicker_ar} u={u} />
        <Headline clip={clip} size={u * 1.55} align="right" local={local} />
        {clip.subhead_ar ? <div style={{fontFamily: fontFor('Amiri'), fontWeight: 700, fontSize: u * 0.86, lineHeight: 1.5, marginTop: u * 0.2}}>{clip.subhead_ar}</div> : null}
        <div style={{width: '34%', borderTop: `2px solid ${INK}`, margin: `${u * 0.5}px 0`}} />
        <Body clip={clip} u={u} columns={1} size={0.78} />
        {clip.masthead_ar || clip.date_ar ? (
          <div style={{fontFamily: fontFor('Amiri'), fontSize: u * 0.6, borderTop: `1px solid ${INK}`, marginTop: u * 0.5, paddingTop: u * 0.2, opacity: 0.85}}>
            {[clip.masthead_ar, clip.date_ar].filter(Boolean).join(' — ')}
          </div>
        ) : null}
      </>
    );
  }

  const masthead = clip.masthead_ar ? (
    template === 'front_page' ? (
      <>
        <Meta right={clip.issue_ar} left={clip.price_ar} u={u} />
        <div style={{fontFamily: fontFor('Aref Ruqaa'), fontWeight: 700, fontSize: u * 3.3, lineHeight: 1.45, textAlign: 'center'}}>{clip.masthead_ar}</div>
        {clip.motto_ar ? <div style={{fontFamily: fontFor('Amiri'), fontSize: u * 0.62, textAlign: 'center', marginTop: -u * 0.2}}>{clip.motto_ar}</div> : null}
        <Rule double m={u * 0.25} />
        <Meta right={clip.date_ar} left={clip.date_secondary_ar} u={u} />
        <Rule m={u * 0.25} />
      </>
    ) : (
      <>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
          <span style={{fontFamily: fontFor('Aref Ruqaa'), fontWeight: 700, fontSize: u * 1.5}}>{clip.masthead_ar}</span>
          <span style={{fontFamily: fontFor('Amiri'), fontSize: u * 0.62}}>{[clip.date_ar, clip.issue_ar].filter(Boolean).join(' · ')}</span>
        </div>
        <Rule m={u * 0.25} />
      </>
    )
  ) : clip.date_ar ? (
    <><Meta right={clip.date_ar} left={clip.date_secondary_ar} u={u} /><Rule m={u * 0.25} /></>
  ) : null;

  const head =
    template === 'banner' ? (
      <>
        <Kicker text={clip.kicker_ar} u={u} boxed />
        <Headline clip={clip} size={u * 3.2} color={RED} local={local} />
      </>
    ) : (
      <>
        <Kicker text={clip.kicker_ar} u={u} />
        <Headline clip={clip} size={u * (template === 'photo_report' ? 1.9 : 2.5)} local={local} />
      </>
    );
  const sub = clip.subhead_ar ? <div style={{fontFamily: fontFor('Amiri'), fontWeight: 700, fontSize: u * 0.95, lineHeight: 1.5, textAlign: 'center', marginTop: u * 0.15}}>{clip.subhead_ar}</div> : null;
  const gap = <div style={{height: u * 0.45}} />;

  if (template === 'photo_report') {
    return (
      <>
        {masthead}
        <Photo image={img} u={u} ratio="16 / 10" />
        {head}
        {sub}
        {gap}
        <Body clip={clip} u={u} columns={Math.min(2, cols)} />
      </>
    );
  }
  return (
    <>
      {masthead}
      {head}
      {sub}
      {gap}
      {template === 'banner' ? <Rule double m={u * 0.3} color={RED} /> : null}
      {img && !side ? <Photo image={img} u={u} ratio="21 / 9" /> : null}
      {side ? (
        <div style={{display: 'flex', flexDirection: pos === 'right' ? 'row' : 'row-reverse', gap: u * 0.9}}>
          <div style={{flex: '0 0 42%'}}><Photo image={img} u={u} /></div>
          <div style={{flex: 1, minWidth: 0}}><Body clip={clip} u={u} columns={cols} /></div>
        </div>
      ) : (
        <Body clip={clip} u={u} columns={cols} />
      )}
    </>
  );
};

// One clipping at a given width. Height follows the content up to maxH; longer text is torn off like a real cutting.
export const Clipping: React.FC<{clip: any; width: number; maxHeight: number; seed: number; delay?: number}> = ({clip, width, maxHeight, seed, delay = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const template = CLIPPING_TEMPLATES.includes(clip.template) ? clip.template : 'front_page';
  const local = frame - delay;
  const enter = spring({frame: local, fps, config: {damping: 18, mass: 0.7}, durationInFrames: 22});
  const u = width * (template === 'column' ? 0.058 : template === 'telegram' ? 0.036 : 0.03);
  const decor: string[] = clip.decor ? Object.keys(clip.decor).filter((k) => clip.decor[k]) : SPEC[template].decor;
  const rot = clip.rotate_deg ?? ((seed % 5) - 2) * 0.9;
  const paper = PAPER[clip.paper] ?? PAPER.aged;
  return (
    <div style={{position: 'relative', width, opacity: Math.min(1, Math.max(0, enter)), transform: `translateY(${(1 - enter) * -50}px) rotate(${rot + (1 - enter) * 4}deg)`,
      filter: 'drop-shadow(0 12px 22px rgba(0,0,0,0.65))'}}>
      <div dir="rtl" lang="ar" style={{direction: 'rtl', position: 'relative', background: paper, backgroundImage: HALFTONE, backgroundSize: '5px 5px', color: INK,
        padding: `${u * 1.3}px ${u * 1.4}px ${u * 1.6}px`, maxHeight, overflow: 'hidden', clipPath: tornClip(seed * 13 + 3, template === 'column' ? 26 : 54, template === 'column' ? 2.2 : 3)}}>
        <Layout clip={clip} template={template} u={u} local={local} />
        {decor.includes('fold') ? <div style={{position: 'absolute', left: 0, right: 0, top: '52%', height: u * 0.5, background: 'linear-gradient(to bottom, rgba(0,0,0,0), rgba(0,0,0,0.13), rgba(255,255,255,0.12), rgba(0,0,0,0))'}} /> : null}
        <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 40%, rgba(0,0,0,0) 55%, rgba(90,60,20,0.22) 100%)', pointerEvents: 'none'}} />
        {decor.includes('stamp') ? <ArchiveStamp size={width * 0.24} font={fontFor('IBM Plex Sans Arabic')} style={{left: u * 1.2, bottom: u * 1.2, transform: 'rotate(-14deg)'}} /> : null}
      </div>
      {decor.includes('tape') ? <Tape size={width * 0.07} style={{left: '50%', marginLeft: -width * 0.09, top: -width * 0.03, transform: `rotate(${-rot * 2 - 2}deg)`}} /> : null}
      {decor.includes('paperclip') ? <Paperclip size={width * 0.15} style={{left: '47%', top: -width * 0.06, transform: 'rotate(7deg)'}} /> : null}
    </div>
  );
};

// Lays out one to three clippings on the frame. `compact` leaves the left and centre free for archival prints.
export const ClippingBoard: React.FC<{shot: any; durationInFrames: number; compact?: boolean}> = ({shot, durationInFrames, compact}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const list: any[] = (Array.isArray(shot.clippings) && shot.clippings.length ? shot.clippings : shot.clipping ? [shot.clipping] : []).slice(0, 3);
  if (!list.length) return null;
  const base = Math.min(width, height * 1.7);
  const push = interpolate(frame, [0, durationInFrames], [1, 1.035], {extrapolateRight: 'clamp'});
  const tpl = (c: any) => (CLIPPING_TEMPLATES.includes(c.template) ? c.template : 'front_page');
  // Pieces are placed left to right inside the area that stays clear of the presenter, and shrunk together if they do not fit.
  const tops = [0.07, 0.13, 0.2];
  const areaX = width * (list.length === 1 ? 0.2 : 0.15), areaW = width * (list.length === 1 ? 0.7 : 0.82), gap = width * 0.022;
  let widths = list.map((c, i) => base * SPEC[tpl(c)].w * (list.length === 1 ? 1 : i === 0 ? 0.86 : 0.8));
  const total = widths.reduce((a, b) => a + b, 0) + gap * (list.length - 1);
  if (total > areaW) widths = widths.map((w) => (w * (areaW - gap * (list.length - 1))) / (total - gap * (list.length - 1)));
  const used = widths.reduce((a, b) => a + b, 0) + gap * (list.length - 1);
  let x = areaX + (areaW - used) / 2;
  const placed = list.map((clip, i) => {
    const item = {clip, w: widths[i], left: x, top: height * tops[i]};
    x += widths[i] + gap;
    return item;
  });
  const shown = compact ? [{clip: list[0], w: base * SPEC[tpl(list[0])].w * 0.62, left: width * 0.82 - (base * SPEC[tpl(list[0])].w * 0.62) / 2, top: height * 0.16}] : placed;
  return (
    <div style={{position: 'absolute', inset: 0, transform: `scale(${push})`, transformOrigin: '55% 40%'}}>
      {shown.map(({clip, w, left, top}, i) => (
        <div key={i} style={{position: 'absolute', left, top}}>
          <Clipping clip={clip} width={w} maxHeight={height * SPEC[tpl(clip)].maxH} seed={i + 1 + (clip.headline_ar?.length ?? 0)} delay={i * 9} />
        </div>
      ))}
    </div>
  );
};
