import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {styleTheme} from '../theme';
import {fontFor} from '../fonts';

// Name strip for a person or place: shot.lower_third = {name_ar, role_ar}. Shown from 0.4 s into the shot.
export const LowerThird: React.FC<{shot: any; durationInFrames: number}> = ({shot, durationInFrames}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const lt = shot.lower_third;
  if (!lt?.name_ar) return null;
  const theme = styleTheme(shot.style_id);
  const unit = Math.min(width, height);
  const start = fps * 0.4;
  const p = Math.min(interpolate(frame, [start, start + 12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}),
    interpolate(frame, [durationInFrames - 10, durationInFrames - 2], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  const look: React.CSSProperties =
    theme.kind === 'tactical'
      ? {background: theme.card, borderRight: `${unit * 0.008}px solid ${theme.accent}`, color: '#fff'}
      : theme.kind === 'archival'
        ? {background: theme.card, color: theme.cardText, transform: 'rotate(-1deg)', boxShadow: '0 5px 12px rgba(0,0,0,0.55)'}
        : {background: 'rgba(20,16,12,0.86)', borderRight: `${unit * 0.008}px solid ${theme.accent}`, color: '#F4E9D2'};
  return (
    <div dir="rtl" style={{position: 'absolute', right: width * 0.04, bottom: height * 0.3, direction: 'rtl', opacity: p, clipPath: `inset(0 0 0 ${(1 - p) * 100}%)`,
      padding: `${unit * 0.012}px ${unit * 0.03}px`, fontFamily: fontFor(theme.font), ...look}}>
      <div style={{fontWeight: 700, fontSize: unit * 0.04, lineHeight: 1.35}}>{lt.name_ar}</div>
      {lt.role_ar ? <div style={{fontWeight: 400, fontSize: unit * 0.027, opacity: 0.85}}>{lt.role_ar}</div> : null}
    </div>
  );
};
