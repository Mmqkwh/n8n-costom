import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import mapData from '../data/map-data.json';
import basemaps from '../data/basemap.json';
import waters from '../data/water.json';
import build from '../data/build.json';
import {Pt, arcPoints, cameraAt, geodesicCircle, headAt, makeProjector, polygonPath, rand, revealWindow, smooth, taperedArrow, ticks, toPath, truncate, wobble} from '../geo';
import {sideColors, styleTheme} from '../theme';
import {fontFor} from '../fonts';
import {Icon, Sprite} from './Icon';
import {ArchiveStamp, Clouds, Desk, FilmOverlay, FilmStrip, HudFrame, Paperclip, Parchment, Tape, Vignette, weave} from './Texture';
import {AtmosphereBand} from './Atmosphere';
import {MapFurniture} from './MapFurniture';

const ARROW_SCALE: Record<string, number> = {main: 1, secondary: 0.62, flank: 0.8, retreat: 0.7};
const POINT_TYPES = ['pin', 'label', 'unit', 'event', 'icon'];
const isPoint = (l: any) => POINT_TYPES.includes(l.type);
// Bundled generic silhouettes (public/silhouettes), tinted by side colour. No markings or insignia.
const SILHOUETTE: Record<string, string> = {armor: 'tank', infantry: 'infantry', artillery: 'artillery', air: 'aircraft', naval: 'ship'};

export const mapFor = (shot: any) => {
  const all = (mapData as any).maps ?? {default: mapData};
  return all[shot.map_id ?? 'default'] ?? all.default;
};
export const mapLayers = (shot: any) => (mapFor(shot).layers ?? []).filter((l: any) => !l.shot_ids?.length || l.shot_ids.includes(shot.shot_id));

// Draws ONLY what production/map-data.json holds, in the look of the chosen visual style
// (libraries/style-specs.yaml). It never adds geography, arrows or labels of its own.
export const MapShot: React.FC<{shot: any; durationInFrames: number}> = ({shot, durationInFrames}) => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const mapId = shot.map_id ?? 'default';
  const md = mapFor(shot);
  const theme = styleTheme(shot.style_id);
  const kind = theme.kind;
  const sat = md.render?.satellite ?? null;       // a real picture of the earth as the base
  const neon = kind === 'tactical';               // tactical and satellite looks: glow instead of ink
  const clean = Boolean(theme.sat);               // satellite look: no grid, no scanlines

  // Archival style shows the map as a paper sheet lying on the desk; the others fill the frame.
  const card = kind === 'archival' ? {x: width * 0.09, y: height * 0.06, w: width * 0.82, h: height * 0.7} : {x: 0, y: 0, w: width, h: height};
  const unit = Math.min(card.w, card.h);
  // With a backdrop band the map is fitted into the upper 70% so the band never hides map data.
  const fitH = kind === 'cinematic' && shot.atmosphere ? card.h * 0.7 : card.h;
  const {project, pxPerKm} = makeProjector(md.projection?.bbox ?? [0, 0, 10, 10], card.w, fitH, unit * 0.07, sat ? 'mercator' : 'equirectangular');

  const layers: any[] = mapLayers(shot);
  const cam = shot.camera ?? {};
  // Camera: either one eased push toward a focus, or a path of keyframes that flies between places.
  let zoom: number, transform: string, origin: string;
  if (Array.isArray(cam.path) && cam.path.length) {
    const now = cameraAt(cam.path, frame / fps);
    zoom = now.scale;
    const [cx, cy] = project(now.focus);
    transform = `translate(${card.w / 2 - cx * zoom}px, ${fitH / 2 - cy * zoom}px) scale(${zoom})`;
    origin = '0 0';
  } else {
    zoom = interpolate(frame, [0, durationInFrames], [cam.scale_start ?? 1, cam.scale_end ?? 1.08], {easing: Easing.inOut(Easing.ease), extrapolateRight: 'clamp'});
    const [fx, fy] = cam.focus ? project(cam.focus) : [card.w / 2, fitH / 2];
    transform = `scale(${zoom})`;
    origin = `${fx}px ${fy}px`;
  }
  // Everything drawn on the map keeps its on-screen size while the camera zooms.
  const U = unit / zoom;

  const reveal = (layer: any, index: number) => {
    const [start, end] = revealWindow(layer, index, layers.length, durationInFrames, fps);
    return interpolate(frame, [start, end], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.ease)});
  };

  const sw = U * 0.005;
  const uid = String(shot.shot_id).replace(/[^a-zA-Z0-9]/g, '');
  const features: any[] = ((basemaps as any)[mapId] ?? (basemaps as any)).features ?? [];
  // No basemap given: the whole sheet is treated as land (plain paper), never as invented coastline.
  const landPath = features.length ? features.map((f) => polygonPath(f.geometry, project)).join(' ') : `M0 0 H${card.w} V${card.h} H0 Z`;
  const water = (waters as any)[mapId] ?? (waters as any);
  const lakePath = (water.lakes?.features ?? []).map((f: any) => polygonPath(f.geometry, project)).join(' ');
  const rivers: {d: string; rank: number}[] = (water.rivers?.features ?? []).map((f: any) => ({
    rank: f.properties?.rank ?? 6,
    d: (f.geometry?.coordinates ?? []).map((line: Pt[]) => toPath(line.map(project))).join(' '),
  }));
  const boxOf = (b: number[]) => {
    const [x0, y0] = project([b[0], b[3]]);
    const [x1, y1] = project([b[2], b[1]]);
    return {x: x0, y: y0, w: x1 - x0, h: y1 - y0};
  };
  const relief = md.render?.relief ?? null;
  const reliefBox = relief ? boxOf(relief.bbox) : null;
  const satBox = sat ? boxOf(sat.bbox) : null;
  const waterColor = kind === 'cinematic' ? theme.sea : neon ? '#0B2A3A' : '#B9C2C4';
  const riverColor = sat ? 'rgba(120,190,255,0.7)' : kind === 'cinematic' ? '#35596A' : neon ? 'rgba(0,229,255,0.55)' : '#4A5F78';
  const glow = (c: string, k = 1) => (neon ? {filter: `drop-shadow(0 0 ${U * 0.008 * k}px ${c})`} : {});
  const march = -(frame * U * 0.0016);   // marching dashes

  const drawLayer = (l: any, i: number) => {
    const p = reveal(l, i);
    if (p <= 0 || isPoint(l)) return null;
    const [c, cDark] = sideColors(l.color, theme);

    if (l.type === 'country') {
      // Modern country outline from the bundled list: tinted fill with a glowing or marching border.
      if (!l.geometry) return null;
      const d = polygonPath(l.geometry, project);
      const border = l.border ?? 'glow';
      return (
        <g key={i} opacity={p}>
          <path d={d} fill={c} fillOpacity={(l.fill_opacity ?? 0.26) * (sat ? 1.15 : 1)} fillRule="evenodd" />
          <path d={d} fill="none" stroke={border === 'glow' ? '#FFFFFF' : c} strokeWidth={sw * (border === 'glow' ? 0.7 : 1)} strokeLinejoin="round"
            strokeDasharray={border === 'marching' ? `${sw * 4} ${sw * 3}` : undefined} strokeDashoffset={border === 'marching' ? march : undefined}
            style={{filter: `drop-shadow(0 0 ${U * (border === 'glow' ? 0.012 : 0.006)}px ${c})`}} />
        </g>
      );
    }

    if (l.type === 'range') {
      // Ground-distance ring growing out of a place, e.g. a declared missile range.
      const ring = geodesicCircle(l.center, l.radius_km * p).map(project);
      const d = toPath(ring, true);
      return (
        <g key={i} style={glow(c)}>
          <path d={d} fill={c} fillOpacity={0.08} />
          <path d={d} fill="none" stroke={c} strokeWidth={sw * 1.1} strokeDasharray={`${sw * 5} ${sw * 3}`} strokeDashoffset={march} />
        </g>
      );
    }

    if (l.type === 'arc') {
      // Curved trajectory between two places with travelling dashes.
      const part = truncate(arcPoints(project(l.from), project(l.to), l.height ?? 0.22), p);
      if (part.length < 2) return null;
      const dashed = l.dashed !== false;
      return (
        <g key={i} style={{filter: `drop-shadow(0 0 ${U * 0.009}px ${c})`}}>
          <path d={toPath(part)} fill="none" stroke={c} strokeWidth={sw * 1.2} strokeLinecap="round" strokeDasharray={dashed ? `${sw * 4} ${sw * 3}` : undefined}
            strokeDashoffset={dashed ? march : undefined} />
          <path d={headAt(part, U * 0.022, false)} fill={c} stroke={c} strokeWidth={sw * 0.6} strokeLinejoin="round" />
        </g>
      );
    }

    const pts: Pt[] = l.coordinates.map(project);

    if (l.type === 'zone') {
      const d = toPath(kind === 'archival' ? wobble(pts, U * 0.002) : pts, true);
      const s = U * 0.014;
      return (
        <g key={i} opacity={p}>
          <defs>
            <pattern id={`hatch-${uid}-${i}`} patternUnits="userSpaceOnUse" width={s} height={s} patternTransform="rotate(45)">
              <line x1={0} y1={0} x2={0} y2={s} stroke={kind === 'cinematic' ? cDark : c} strokeWidth={s * 0.22} />
            </pattern>
          </defs>
          <path d={d} fill={c} fillOpacity={neon ? 0.14 : 0.1} />
          <path d={d} fill={`url(#hatch-${uid}-${i})`} fillOpacity={neon ? 0.4 : 0.5} stroke={kind === 'cinematic' ? cDark : c}
            strokeWidth={sw * 0.7} strokeDasharray={l.accuracy === 'approximate' ? `${sw * 2.5} ${sw * 2}` : undefined} style={glow(c)} />
        </g>
      );
    }

    if (l.type === 'front_line') {
      const line = smooth(pts, 8);
      if (kind === 'cinematic') {
        return (
          <g key={i} opacity={p}>
            <path d={toPath(line)} fill="none" stroke={cDark} strokeWidth={sw * 1.25} strokeLinejoin="round" strokeLinecap="round" />
            <path d={ticks(line, U * 0.022, U * 0.014)} fill="none" stroke={cDark} strokeWidth={sw} strokeLinecap="round" />
          </g>
        );
      }
      if (neon) {
        return <path key={i} d={toPath(line)} fill="none" stroke={c} strokeWidth={sw * (clean ? 0.9 : 1)} strokeLinejoin="round" opacity={p} style={glow(c, 1.4)} />;
      }
      return <path key={i} d={toPath(wobble(line, U * 0.003))} fill="none" stroke={c} strokeWidth={sw * 1.5} strokeLinejoin="round" strokeLinecap="round"
        strokeDasharray={`${sw * 5} ${sw * 1.6}`} opacity={p * 0.95} />;
    }

    if (l.type === 'route') {
      const k = ARROW_SCALE[l.arrow_style] ?? 1;
      const retreat = l.arrow_style === 'retreat';
      const part = truncate(smooth(pts, l.arrow_style === 'flank' ? 20 : 14), p);
      if (part.length < 2) return null;
      // Tapered filled arrow: the cinematic look, and the satellite look (solid shapes read best on a photo).
      if ((kind === 'cinematic' || clean) && !retreat) {
        const a = pts[0], b = pts[pts.length - 1];
        return (
          <g key={i} style={{filter: clean ? `drop-shadow(0 0 ${U * 0.01}px ${c})` : `drop-shadow(${U * 0.003}px ${U * 0.005}px ${U * 0.005}px rgba(0,0,0,0.55))`}}>
            <defs>
              <linearGradient id={`arr-${uid}-${i}`} gradientUnits="userSpaceOnUse" x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]}>
                <stop offset="0" stopColor={cDark} stopOpacity={clean ? 0.55 : 1} /><stop offset="1" stopColor={c} />
              </linearGradient>
            </defs>
            <path d={taperedArrow(part, U * 0.008 * k, U * 0.03 * k, U * 0.062 * k, U * 0.058 * k)} fill={`url(#arr-${uid}-${i})`}
              stroke={clean ? 'rgba(255,255,255,0.75)' : cDark} strokeWidth={Math.max(1, sw * 0.25)} strokeLinejoin="round" />
          </g>
        );
      }
      const line = kind === 'archival' ? wobble(part, U * 0.0025) : part;
      const w = (kind === 'archival' ? sw * 1.5 : neon ? sw * 0.9 : sw * 1.6) * (0.6 + 0.4 * k);
      const dash = neon ? `${sw * 3} ${sw * (retreat ? 4 : 2.2)}` : retreat ? `${sw * 3.5} ${sw * 2.5}` : undefined;
      return (
        <g key={i} opacity={retreat ? 0.85 : 1} style={glow(c)}>
          <path d={toPath(line)} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={dash} strokeDashoffset={neon ? march : undefined} />
          <path d={headAt(line, U * 0.028 * (0.7 + 0.3 * k), kind !== 'cinematic')} fill={kind === 'cinematic' ? c : 'none'} stroke={c} strokeWidth={w}
            strokeLinecap="round" strokeLinejoin="round" />
        </g>
      );
    }
    return null;
  };

  const drawPoint = (l: any, i: number) => {
    const p = reveal(l, i);
    if (p <= 0 || l.type !== 'pin') return null;
    const [c] = sideColors(l.color, theme);
    const [x, y] = project(l.coordinates);
    const pulse = 1 + 0.3 * Math.sin((frame / fps) * Math.PI * 2);
    const r = U * 0.008;
    return (
      <g key={`p${i}`} opacity={p} transform={`translate(${x} ${y}) scale(${0.6 + 0.4 * p})`}>
        {kind === 'cinematic' ? <circle r={r} fill="#FFFFFF" stroke="#222222" strokeWidth={r * 0.45} /> : null}
        {neon && !clean ? <rect x={-r * 0.8} y={-r * 0.8} width={r * 1.6} height={r * 1.6} fill="#FFFFFF" style={glow('#FFFFFF')} /> : null}
        {clean ? <circle r={r * 0.9} fill="#FFFFFF" stroke={c} strokeWidth={r * 0.5} style={glow(c)} /> : null}
        {kind === 'archival' ? <circle r={r * 0.8} fill={c} /> : null}
        {l.emphasis && kind === 'cinematic' ? <circle r={r * 2.4 * pulse} fill="none" stroke={theme.accent} strokeWidth={r * 0.4} opacity={0.85} /> : null}
        {l.emphasis && neon && !clean ? (
          <g stroke={c} fill="none" strokeWidth={r * 0.3} style={glow(c)}>
            <circle r={r * 3.2} strokeDasharray={`${r} ${r * 0.7}`} transform={`rotate(${(frame * 1.5) % 360})`} />
            <circle r={r * 2} opacity={0.6 + 0.4 * (pulse - 1) / 0.3} />
            <path d={`M${-r * 4.6} 0 h${r * 1.2} M${r * 3.4} 0 h${r * 1.2} M0 ${-r * 4.6} v${r * 1.2} M0 ${r * 3.4} v${r * 1.2}`} />
          </g>
        ) : null}
        {l.emphasis && clean
          ? [0, 1, 2].map((n) => {
              // radar shockwaves: three rings expanding and fading, one after another
              const ph = ((frame / fps) * 0.7 + n / 3) % 1;
              return <circle key={n} r={r * (1.5 + ph * 7)} fill="none" stroke={c} strokeWidth={r * 0.35} opacity={(1 - ph) * 0.9} style={glow(c)} />;
            })
          : null}
        {l.emphasis && kind === 'archival' ? (
          <ellipse rx={r * 3.4} ry={r * 2.7} fill="none" stroke={theme.red} strokeWidth={r * 0.45} strokeDasharray={`${r * 30} ${r}`} transform="rotate(-12)" />
        ) : null}
      </g>
    );
  };

  const labelBase: React.CSSProperties = {position: 'absolute', transform: 'translate(-50%, -50%)', direction: 'rtl', whiteSpace: 'nowrap', fontFamily: fontFor(theme.font), fontWeight: 700};
  const labelLook = (i: number): React.CSSProperties =>
    kind === 'cinematic'
      ? {fontSize: U * 0.027, color: theme.label, textShadow: '0 0 5px #F6EBD0, 0 0 5px #F6EBD0, 0 0 9px #F6EBD0'}
      : clean
        ? {fontSize: U * 0.026, color: '#FFFFFF', background: 'rgba(6,10,16,0.62)', borderRadius: U * 0.006, padding: `${U * 0.002}px ${U * 0.012}px`, textShadow: '0 1px 2px #000'}
        : neon
          ? {fontSize: U * 0.021, color: theme.label, background: theme.labelBg, borderRight: `${Math.max(1, U * 0.003)}px solid ${theme.accent}`, padding: `${U * 0.001}px ${U * 0.01}px`, letterSpacing: '0.02em'}
          : {fontSize: U * 0.023, color: theme.label, background: theme.labelBg, padding: `${U * 0.001}px ${U * 0.012}px`, boxShadow: '0 2px 5px rgba(0,0,0,0.35)',
              transform: `translate(-50%, -50%) rotate(${(rand(i + 3) - 0.5) * 4}deg)`};
  const stacked = (i: number): React.CSSProperties => ({...labelBase, ...labelLook(i), position: 'static', transform: 'none'});

  const drawLabel = (l: any, i: number) => {
    const p = reveal(l, i);
    if (p <= 0) return null;
    const [c, cDark] = sideColors(l.color, theme);
    const text = l.label_ar ? `${l.label_ar}${l.accuracy === 'approximate' ? ' (تقريبي)' : ''}` : null;

    if (l.type === 'arc') {
      // Optional sprite riding the tip of the arc while it draws, and a label at the destination.
      const pts = arcPoints(project(l.from), project(l.to), l.height ?? 0.22);
      const tip = truncate(pts, p).slice(-1)[0];
      const end = pts[pts.length - 1];
      return (
        <React.Fragment key={`t${i}`}>
          {l.icon && p < 1 ? (
            <div style={{position: 'absolute', left: tip[0], top: tip[1], transform: 'translate(-50%, -60%)'}}><Sprite name={l.icon} size={U * 0.075} /></div>
          ) : null}
          {text ? <div style={{...labelBase, ...labelLook(i), left: end[0], top: end[1] - U * 0.04, opacity: Math.max(0, p * 2 - 1)}}>{text}</div> : null}
        </React.Fragment>
      );
    }
    if (l.type === 'range') {
      const top = project(geodesicCircle(l.center, l.radius_km * p, 4)[0]);
      const label = l.label_ar ?? `${Number(l.radius_km).toLocaleString('en-US')} كم`;
      return <div key={`t${i}`} style={{...labelBase, ...labelLook(i), left: top[0], top: top[1] - U * 0.03, opacity: p, fontSize: U * 0.03, color: neon ? c : theme.label}}>{label}</div>;
    }
    if (l.type === 'country') {
      if (!text || !l.label_at) return null;
      const [x, y] = project(l.label_at);
      return <div key={`t${i}`} style={{...labelBase, ...labelLook(i), left: x, top: y, opacity: p, fontSize: U * 0.034, fontWeight: 900}}>{text}</div>;
    }

    const anchor: Pt = l.label_at ?? (isPoint(l) ? l.coordinates : l.coordinates[Math.floor(l.coordinates.length / 2)]);
    const [x, y] = project(anchor);
    const iconSize = U * (l.type === 'unit' ? 0.06 : 0.05);

    if (l.type === 'icon') {
      // 3D sprite icon standing on the map: pops in, with an optional label under it.
      const s = U * 0.11 * (l.icon_scale ?? 1);
      const pop = p < 1 ? 0.5 + 0.62 * p - 0.12 * Math.sin(p * Math.PI) : 1;
      const tone = kind === 'archival' ? 'sepia(0.85) contrast(0.95)' : neon ? `drop-shadow(0 0 ${U * 0.008}px rgba(${clean ? '0,0,0,0.8' : '0,229,255,0.55'}))` : 'drop-shadow(0 6px 8px rgba(0,0,0,0.5))';
      return (
        <div key={`t${i}`} style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -62%) scale(${pop})`, opacity: Math.min(1, p * 2),
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: U * 0.004}}>
          {/* your own picture or icon (asset_id) instead of a bundled sprite */}
          {l.asset_id && ((build as any).assets ?? {})[l.asset_id]
            ? <Img src={staticFile(((build as any).assets ?? {})[l.asset_id].file)} style={{width: s * 1.25, height: s * 1.25, objectFit: 'contain', filter: tone,
                ...(l.framed ? {objectFit: 'cover', borderRadius: '50%', border: `${Math.max(2, U * 0.004)}px solid #fff`} : {})}} />
            : <Sprite name={l.icon} size={s} style={{filter: tone}} />}
          {text ? <div style={stacked(i)}>{text}</div> : null}
        </div>
      );
    }
    if (l.type === 'label' && l.kind === 'water' && text) {
      const wc = kind === 'cinematic' ? '#D6E6EA' : clean ? 'rgba(200,225,255,0.85)' : neon ? 'rgba(0,229,255,0.7)' : '#3F566E';
      return <div key={`t${i}`} style={{...labelBase, left: x, top: y, opacity: p * 0.9, fontWeight: 400, fontSize: U * 0.034, color: wc,
        textShadow: kind === 'archival' ? 'none' : '0 1px 3px rgba(0,0,0,0.6)'}}>{l.label_ar}</div>;
    }
    if (l.type === 'unit' && (l.display === 'silhouette' || l.display === 'card') && SILHOUETTE[l.symbol]) {
      const sil = staticFile(`silhouettes/${SILHOUETTE[l.symbol]}.png`);
      const flag = l.flag_asset_id ? ((build as any).assets ?? {})[l.flag_asset_id] : null;
      const sw2 = U * (l.display === 'card' ? 0.085 : 0.1);
      const shape = (color: string) => (
        <div style={{width: sw2, height: sw2 * 0.5, background: color, WebkitMaskImage: `url(${sil})`, maskImage: `url(${sil})`, WebkitMaskSize: 'contain', maskSize: 'contain',
          WebkitMaskRepeat: 'no-repeat', maskRepeat: 'no-repeat', WebkitMaskPosition: 'center', maskPosition: 'center', transform: l.facing === 'left' ? 'scaleX(-1)' : undefined}} />
      );
      return (
        <div key={`t${i}`} style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) scale(${0.7 + 0.3 * p})`, opacity: p, ...glow(c)}}>
          {l.display === 'card' ? (
            <div style={{display: 'flex', alignItems: 'center', gap: U * 0.01, direction: 'rtl', padding: `${U * 0.008}px ${U * 0.014}px`,
              background: neon ? 'rgba(10,20,30,0.9)' : kind === 'archival' ? '#EFE4CE' : `linear-gradient(180deg, ${c}, ${cDark})`,
              border: `${Math.max(1, U * 0.003)}px solid ${kind === 'cinematic' ? '#E8D9B5' : c}`, boxShadow: '0 4px 10px rgba(0,0,0,0.5)',
              transform: kind === 'archival' ? `rotate(${(rand(i + 5) - 0.5) * 4}deg)` : undefined}}>
              {flag ? <Img src={staticFile(flag.file)} style={{height: sw2 * 0.42, border: '1px solid rgba(0,0,0,0.4)'}} /> : null}
              {shape(kind === 'cinematic' ? '#F3E7CC' : c)}
              {text ? <span style={{fontFamily: fontFor(theme.font), fontWeight: 700, fontSize: U * 0.022, whiteSpace: 'nowrap',
                color: kind === 'cinematic' ? '#F3E7CC' : neon ? '#fff' : theme.cardText}}>{text}</span> : null}
            </div>
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: U * 0.004}}>
              <div style={{filter: kind === 'cinematic' ? 'drop-shadow(0 2px 2px rgba(0,0,0,0.45))' : undefined}}>{shape(kind === 'cinematic' ? cDark : c)}</div>
              {text ? <div style={stacked(i)}>{text}</div> : null}
            </div>
          )}
        </div>
      );
    }
    if (l.type === 'unit' || l.type === 'event') {
      return (
        <div key={`t${i}`} style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) scale(${0.7 + 0.3 * p})`, opacity: p, display: 'flex',
          flexDirection: 'column', alignItems: 'center', gap: U * 0.006, ...glow(c)}}>
          {l.type === 'event' ? (
            <div style={{width: iconSize * 1.5, height: iconSize * 1.5, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: neon ? 'rgba(10,20,30,0.9)' : kind === 'cinematic' ? 'rgba(240,226,196,0.92)' : '#EFE4CE', border: `${Math.max(1, U * 0.003)}px solid ${c}`,
              boxShadow: '0 2px 6px rgba(0,0,0,0.45)'}}>
              <Icon group="events" name={l.symbol} color={c} size={iconSize} />
            </div>
          ) : (
            <Icon group="units" name={l.symbol} color={c} size={iconSize} style={kind === 'cinematic' ? {filter: 'drop-shadow(0 2px 3px rgba(0,0,0,0.5))'} : undefined} />
          )}
          {text ? <div style={stacked(i)}>{text}</div> : null}
        </div>
      );
    }
    if (!text) return null;
    const dy = l.type === 'pin' && !l.label_at ? -U * (l.emphasis ? 0.06 : 0.036) : 0;
    return <div key={`t${i}`} style={{...labelBase, ...labelLook(i), left: x, top: y + dy, opacity: p}}>{text}</div>;
  };

  const inset = (shot.asset_ids ?? []).map((id: string) => ((build as any).assets ?? {})[id]).find((a: any) => a && a.kind === 'image');
  const jitter = kind === 'archival' ? weave(frame) : {x: 0, y: 0};
  // Optional orbital tilt: the map plane leans away from the viewer, with haze toward the horizon.
  const tilt = Math.max(0, Math.min(55, cam.tilt_deg ?? 0));

  const plane = (
    <div style={{position: 'absolute', inset: 0, transform, transformOrigin: origin}}>
      {kind === 'archival' && !sat ? <Parchment style={{filter: 'saturate(0.45) brightness(1.12)'}} /> : null}
      <svg width={card.w} height={card.h} viewBox={`0 0 ${card.w} ${card.h}`} style={{position: 'absolute', inset: 0, overflow: 'visible'}}>
        <defs>
          <clipPath id={`land-${uid}`}><path d={landPath} fillRule="evenodd" /></clipPath>
          <radialGradient id={`sea-${uid}`} cx="50%" cy="45%" r="75%">
            <stop offset="0" stopColor={theme.sea} /><stop offset="1" stopColor={theme.seaDeep} />
          </radialGradient>
        </defs>
        {sat && satBox ? (
          <image href={staticFile(sat.file)} x={satBox.x} y={satBox.y} width={satBox.w} height={satBox.h} preserveAspectRatio="none"
            style={kind === 'archival' ? {filter: 'grayscale(1) sepia(0.5) contrast(1.05)'} : undefined} />
        ) : (
          <>
            {kind !== 'archival' ? <rect x={-card.w} y={-card.h} width={card.w * 3} height={card.h * 3} fill={`url(#sea-${uid})`} /> : null}
            {kind === 'cinematic' ? (
              <>
                <path d={landPath} fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth={unit * 0.012} strokeLinejoin="round" />
                <image href={staticFile('textures/parchment.webp')} width={card.w} height={card.h} preserveAspectRatio="xMidYMid slice" clipPath={`url(#land-${uid})`} />
                <path d={landPath} fill="none" stroke={theme.coast} strokeWidth={1.6} strokeOpacity={0.8} />
              </>
            ) : null}
            {neon ? <path d={landPath} fill={theme.land} fillRule="evenodd" stroke={theme.coast} strokeOpacity={0.5} strokeWidth={1.4} style={glow(theme.coast)} /> : null}
            {kind === 'archival' ? <path d={landPath} fill="rgba(120,95,60,0.2)" fillRule="evenodd" stroke={theme.coast} strokeWidth={1.5} /> : null}
            {reliefBox ? (
              <image href={staticFile(relief.file)} x={reliefBox.x} y={reliefBox.y} width={reliefBox.w} height={reliefBox.h} preserveAspectRatio="none"
                clipPath={`url(#land-${uid})`} opacity={neon ? 0.85 : kind === 'archival' ? 0.6 : 0.75} style={{mixBlendMode: neon ? 'overlay' : 'multiply'}} />
            ) : null}
            {lakePath ? <path d={lakePath} fill={waterColor} fillRule="evenodd" stroke={theme.coast} strokeOpacity={neon ? 0.45 : 0.7} strokeWidth={1.1} /> : null}
          </>
        )}
        {rivers.map((r, i) => (
          <path key={`r${i}`} d={r.d} fill="none" stroke={riverColor} strokeWidth={sw * (r.rank <= 3 ? 0.75 : r.rank <= 6 ? 0.5 : 0.34)} strokeLinecap="round" strokeLinejoin="round" />
        ))}
        {layers.map(drawLayer)}
        {layers.map(drawPoint)}
      </svg>
      {layers.map(drawLabel)}
    </div>
  );

  const canvas = (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden', background: sat ? '#03090F' : theme.sea}}>
      {tilt ? (
        <div style={{position: 'absolute', inset: 0, perspective: card.h * 1.6, perspectiveOrigin: '50% 30%'}}>
          <div style={{position: 'absolute', inset: 0, transform: `rotateX(${tilt}deg) scale(${1 + tilt / 70})`, transformOrigin: '50% 85%'}}>{plane}</div>
        </div>
      ) : plane}
      {tilt ? <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: '38%', background: 'linear-gradient(to bottom, rgba(3,9,15,0.96), rgba(40,70,100,0.35) 70%, rgba(0,0,0,0))', pointerEvents: 'none'}} /> : null}
      {sat ? <div style={{position: 'absolute', inset: 0, background: 'rgba(4,10,18,0.2)', pointerEvents: 'none'}} /> : null}
      {sat && md.basemap?.clouds !== false && zoom < 2.2 ? <Clouds /> : null}
      {kind === 'cinematic' ? <Vignette strength={theme.vignette} warm /> : null}
      {neon ? <>{clean ? null : <HudFrame theme={theme} />}<Vignette strength={theme.vignette} /></> : null}
    </div>
  );

  return (
    <AbsoluteFill style={{backgroundColor: theme.seaDeep, overflow: 'hidden'}}>
      {kind === 'archival' ? (
        <>
          <Desk />
          <div style={{position: 'absolute', left: card.x + jitter.x, top: card.y + jitter.y, width: card.w, height: card.h, transform: 'rotate(-1.1deg)',
            boxShadow: '0 14px 34px rgba(0,0,0,0.7)', border: `${Math.round(unit * 0.012)}px solid #EFE4CE`, boxSizing: 'content-box'}}>
            {canvas}
            <Tape size={unit * 0.045} style={{left: -unit * 0.05, top: -unit * 0.02, transform: 'rotate(-38deg)'}} />
            <Tape size={unit * 0.045} style={{right: -unit * 0.05, top: -unit * 0.02, transform: 'rotate(36deg)'}} />
            <Paperclip size={unit * 0.11} style={{left: '30%', top: -unit * 0.05, transform: 'rotate(6deg)'}} />
            <ArchiveStamp size={unit * 0.17} font={fontFor(theme.font)} style={{left: unit * 0.03, bottom: unit * 0.03, transform: 'rotate(-12deg)'}} />
          </div>
          <Vignette strength={theme.vignette} />
          <FilmStrip />
        </>
      ) : (
        canvas
      )}
      {kind === 'cinematic' && shot.atmosphere ? <AtmosphereBand name={shot.atmosphere} kind={kind} durationInFrames={durationInFrames} /> : null}
      {inset ? (
        <div style={{position: 'absolute', left: width * 0.03, top: height * 0.17, width: width * 0.2, transform: 'rotate(-4deg)', background: '#EFE8D8',
          padding: unit * 0.008, boxShadow: '0 8px 20px rgba(0,0,0,0.6)'}}>
          <Img src={staticFile(inset.file)} style={{width: '100%', display: 'block', filter: neon ? 'none' : 'grayscale(0.85) sepia(0.25) contrast(1.05)'}} />
        </div>
      ) : null}
      <MapFurniture shot={shot} theme={theme} layers={layers} pxPerKm={pxPerKm * zoom} showScale={md.show_scale !== false} credit={sat?.credit ?? null} />
      {!neon ? <FilmOverlay grain={kind === 'archival' ? 0.14 : 0.08} scratches={kind === 'archival'} /> : null}
    </AbsoluteFill>
  );
};
