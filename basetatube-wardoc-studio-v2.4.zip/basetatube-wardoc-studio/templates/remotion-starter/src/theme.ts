// Implements libraries/style-specs.yaml (measured from assets/style-references). Keep the two in sync.
export type StyleKind = 'cinematic' | 'tactical' | 'archival';

export type StyleTheme = {
  kind: StyleKind;
  sat?: boolean;   // clean look for a satellite-picture base: no grid, no scanlines
  sea: string; seaDeep: string; land: string; coast: string;
  ink: string; red: string; redDark: string; blue: string; blueDark: string; accent: string;
  highlight: string; label: string; labelBg: string; card: string; cardBorder: string; cardText: string;
  font: string; titleFont: string; vignette: number; transition: string;
};

export const STYLE_THEMES: Record<string, StyleTheme> = {
  'cinematic-war-map': {
    kind: 'cinematic', sea: '#3C6373', seaDeep: '#2B4753', land: '#D7C4A5', coast: '#5E4A2E',
    ink: '#221C16', red: '#D62828', redDark: '#8A0D0D', blue: '#1D63B8', blueDark: '#143D6D', accent: '#E8B84A', highlight: '#3A2412',
    label: '#221C16', labelBg: 'rgba(234,216,186,0.9)', card: '#EAD8BA', cardBorder: '#6B5335', cardText: '#231810',
    font: 'Readex Pro', titleFont: 'Cairo', vignette: 0.7, transition: 'cross_dissolve',
  },
  'modern-tactical': {
    kind: 'tactical', sea: '#0A1118', seaDeep: '#05080C', land: '#13222E', coast: '#00E5FF',
    ink: '#FFFFFF', red: '#FF1744', redDark: '#B3102E', blue: '#00E5FF', blueDark: '#0090A8', accent: '#00E5FF', highlight: '#FFE14A',
    label: '#FFFFFF', labelBg: 'rgba(10,20,30,0.85)', card: 'rgba(10,20,30,0.85)', cardBorder: 'rgba(0,229,255,0.45)', cardText: '#FFFFFF',
    font: 'IBM Plex Sans Arabic', titleFont: 'IBM Plex Sans Arabic', vignette: 0.55, transition: 'radar_wipe',
  },
  'archival-atlas': {
    kind: 'archival', sea: '#E4D5BE', seaDeep: '#D2C2A6', land: '#CDBB9C', coast: '#5A4838',
    ink: '#1B1714', red: '#A81818', redDark: '#7A1212', blue: '#2F4A6B', blueDark: '#22364E', accent: '#A81818', highlight: '#1B1714',
    label: '#1B1714', labelBg: '#EFE4CE', card: '#EFE4CE', cardBorder: '#8B7A5E', cardText: '#1B1714',
    font: 'IBM Plex Sans Arabic', titleFont: 'Readex Pro', vignette: 0.8, transition: 'paper_slide',
  },
  // Satellite: a real picture of the earth as the base, clean white type and neon overlays (needs basemap.satellite).
  'satellite': {
    kind: 'tactical', sat: true, sea: '#06121C', seaDeep: '#03090F', land: '#1B2A33', coast: '#FFFFFF',
    ink: '#FFFFFF', red: '#FF3B30', redDark: '#B3241C', blue: '#35A7FF', blueDark: '#1C6FB8', accent: '#FFFFFF', highlight: '#FFD23F',
    label: '#FFFFFF', labelBg: 'rgba(8,12,18,0.74)', card: 'rgba(8,12,18,0.82)', cardBorder: 'rgba(255,255,255,0.28)', cardText: '#FFFFFF',
    font: 'Cairo', titleFont: 'Cairo', vignette: 0.6, transition: 'cross_dissolve',
  },
};

export const styleTheme = (id?: string) => STYLE_THEMES[id ?? ''] ?? STYLE_THEMES['cinematic-war-map'];
export const sideColors = (c: string | undefined, t: StyleTheme): [string, string] =>
  c === 'blue' ? [t.blue, t.blueDark] : c === 'accent' ? [t.highlight, t.highlight] : !c || c === 'red' ? [t.red, t.redDark] : [c, c];

export type CaptionTheme = {
  kind: 'kinetic' | 'minimal' | 'infographic';
  font: string; weight: number; primary: string; keyword: string; backing: string;
  enter: number; exit: number; sizeFactor: number; bottomPct: number;
};

// Measured from style-04/05/06 references.
export const CAPTION_THEMES: Record<string, CaptionTheme> = {
  'bold-kinetic': {kind: 'kinetic', font: 'Cairo', weight: 900, primary: '#FFFFFF', keyword: '#FFCC00', backing: '#111417', enter: 6, exit: 5, sizeFactor: 0.052, bottomPct: 13},
  'cinematic-minimal': {kind: 'minimal', font: 'Readex Pro', weight: 700, primary: '#FFFFFF', keyword: '#EAA838', backing: 'rgba(18,20,24,0.68)', enter: 10, exit: 8, sizeFactor: 0.045, bottomPct: 13},
  'infographic-arabic': {kind: 'infographic', font: 'IBM Plex Sans Arabic', weight: 700, primary: '#FFFFFF', keyword: '#FF3B14', backing: '#1F2227', enter: 7, exit: 6, sizeFactor: 0.048, bottomPct: 11},
};
export const captionTheme = (id?: string) => CAPTION_THEMES[id ?? ''] ?? CAPTION_THEMES['cinematic-minimal'];
