import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import './fonts';
import brief from './data/brief.json';
import shotPlan from './data/shot-plan.json';
import build from './data/build.json';
import {styleTheme} from './theme';
import {MapShot, mapFor, mapLayers} from './components/MapShot';
import {revealWindow} from './geo';
import {MediaShot} from './components/MediaShot';
import {CardShot} from './components/CardShot';
import {Captions} from './components/Captions';
import {Presenter} from './components/Presenter';
import {LowerThird} from './components/LowerThird';
import {Notices} from './components/Badge';
import {TRANSITION_FRAMES, TRANSITIONS, TransitionIn} from './components/Transition';

const STATUS_LABEL: Record<string, string> = {
  research_required: 'بانتظار التوثيق — ليست معلومة مؤكدة',
  illustrative: 'مشهد توضيحي',
};

const ShotBody: React.FC<{shot: any; durationInFrames: number}> = ({shot, durationInFrames}) => {
  switch (shot.shot_type) {
    case 'map_graphic':
      return <MapShot shot={shot} durationInFrames={durationInFrames} />;
    case 'archival_licensed':
    case 'ai_illustration':
      return <MediaShot shot={shot} durationInFrames={durationInFrames} />;
    case 'presenter':
      return <CardShot shot={shot} durationInFrames={durationInFrames} variant="presenter" />;
    default:
      return <CardShot shot={shot} durationInFrames={durationInFrames} variant="card" />;
  }
};

const noticesFor = (shot: any, b: any): string[] => {
  const out: string[] = [];
  if (b.demo) out.push('عرض تجريبي للقالب — بيانات خيالية غير تاريخية');
  if (STATUS_LABEL[shot.data_status]) out.push(STATUS_LABEL[shot.data_status]);
  if (shot.shot_type === 'ai_illustration') out.push('صورة توضيحية بالذكاء الاصطناعي — ليست لقطة أرشيفية');
  const plateShown = shot.atmosphere && (shot.shot_type === 'map_graphic' ? styleTheme(shot.style_id).kind === 'cinematic' : ['infographic', 'transition', 'presenter'].includes(shot.shot_type));
  if (plateShown) out.push('خلفية توضيحية مولَّدة — ليست لقطة من الحدث');
  if (shot.clipping || shot.clippings?.length) out.push('تصميم توضيحي — ليس صورة من صحيفة أصلية');
  if (shot.shot_type === 'map_graphic' && mapFor(shot).basemap?.modern_reference) out.push('خريطة أساس حديثة للاستدلال فقط — ليست حدودًا تاريخية');
  for (const id of shot.asset_ids ?? []) {
    const a = (b.assets ?? {})[id];
    if (a?.attribution && shot.shot_type !== 'ai_illustration') out.push(a.attribution);
  }
  return out;
};

const transitionOf = (shot: any, index: number) => {
  if (index === 0) return 'none';
  if (TRANSITIONS.includes(shot.transition_in)) return shot.transition_in;
  return styleTheme(shot.style_id).transition;
};

const DATE_SFX: Record<string, string> = {cinematic: 'hit', tactical: 'ping', archival: 'typewriter'};
// One quiet cue as each map element appears, so the picture and the sound land together.
const LAYER_SFX: Record<string, [string, number]> = {route: ['swish', 0.28], arc: ['swish', 0.3], pin: ['pop', 0.3], label: ['pop', 0.16], unit: ['pop', 0.26], event: ['pop', 0.3],
  icon: ['pop', 0.32], zone: ['pulse', 0.3], country: ['pulse', 0.34], range: ['pulse', 0.36], front_line: ['pulse', 0.24]};

export const Documentary: React.FC = () => {
  const {fps} = useVideoConfig();
  const shots: any[] = (shotPlan as any).shots ?? [];
  const b = build as any;
  const talkShots = shots.filter((s) => b.talk?.[s.shot_id]?.audio);
  const presenterOn = Boolean(b.presenter) && (Boolean((brief as any).presenter?.enabled) || shots.some((s) => s.shot_type === 'presenter'));
  return (
    <AbsoluteFill style={{backgroundColor: '#0d0d0d', direction: 'rtl'}}>
      {shots.map((shot, index) => {
        const from = Math.round(shot.start_sec * fps);
        const dur = Math.max(1, Math.round((shot.end_sec - shot.start_sec) * fps));
        const next = shots[index + 1];
        // Keep this shot on screen under the next shot's entry transition.
        const overlap = next && transitionOf(next, index + 1) !== 'none' && Math.abs(next.start_sec - shot.end_sec) < 0.05 ? TRANSITION_FRAMES : 0;
        const transition = transitionOf(shot, index);
        return (
          <Sequence key={shot.shot_id} from={from} durationInFrames={dur + overlap} name={`${shot.shot_id} · ${shot.shot_type}`}>
            <TransitionIn type={transition}>
              <ShotBody shot={shot} durationInFrames={dur} />
              <LowerThird shot={shot} durationInFrames={dur} />
              <Notices items={noticesFor(shot, b)} />
              {presenterOn ? <Presenter shot={shot} shotStartSec={shot.start_sec} /> : null}
            </TransitionIn>
            {b.sfx && transition !== 'none' ? <Audio src={staticFile('sfx/whoosh.wav')} volume={0.32} /> : null}
            {b.sfx && shot.shot_type === 'map_graphic'
              ? mapLayers(shot).map((layer: any, i: number, all: any[]) => {
                  const cue = LAYER_SFX[layer.type];
                  const at = Math.round(revealWindow(layer, i, all.length, dur, fps)[0]);
                  if (!cue || at >= dur - 2) return null;
                  return (
                    <Sequence key={`sfx${i}`} from={at}>
                      <Audio src={staticFile(`sfx/${cue[0]}.wav`)} volume={cue[1]} />
                    </Sequence>
                  );
                })
              : null}
            {b.sfx && shot.date_label_ar ? (
              <Sequence from={Math.round(fps * 0.15)}>
                <Audio src={staticFile(`sfx/${DATE_SFX[styleTheme(shot.style_id).kind]}.wav`)} volume={0.38} />
              </Sequence>
            ) : null}
          </Sequence>
        );
      })}
      <Captions />
      {/* A talking clip plays its own voice: then voice and music run as separate tracks and the narration is silent in those shots. */}
      {talkShots.length && b.tracks?.voice ? (
        <>
          <Audio src={staticFile(b.tracks.voice)} volume={(f) => (talkShots.some((s) => f >= s.start_sec * fps && f < s.end_sec * fps) ? 0 : 1)} />
          {b.tracks.music ? <Audio src={staticFile(b.tracks.music)} volume={0.16} /> : null}
        </>
      ) : b.audio ? <Audio src={staticFile(b.audio)} /> : null}
    </AbsoluteFill>
  );
};
