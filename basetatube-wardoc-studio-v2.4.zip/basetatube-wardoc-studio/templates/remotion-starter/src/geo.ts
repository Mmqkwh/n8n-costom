// Pure geometry helpers. Nothing here invents geography: it only projects and draws the data it is given.
export type Pt = [number, number];

// Projection fitted to bbox = [west, south, east, north], WGS84 [longitude, latitude].
// "equirectangular" is used for the drawn styles; "mercator" whenever a satellite picture is the base,
// because map tiles are Web Mercator and every layer must sit exactly on the picture.
const mercY = (lat: number) => Math.log(Math.tan(Math.PI / 4 + (Math.max(-85, Math.min(85, lat)) * Math.PI) / 360));

export const makeProjector = (bbox: number[], width: number, height: number, pad: number, type: 'equirectangular' | 'mercator' = 'equirectangular') => {
  const [west, south, east, north] = bbox;
  const lat0 = (south + north) / 2;
  if (type === 'mercator') {
    const x0 = (west * Math.PI) / 180, x1 = (east * Math.PI) / 180, yTop = mercY(north), yBottom = mercY(south);
    const scale = Math.min((width - pad * 2) / (x1 - x0), (height - pad * 2) / (yTop - yBottom));
    const ox = (width - (x1 - x0) * scale) / 2, oy = (height - (yTop - yBottom) * scale) / 2;
    const project = ([lon, lat]: Pt): Pt => [ox + ((lon * Math.PI) / 180 - x0) * scale, oy + (yTop - mercY(lat)) * scale];
    return {project, pxPerKm: scale / (6371 * Math.cos((lat0 * Math.PI) / 180))};
  }
  const k = Math.cos((lat0 * Math.PI) / 180) || 1;
  const scale = Math.min((width - pad * 2) / ((east - west) * k), (height - pad * 2) / (north - south));
  const ox = (width - (east - west) * k * scale) / 2;
  const oy = (height - (north - south) * scale) / 2;
  const project = ([lon, lat]: Pt): Pt => [ox + (lon - west) * k * scale, oy + (north - lat) * scale];
  return {project, pxPerKm: scale / 111.32};
};

export const toPath = (pts: Pt[], close = false) =>
  pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ') + (close ? ' Z' : '');

export const polygonPath = (geometry: any, project: (c: Pt) => Pt) => {
  if (!geometry) return '';
  const polys = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.type === 'MultiPolygon' ? geometry.coordinates : [];
  return polys.map((rings: Pt[][]) => rings.map((ring) => toPath(ring.map(project), true)).join(' ')).join(' ');
};

// Catmull-Rom smoothing through the given points (the line still passes through every data point).
export const smooth = (pts: Pt[], perSegment = 14): Pt[] => {
  if (pts.length < 3) return pts.length === 2 ? Array.from({length: perSegment + 1}, (_, i) => {
    const t = i / perSegment;
    return [pts[0][0] + (pts[1][0] - pts[0][0]) * t, pts[0][1] + (pts[1][1] - pts[0][1]) * t] as Pt;
  }) : pts;
  const out: Pt[] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    for (let j = 0; j < perSegment; j++) {
      const t = j / perSegment, t2 = t * t, t3 = t2 * t;
      out.push([
        0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
        0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
      ]);
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
};

export const lengths = (pts: Pt[]) => {
  const acc = [0];
  for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  return acc;
};

// First fraction p (0..1) of a polyline, with an exact interpolated end point.
export const truncate = (pts: Pt[], p: number): Pt[] => {
  if (p >= 1) return pts;
  const acc = lengths(pts), target = acc[acc.length - 1] * Math.max(0, p);
  const out: Pt[] = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    if (acc[i] <= target) out.push(pts[i]);
    else {
      const t = (target - acc[i - 1]) / (acc[i] - acc[i - 1] || 1);
      out.push([pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t]);
      break;
    }
  }
  return out;
};

const normalAt = (pts: Pt[], i: number): Pt => {
  const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
  const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy) || 1;
  return [-dy / len, dx / len];
};

// Tapered military arrow as one closed polygon: narrow tail, wider body, triangular head.
export const taperedArrow = (pts: Pt[], tailW: number, bodyW: number, headW: number, headL: number) => {
  if (pts.length < 2) return '';
  const acc = lengths(pts), total = acc[acc.length - 1];
  if (total < headL * 0.6) headL = total * 0.6;
  const bodyEnd = total - headL;
  const left: Pt[] = [], right: Pt[] = [];
  let neck = 0;
  for (let i = 0; i < pts.length && acc[i] <= bodyEnd; i++) {
    const w = (tailW + (bodyW - tailW) * (acc[i] / (bodyEnd || 1))) / 2;
    const n = normalAt(pts, i);
    left.push([pts[i][0] + n[0] * w, pts[i][1] + n[1] * w]);
    right.push([pts[i][0] - n[0] * w, pts[i][1] - n[1] * w]);
    neck = i;
  }
  if (!left.length) return '';
  const n = normalAt(pts, neck), base = pts[neck], tip = pts[pts.length - 1];
  const head: Pt[] = [[base[0] + n[0] * headW / 2, base[1] + n[1] * headW / 2], tip, [base[0] - n[0] * headW / 2, base[1] - n[1] * headW / 2]];
  return toPath([...left, ...head, ...right.reverse()], true);
};

// Open chevron / triangle head at the end of a polyline.
export const headAt = (pts: Pt[], size: number, open = false) => {
  if (pts.length < 2) return '';
  const tip = pts[pts.length - 1];
  let j = pts.length - 2;
  while (j > 0 && Math.hypot(tip[0] - pts[j][0], tip[1] - pts[j][1]) < size * 0.5) j--;
  const dx = tip[0] - pts[j][0], dy = tip[1] - pts[j][1], len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len;
  const a: Pt = [tip[0] - ux * size - uy * size * 0.55, tip[1] - uy * size + ux * size * 0.55];
  const b: Pt = [tip[0] - ux * size + uy * size * 0.55, tip[1] - uy * size - ux * size * 0.55];
  return open ? toPath([a, tip, b]) : toPath([a, tip, b], true);
};

// Deterministic hand-drawn wobble (archival ink). Same input, same output on every frame.
export const wobble = (pts: Pt[], amount: number): Pt[] =>
  pts.map((p, i) => {
    const n = normalAt(pts, i), d = (Math.sin(i * 1.7) + Math.sin(i * 0.53 + 1.3)) * 0.5 * amount;
    return [p[0] + n[0] * d, p[1] + n[1] * d];
  });

// Perpendicular tick marks along a line (fortified front line).
export const ticks = (pts: Pt[], every: number, size: number) => {
  const acc = lengths(pts);
  let next = every / 2, d = '';
  for (let i = 1; i < pts.length; i++) {
    while (acc[i] >= next) {
      const t = (next - acc[i - 1]) / (acc[i] - acc[i - 1] || 1);
      const x = pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t, y = pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t;
      const n = normalAt(pts, i);
      d += `M${x.toFixed(1)} ${y.toFixed(1)} l${(n[0] * size).toFixed(1)} ${(n[1] * size).toFixed(1)} `;
      next += every;
    }
  }
  return d;
};

// A round distance for the scale bar that fits roughly a sixth of the frame width.
export const niceScale = (pxPerKm: number, maxPx: number) => {
  const steps = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000];
  let km = steps[0];
  for (const s of steps) if (s * pxPerKm <= maxPx) km = s;
  return {km, px: km * pxPerKm};
};

// Seeded pseudo-random in 0..1 (stable across frames and machines).
export const rand = (seed: number) => {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
};

// Flight arc between two screen points: a quadratic curve lifted sideways by `height` times the distance.
export const arcPoints = (a: Pt, b: Pt, height = 0.22, steps = 48): Pt[] => {
  const dx = b[0] - a[0], dy = b[1] - a[1], dist = Math.hypot(dx, dy) || 1;
  // lift toward the top of the frame so arcs read as trajectories
  let nx = -dy / dist, ny = dx / dist;
  if (ny > 0) { nx = -nx; ny = -ny; }
  const cx = (a[0] + b[0]) / 2 + nx * dist * height, cy = (a[1] + b[1]) / 2 + ny * dist * height;
  return Array.from({length: steps + 1}, (_, i) => {
    const t = i / steps, u = 1 - t;
    return [u * u * a[0] + 2 * u * t * cx + t * t * b[0], u * u * a[1] + 2 * u * t * cy + t * t * b[1]] as Pt;
  });
};

// Points of a circle of `km` around a place on the globe (true ground distance, so it is not a perfect circle on the map).
export const geodesicCircle = (center: Pt, km: number, steps = 96): Pt[] => {
  const R = 6371, d = km / R, lat1 = (center[1] * Math.PI) / 180, lon1 = (center[0] * Math.PI) / 180;
  return Array.from({length: steps + 1}, (_, i) => {
    const brg = (i / steps) * Math.PI * 2;
    const lat2 = Math.asin(Math.sin(lat1) * Math.cos(d) + Math.cos(lat1) * Math.sin(d) * Math.cos(brg));
    const lon2 = lon1 + Math.atan2(Math.sin(brg) * Math.sin(d) * Math.cos(lat1), Math.cos(d) - Math.sin(lat1) * Math.sin(lat2));
    return [(lon2 * 180) / Math.PI, (lat2 * 180) / Math.PI] as Pt;
  });
};

// When a map layer appears, in frames from the start of its shot. Shared by the picture and the sound effects.
export const revealWindow = (layer: any, index: number, count: number, durationInFrames: number, fps: number): [number, number] => {
  const slot = durationInFrames / Math.max(1, count + 1);
  const start = layer.reveal_start_sec != null ? layer.reveal_start_sec * fps : slot * index * 0.8;
  const end = layer.reveal_end_sec != null ? layer.reveal_end_sec * fps : start + Math.max(18, slot * 0.9);
  return [start, Math.max(start + 1, end)];
};

// Camera keyframes: [{at_sec, focus: [lon, lat], scale}] -> focus and scale at time t, eased between keys.
export const cameraAt = (path: any[], t: number): {focus: Pt; scale: number} => {
  const keys = [...path].sort((a, b) => (a.at_sec ?? 0) - (b.at_sec ?? 0));
  if (t <= (keys[0].at_sec ?? 0)) return {focus: keys[0].focus, scale: keys[0].scale ?? 1};
  for (let i = 1; i < keys.length; i++) {
    const a = keys[i - 1], b = keys[i];
    if (t <= b.at_sec) {
      const u = (t - a.at_sec) / Math.max(0.001, b.at_sec - a.at_sec);
      const e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
      const sa = a.scale ?? 1, sb = b.scale ?? 1;
      return {focus: [a.focus[0] + (b.focus[0] - a.focus[0]) * e, a.focus[1] + (b.focus[1] - a.focus[1]) * e], scale: sa * Math.pow(sb / sa, e)};
    }
  }
  const last = keys[keys.length - 1];
  return {focus: last.focus, scale: last.scale ?? 1};
};
