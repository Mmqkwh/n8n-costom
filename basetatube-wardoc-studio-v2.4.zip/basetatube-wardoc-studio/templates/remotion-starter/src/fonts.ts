// Arabic fonts are bundled in public/fonts (SIL Open Font License, see the OFL-*.txt files there),
// so rendering needs no network and the typography is identical on every machine.
import {continueRender, delayRender, staticFile} from 'remotion';
import faces from '../public/fonts/fonts.json';

if (typeof document !== 'undefined') {
  const handle = delayRender('Loading bundled Arabic fonts');
  Promise.all(
    (faces as any[]).map((f) => {
      const face = new FontFace(f.family, `url(${staticFile('fonts/' + f.file)}) format('woff2')`, {weight: f.weight, unicodeRange: f.unicodeRange});
      return face.load().then((loaded) => (document as any).fonts.add(loaded));
    }),
  )
    .then(() => continueRender(handle))
    .catch((err) => {
      console.error('Font loading failed', err);
      continueRender(handle);
    });
}

export const fontFor = (family: string) => `'${family}', 'Cairo', 'Noto Sans Arabic', sans-serif`;
