import React from 'react';
import {Composition} from 'remotion';
import {Documentary} from './Documentary';
import brief from './data/brief.json';
import shotPlan from './data/shot-plan.json';

const SIZES: Record<string, [number, number]> = {
  '16:9': [1920, 1080],
  '9:16': [1080, 1920],
  '1:1': [1080, 1080],
};

export const Root: React.FC = () => {
  const [width, height] = SIZES[(brief as any).aspect_ratio] ?? SIZES['16:9'];
  const fps = (shotPlan as any).fps ?? 30;
  const durationInFrames = Math.max(1, Math.round(((shotPlan as any).duration_seconds ?? 10) * fps));
  return (
    <Composition
      id="Documentary"
      component={Documentary}
      width={width}
      height={height}
      fps={fps}
      durationInFrames={durationInFrames}
    />
  );
};
