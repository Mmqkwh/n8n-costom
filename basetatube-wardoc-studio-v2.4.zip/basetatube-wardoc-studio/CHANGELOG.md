# Changelog

## 2.4.0

- The plan quality gate is now the default: the build stops on a weak plan (`--draft` for previews).
- `scripts/wow_check.py`: measured check of the rendered film per shot (movement, colour, fullness, frozen stretches) against a reference level, frames saved for review, and a scored verdict by eye (nothing under 7, average 8+, not below the reference). A film is `COMPLETED` only with a passing verdict.

## 2.3.0

Instructions only (`workflows/motion-playbook.md`); no new code. Motion graphics impact is stated as the first priority. Both routes: required self check of rendered frames, four episode templates, bolder camera, stronger captions. FREE: archive video, parallax, cut-outs, side-by-side / timeline / counter shots, relief maps for close zooms. HIGGS: generated cinematic opening in every film, every still animated, generated map-to-scene transitions, one fixed channel character, one icon sheet per episode. The model carries these out by extending the generated project.

## 2.2.1

- `find_assets.py`: requests are retried with a growing pause (Openverse is slow on new queries and sometimes answers 504); a source that stays down is skipped and reported. New sources: NASA image library, Internet Archive, and Iconify for icons (`--source icons`).

## 2.2.0

- Wow rule in both routes: creative freedom, and minimums for a film of 30 s or more (3 pictures, one per 15 s; 3 topic-specific elements), checked by the builder.
- FREE: finding pictures and icons is a required task. `scripts/find_assets.py` (search Openverse + Wikimedia Commons, download and register any URL), a longer list of picture and icon sites, and places for outside assets: `icon` layers with `asset_id` (optionally `framed`), `icon_asset_id` on cards.
- Licence fields in the manifest are informational; no asset is blocked on them any more.
- HIGGS: generation without cost preflight, approval or economy; narration only with `elevenlabs_v4` (no Edge TTS); music and sound effects generated; talking character with `wan3_0_prime` / `wan3_0` or `minimax_h3_max`, whose own audio is played in its shots (narration silenced there, music continues); generated effects in `audio/sfx/` replace the built-in ones.
- Router: choosing Higgsfield now returns `paid_generation_allowed: true`.

## 2.1.0

- Map quality rule (`system/rules-visual.md`) with a builder gate: every map shot needs a colour fill, at least three kinds of element including a symbol, something new at least every 3.5 s, a moving camera, and stays under 12 s. `quality_gate` and `quality_issues` in the build output; `--strict` makes it blocking.
- HIGGS: the spoken line must be written in Arabic script inside every `wan3_0_prime` prompt with dialogue.
- The disclosure label under the affiliate message was removed on the owner's request; the message and link are unchanged.

## 2.0.0

Maps
- New `satellite` style: a real picture of the earth as the map base, fetched and stitched at build time (`basemap.satellite`: eox, nasa or esri), with drifting clouds, credit line, and Web Mercator placement of every layer.
- Several maps per film (`maps` + `map_id`), camera keyframes that fly between places (`camera.path`), optional orbital tilt (`camera.tilt_deg`).
- New layers: `country` (modern outline, glowing / solid / marching border), `arc` (curved trajectory with travelling dashes and an optional riding icon), `range` (ground-distance ring that grows).
- Headline and counting number over a map shot (`title_ar`, `stat`, `overlay_at_sec`).
- Finer coastline on request (`basemap.detail: "10m"`); country outlines on satellite always try 1:10m.
- Map elements keep their on-screen size while the camera zooms.

Sound
- A cue on every map reveal (pop, swish, pulse) timed to the layer; sub-bass impacts and risers in the music.

HIGGS route
- Talking host clip per shot (`assets/presenter/talk/<shot_id>.webm`), `scripts/key_video.py` for the green screen, `scripts/align_words.py` for word timings of audio without timestamps.

Other
- Medical icons use a green cross. Repository files for GitHub (licence placeholder, ignore list, release workflow).

Not done: vertical 9:16 tuning (left out on request), a true globe projection (the tilt gives the orbital feel instead).

## 1.9.0

- 32 isometric 3D icons in two sprite sheets (`public/icons/military.webp`, `civil.webp`; two files, not 32). New map layer type `icon` and card field `icon`.
- HIGGS route: voice model `elevenlabs_v4` with a voice the user picks; a character that speaks is generated with `wan3_0_prime` using that line's audio as reference; supporting clips with `wan3_0_prime` are allowed. Prompt templates 6 to 8 added.

## 1.8.0

Instructions only; no change to the video code and no new files.
- Pace rule: a visible change every 1.5 to 3 seconds, with concrete shot lengths (`system/rules-narrative.md`).
- Sync rule: every map layer and card timed to the word that names it, computed from `narration.words.json`.
- Current-affairs mode (`"topic_kind": "current_affairs"`): source, attribution, as-of date and map limits (`system/rules-research.md`).
- Channel identity from `brief.channel` using the existing closing card and lower third.
- HIGGS route now states that it is the FREE pipeline plus generated pictures: every free asset, style, card, clipping, host and audio tool is used there too, with a list of where a generated picture can go.

## 1.7.2

- Packaging only: radio layers moved from a nested zip to a plain pack file (`scripts/radio_pack.py`), because Claude on the web rejects nested zips.

## 1.7.1

- Packaging only: the skill now has under 200 files so it can be uploaded to Claude on the web. Radio layers ship as one archive, the classic host is drawn by code at build time, and the exported symbol copies are no longer shipped (run `scripts/export_map_symbols.py`). No change in output.

## 1.7.0

- Radio host rebuilt as layers at higher resolution: 7 body gestures (including pointing left, right and up), 5 eye states (blink, left, right, up, wide), 3-state mouth, combined freely by the video. Tactical (gunmetal, cyan dial) and archival (sepia) looks chosen from the visual style.

## 1.6.0

- New default host for the FREE route: a living 1940s radio mascot (`assets/presenter-radio/`, bundled). The drawn SVG man stays available with `"presenter": {"character": "classic"}`.

## 1.5.0

Added
- Editable Arabic newspaper clippings (`shot.clipping`, or `shot.clippings` for two or three together) in five templates: `front_page`, `banner`, `column`, `photo_report`, `telegram`. Editable fields: masthead, motto, issue, price, two dates, kicker, headline, red-pencil highlight, subhead, dateline, body paragraphs, byline, column count, picture slot (cleared asset or bundled backdrop as halftone, position, ratio, caption), paper tone, rotation and decor (tape, paperclip, stamp, fold).
- Works with the archive set: desk or backdrop, film strip, date card, lower third, transitions; beside photo prints on an archival shot.
- Bundled fonts Amiri and Aref Ruqaa (SIL OFL 1.1) for period typography.
- `libraries/clipping-templates.yaml`, `templates/clippings.example.json`; builder checks template names, the picture's rights, verified-needs-claims, and warns when the body exceeds a template's capacity.

## 1.4.0

Added (all bundled, nothing fetched at render time)
- Terrain from Natural Earth (public domain, modern): shaded relief (`basemap.relief`), rivers (`basemap.rivers`), lakes (`basemap.lakes`), cut to each map at build time; sea-name labels (`kind: water`).
- Six generic backdrops (`shot.atmosphere`: desert, winter, city, sea, war_room, mountain) with drifting dust / snow; as card backgrounds and as the lower band of a cinematic map. Always shown with an "illustration" notice.
- Five generic unit silhouettes (tank, infantry, artillery, aircraft, ship); unit `display: silhouette | card`, `facing`, and `flag_asset_id` for a rights-cleared flag.
- Archival furniture drawn in code: film strip, paperclip, decorative archive stamp; newsprint clipping card (`shot.clipping`) with a notice.

Still not bundled on purpose: national flags and insignia, real photographs and newspaper scans, moving footage, satellite imagery.

## 1.3.0

The FREE route now follows the style references.

Added
- `libraries/style-specs.yaml`: the look of the three visual styles and three caption styles, measured from the reference images, and implemented one-to-one by the Remotion starter (`src/theme.ts` and components).
- Bundled textures (`parchment.webp`, `desk.webp`), generated once and shipped as static files; procedural HUD grid, scanlines, film grain, scratches, torn paper and tape.
- Map look per style: tapered gradient arrows / glowing dashed arrows / hand-drawn ink; toothed front lines; hatched zones; pins with pulse ring, reticle or grease-pencil circle; labels, date card, legend, compass and kilometre scale bar in each style.
- Map symbols: 9 unit and 10 event symbols (`unit` and `event` layers), one source in `src/icons.json`, editable SVG copies under `assets/vector/map-symbols/`. Route `arrow_style`: main, secondary, flank, retreat.
- Basemap: bundled Natural Earth 1:50m land (public domain, modern coastlines), `"land_geojson": "natural_earth"` and `scripts/clip_basemap.py`.
- Motion: transitions (cross dissolve, paper slide, paper rip, radar wipe, film flash), statistic card with count-up, quote card, lower third, archival prints on a desk, gate weave.
- Captions redrawn to match references 04 / 05 / 06, plus `callout_ar`.
- Arabic fonts bundled (Cairo, Readex Pro, IBM Plex Sans Arabic, SIL OFL 1.1 with licence texts); the render no longer needs Google Fonts.
- `scripts/make_sfx.py`: whoosh, hit, typewriter, ping synthesised in code and placed automatically.
- Presenter: 12 poses (added speaking_mid, pointing_up, thinking, holding_paper), 3 style variants, three-shape mouth animation.
- `scripts/style_check.py` and QA gate Q5a.

Not reproduced by the FREE route (needs cleared media or HIGGS): live battlefield footage, photographs, newspaper clippings, satellite imagery, flags and insignia, relief shading.

## 1.2.0

Fixed
- `make_narration.py`: the speech rate was passed as `--rate -8%`, which edge-tts rejects, so narration always fell back to `VOICE_NEEDED`. Now uses the Python API (and `--rate=-8%` on the CLI path). Failures report the real cause in `diagnostic`.
- `make_narration.py --help` crashed on an unescaped `%`.
- Router: negated requests ("without using Higgsfield", "بدون استخدام هيجزفيلد", "مش عايز هيجز", "do not use higgsfield") no longer select the paid route. "vs" no longer means "compare both routes". "Peter Higgs" / "بوزون هيجز" no longer select Higgsfield.
- Router keyword lists existed twice and had drifted; `routing/mode-router.json` is now the only copy and `route.py` reads it. `routing/mode-router.yaml` was removed.
- `make_music.py`: `--cue-sheet` silently overrode `--duration`. Now an error, or use `--scale-cues` to fit the cues to a duration.
- `make_presenter_assets.py` rewrote the skill's own assets on every run. It now writes to `--out`.
- One output layout everywhere (`research/`, `production/`, `assets/`, `audio/`, `remotion/`); one music file name (`audio/original-score.wav`); one queue name (`production/higgs-generation-queue.yaml`); 8 presenter poses everywhere. `render_commands.md`, `research-open-questions.md` and `map-data.json` are now created by the scaffold.

Added
- `templates/remotion-starter/` + `scripts/build_remotion_project.py`: a data-driven Remotion project (map shots with routes, front lines, zones, pins; archival / AI shots; title and date cards; RTL captions; presenter; audio) with a fictional demo. Build-time rights gate and on-screen notices for unverified shots.
- Word-level caption timing: `narration.words.json` from Edge TTS and `srt_to_captions.py --words`.
- `schemas/map-data.schema.json`; optional `title_ar`, `date_label_ar`, `presenter_pose`, `camera.focus` in the shot plan; optional `words` in captions.
- `workflows/both-mode.md`.
- `templates/higgs-prompt-templates.md`: keyframes first, named image references, frozen Arabic text.
- `scripts/run_tests.py`, more router/audio tests, a build test, and a stricter `validate_skill.py`.
- `mix_audio.py --fit voice`.

Changed
- Style references converted from PNG to WebP (about 14 MB to under 1 MB).
- Skill description narrowed to war / military-history documentaries.
- Affiliate message and link unchanged; shown at most once per reply, with a disclosure label under it.
