# BasetaTube WarDoc Studio v2.4 — Claude custom skill

Install the complete folder as a skill. Start with [`SKILL.md`](SKILL.md), then `CLAUDE.md`.

**Routes:** FREE: historically sourced, Remotion-based maps + optional Edge TTS Arabic narration + original code-generated music. HIGGS: Higgsfield with Wan 3.0 Prime / Wan 3.0 and GPT Image 2.6 (credits require approval). BOTH: the same film in both versions for comparison.

## Install

**Claude Code:** clone this repository into your skills folder; the folder name must stay `basetatube-wardoc-studio`.

```bash
git clone https://github.com/<your-account>/basetatube-wardoc-studio ~/.claude/skills/basetatube-wardoc-studio
```

**Claude on the web:** download `basetatube-wardoc-studio.zip` from the Releases page and upload it under Settings > Capabilities > Skills. The web sandbox can plan and build a project; rendering the MP4, Edge TTS and satellite pictures need a machine with Node, FFmpeg and network.

## Quick start

```bash
python scripts/route.py "اعمل فيديو عن معركة العلمين"                 # choose the route (free by default)
python scripts/new_project.py --topic "معركة العلمين" --slug el-alamein --out output
# ... research, script, shot plan, map data (see SKILL.md) ...
python scripts/make_narration.py --text-file output/el-alamein/production/narration.txt \
  --output output/el-alamein/audio/narration.mp3 --subtitles output/el-alamein/audio/narration.srt
python scripts/srt_to_captions.py --words output/el-alamein/audio/narration.words.json \
  --output output/el-alamein/production/captions.json --style bold-kinetic
python scripts/make_music.py --cue-sheet output/el-alamein/production/music-cues.json \
  --output output/el-alamein/audio/original-score.wav
python scripts/mix_audio.py --voice output/el-alamein/audio/narration.mp3 \
  --music output/el-alamein/audio/original-score.wav --output output/el-alamein/audio/documentary-mix.m4a
python scripts/build_remotion_project.py --project output/el-alamein
cd output/el-alamein/remotion && npm install && npm run render
```

## Test the toolchain without any research

```bash
python scripts/build_remotion_project.py --demo --project output/template-demo
cd output/template-demo/remotion && npm install && npm run render   # 33 s clip, fictional data, all three styles and the clipping templates
python scripts/run_tests.py                                           # all offline self-tests
```

**Look:** three visual styles and three caption styles, each fixed in [`libraries/style-specs.yaml`](libraries/style-specs.yaml) and rendered by the starter with bundled textures, Arabic fonts and map symbols. `python scripts/style_check.py` compares a rendered frame with its style reference.

**Audio:** see [`workflows/free-audio.md`](workflows/free-audio.md). Music is fully offline and uses only the Python standard library. Edge TTS is an unofficial online service; it is not guaranteed to run inside every web chat or to be permitted for every commercial distribution. A user-recorded narration is the fallback.

Never imply files were rendered unless an execution tool returned them. The skill ships the pipeline and a fictional demo, not a pre-rendered documentary. See [`CHANGELOG.md`](CHANGELOG.md) for what changed.
