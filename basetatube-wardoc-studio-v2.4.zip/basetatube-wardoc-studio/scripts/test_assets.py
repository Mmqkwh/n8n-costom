#!/usr/bin/env python3
"""Tests for bundled assets and the small generators. Offline; FFmpeg tests skip when FFmpeg is missing."""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
STARTER = ROOT / "templates" / "remotion-starter"
sys.path.insert(0, str(SCRIPTS))
import clip_basemap  # noqa: E402
import export_map_symbols  # noqa: E402
import make_sfx  # noqa: E402
import make_presenter_assets  # noqa: E402


def run(script, *args):
    return subprocess.run([sys.executable, str(SCRIPTS / script), *args], capture_output=True, text=True)


class AssetTests(unittest.TestCase):
    def test_sfx_are_real_and_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = make_sfx.build(tmp)
            self.assertEqual(out["effects"], ["whoosh", "hit", "typewriter", "ping", "pop", "swish", "pulse", "riser"])
            for name in out["effects"]:
                with wave.open(str(Path(tmp) / f"{name}.wav"), "rb") as f:
                    self.assertEqual(f.getframerate(), 32000)
                    self.assertGreater(f.getnframes(), 4000)
            self.assertEqual(make_sfx.render("ping"), make_sfx.render("ping"))
            self.assertLessEqual(max(abs(x) for x in make_sfx.render("hit")), 0.8001)
        with self.assertRaises(ValueError):
            make_sfx.render("laser")

    def test_clip_basemap(self):
        square = {"type": "FeatureCollection", "features": [
            {"type": "Feature", "properties": {}, "geometry": {"type": "Polygon", "coordinates": [[[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]]]}},
            {"type": "Feature", "properties": {}, "geometry": {"type": "Polygon", "coordinates": [[[50, 50], [60, 50], [60, 60], [50, 60], [50, 50]]]}}]}
        out = clip_basemap.clip_collection(square, [4, 4, 6, 6], margin=0.5)
        self.assertEqual(len(out["features"]), 1)
        ring = out["features"][0]["geometry"]["coordinates"][0][0]
        self.assertEqual(ring[0], ring[-1])
        xs, ys = [p[0] for p in ring], [p[1] for p in ring]
        self.assertEqual((min(xs), max(xs), min(ys), max(ys)), (3, 7, 3, 7))
        with self.assertRaises(ValueError):
            clip_basemap.clip_collection(square, [6, 4, 4, 6])

    def test_bundled_natural_earth_clips_to_real_coast(self):
        land = json.loads((ROOT / "assets/geo/ne_50m_land.geojson").read_text(encoding="utf-8"))
        self.assertIn("public domain", land["source"])
        out = clip_basemap.clip_collection(land, [24, 28, 34, 33])
        self.assertGreater(len(out["features"]), 0)
        self.assertEqual(clip_basemap.clip_collection(land, [-150, -40, -140, -30], margin=0.1)["features"], [])  # open Pacific

    def test_map_symbols_match_single_source(self):
        icons = json.loads((STARTER / "src/icons.json").read_text(encoding="utf-8"))
        self.assertEqual(len(icons["units"]["items"]), 9)
        self.assertEqual(len(icons["events"]["items"]), 10)
        with tempfile.TemporaryDirectory() as tmp:
            files = export_map_symbols.export(tmp)
            self.assertEqual(len(files), 38)
            self.assertIn("<svg", (Path(tmp) / files[0]).read_text(encoding="utf-8"))
        schema = json.loads((ROOT / "schemas/map-data.schema.json").read_text(encoding="utf-8"))
        allowed = set(schema["properties"]["layers"]["items"]["properties"]["symbol"]["enum"])
        self.assertEqual(allowed, set(icons["units"]["items"]) | set(icons["events"]["items"]))

    def test_presenter_poses_in_sync_everywhere(self):
        poses = make_presenter_assets.POSES
        self.assertEqual(len(poses), 12)
        component = (STARTER / "src/components/Presenter.tsx").read_text(encoding="utf-8")
        for pose in poses:
            self.assertIn(f"'{pose}'", component)
            for variant in make_presenter_assets.VARIANTS:
                self.assertIn("<svg", make_presenter_assets.svg_for(pose, variant))
        schema = json.loads((ROOT / "schemas/shot-plan.schema.json").read_text(encoding="utf-8"))
        enum = schema["properties"]["shots"]["items"]["properties"]["presenter_pose"]["enum"]
        self.assertEqual(set(enum) - {None}, set(poses))

    def test_fonts_and_textures_are_bundled_with_licences(self):
        fonts = STARTER / "public/fonts"
        faces = json.loads((fonts / "fonts.json").read_text(encoding="utf-8"))
        self.assertEqual({f["family"] for f in faces}, {"Cairo", "Readex Pro", "IBM Plex Sans Arabic", "Amiri", "Aref Ruqaa"})
        for face in faces:
            self.assertGreater((fonts / face["file"]).stat().st_size, 10000)
        for name in ("Cairo", "ReadexPro", "IBMPlexSansArabic", "Amiri", "ArefRuqaa"):
            self.assertIn("SIL OPEN FONT LICENSE", (fonts / f"OFL-{name}.txt").read_text(encoding="utf-8").upper())
        for name in ("parchment.webp", "desk.webp"):
            self.assertGreater((STARTER / "public/textures" / name).stat().st_size, 20000)
        self.assertNotIn("google-fonts", (STARTER / "package.json").read_text(encoding="utf-8"))

    def test_backdrops_silhouettes_and_terrain_are_bundled(self):
        public = STARTER / "public"
        schema = json.loads((ROOT / "schemas/shot-plan.schema.json").read_text(encoding="utf-8"))
        plates = [a for a in schema["properties"]["shots"]["items"]["properties"]["atmosphere"]["enum"] if a]
        self.assertEqual(sorted(plates), ["city", "desert", "mountain", "sea", "war_room", "winter"])
        component = (STARTER / "src/components/Atmosphere.tsx").read_text(encoding="utf-8")
        for name in plates:
            self.assertIn(f"'{name}'", component)
            for suffix in ("", "-band"):
                self.assertGreater((public / "atmosphere" / f"{name}{suffix}.webp").stat().st_size, 20000)
        for name in ("tank", "infantry", "artillery", "aircraft", "ship"):
            data = (public / "silhouettes" / f"{name}.png").read_bytes()
            self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
            self.assertEqual(data[25], 6, f"{name} must be RGBA so it can be used as a mask")
        geo = ROOT / "assets/geo"
        rivers = json.loads((geo / "ne_50m_rivers.geojson").read_text(encoding="utf-8"))
        lakes = json.loads((geo / "ne_50m_lakes.geojson").read_text(encoding="utf-8"))
        self.assertIn("public domain", rivers["source"])
        self.assertIn("public domain", lakes["source"])
        self.assertGreater(len(clip_basemap.clip_lines(rivers, [24, 22, 36, 32])["features"]), 0)
        self.assertEqual(clip_basemap.clip_lines(rivers, [-150, -40, -140, -30], margin=0.1)["features"], [])
        self.assertGreater((geo / "ne_shaded_relief.webp").stat().st_size, 500000)
        self.assertTrue((geo / "README.md").is_file())

    def test_clip_lines_splits_at_the_box(self):
        line = {"type": "FeatureCollection", "features": [{"type": "Feature", "properties": {"rank": 2},
                "geometry": {"type": "LineString", "coordinates": [[0, 5], [4, 5], [5, 5], [6, 5], [20, 5], [5.5, 5.5], [5.6, 5.6]]}}]}
        out = clip_basemap.clip_lines(line, [4, 4, 6, 6], margin=0)
        self.assertEqual(out["features"][0]["geometry"]["coordinates"], [[[4, 5], [5, 5], [6, 5]], [[5.5, 5.5], [5.6, 5.6]]])
        self.assertEqual(out["features"][0]["properties"]["rank"], 2)

    def test_clipping_templates_in_sync(self):
        schema = json.loads((ROOT / "schemas/shot-plan.schema.json").read_text(encoding="utf-8"))
        clip = schema["$defs"]["clipping"]
        templates = clip["properties"]["template"]["enum"]
        self.assertEqual(templates, ["front_page", "banner", "column", "photo_report", "telegram"])
        component = (STARTER / "src/components/Clipping.tsx").read_text(encoding="utf-8")
        library = (ROOT / "libraries/clipping-templates.yaml").read_text(encoding="utf-8")
        example = json.loads((ROOT / "templates/clippings.example.json").read_text(encoding="utf-8"))
        for name in templates:
            self.assertIn(f"'{name}'", component)
            self.assertIn(f"  {name}:", library)
            self.assertEqual(example[name]["template"], name)
        # every editable field is documented and actually read by the component
        for field in clip["properties"]:
            self.assertIn(field, library, field)
            self.assertIn(f"clip.{field}", component, field)
        self.assertEqual(clip["required"], ["headline_ar"])

    def test_radio_layers_complete_in_every_look(self):
        component = (STARTER / "src/components/Presenter.tsx").read_text(encoding="utf-8")
        layers = {"body": ["neutral", "point_left", "point_right", "point_up", "explaining", "holding_paper", "thinking"],
                  "eyes": ["blink", "left", "right", "up", "wide"], "mouth": ["mid", "open"]}
        import radio_pack
        index, _ = radio_pack.read_index()
        self.assertEqual(len(index), 42)
        for look in radio_pack.LOOKS:
            for kind, parts in layers.items():
                for name in parts:
                    self.assertGreater(index[f"{look}/{kind}_{name}.webp"][1], 1500)
                    self.assertIn(f"'{name}'", component)
        with tempfile.TemporaryDirectory() as tmp:
            files = radio_pack.extract(tmp, "tactical", flat=True)
            self.assertEqual(len(files), 14)
            data = (Path(tmp) / "body_neutral.webp").read_bytes()
            self.assertEqual((data[:4], data[8:12]), (b"RIFF", b"WEBP"))

    def test_sprite_sheets_and_index(self):
        icons = json.loads((STARTER / "src/icons.json").read_text(encoding="utf-8"))
        sprites = icons["_sprites"]
        self.assertEqual(len(sprites["items"]), 32)
        cells = set()
        for name, (sheet, col, row) in sprites["items"].items():
            self.assertIn(sheet, sprites["sheets"])
            self.assertTrue(0 <= col < sprites["cols"] and 0 <= row < sprites["rows"], name)
            cells.add((sheet, col, row))
        self.assertEqual(len(cells), 32)  # no two names share a cell
        for rel in sprites["sheets"].values():
            data = (STARTER / "public" / rel).read_bytes()
            self.assertEqual((data[:4], data[8:12]), (b"RIFF", b"WEBP"))
        self.assertEqual(len(list((STARTER / "public/icons").iterdir())), 2)  # two sheets, not one file per icon
        names = set(sprites["items"])
        layer = json.loads((ROOT / "schemas/map-data.schema.json").read_text(encoding="utf-8"))["properties"]["layers"]["items"]["properties"]
        shot = json.loads((ROOT / "schemas/shot-plan.schema.json").read_text(encoding="utf-8"))["properties"]["shots"]["items"]["properties"]
        self.assertEqual(set(layer["icon"]["enum"]), names)
        self.assertEqual(set(shot["icon"]["enum"]) - {None}, names)
        library = (ROOT / "libraries/map-elements.yaml").read_text(encoding="utf-8")
        for name in names:
            self.assertIn(name, library)

    def test_satellite_plan_and_countries(self):
        import fetch_basemap
        plan = fetch_basemap.plan(fetch_basemap.grow([24, 22, 37, 32], 0.35), 3000, "eox")
        self.assertTrue(1 <= plan["zoom"] <= 13)
        self.assertLessEqual(plan["cols"] * plan["rows"], 1100)
        self.assertGreaterEqual(plan["cols"] * 256, 3000)
        self.assertAlmostEqual(fetch_basemap.inv_merc_y(fetch_basemap.merc_y(30.0)), 30.0, places=6)
        with self.assertRaises(ValueError):
            fetch_basemap.grow([10, 5, 5, 10], 0.1)
        countries = json.loads((ROOT / "assets/geo/ne_50m_countries.geojson").read_text(encoding="utf-8"))
        self.assertIn("public domain", countries["source"])
        isos = {f["properties"]["iso"] for f in countries["features"]}
        self.assertTrue({"EGY", "IRN", "USA", "CHN", "FRA"} <= isos)

    def test_find_assets_add_registers_without_gate(self):
        import find_assets
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "pic.png"
            src.write_bytes(b"\x89PNG fake")
            out = find_assets.add(Path(tmp) / "proj", src.as_uri(), "A-9", role="icon", page="https://example.org/p", creator="Someone", license_name="CC BY 4.0")
            self.assertEqual(out["file"], "assets/media/A-9.png")
            entry = json.loads((Path(tmp) / "proj/assets/asset-manifest.json").read_text(encoding="utf-8"))["assets"][0]
            self.assertEqual((entry["license_status"], entry["exact_item_url"], entry["attribution_text"]), ("unchecked", "https://example.org/p", "Someone"))
            with self.assertRaises(ValueError):
                find_assets.add(Path(tmp) / "proj", src.as_uri(), "bad id!")

    def test_find_assets_retries_and_survives_a_dead_source(self):
        import io
        import urllib.error
        import find_assets
        calls = {"n": 0}

        class Reply(io.BytesIO):
            headers = {"Content-Type": "application/json"}
            def __enter__(self): return self
            def __exit__(self, *a): return False

        def flaky(req, timeout=0):
            calls["n"] += 1
            if calls["n"] < 3:
                raise urllib.error.HTTPError(req.full_url, 504, "Gateway Timeout", {}, None)
            return Reply(b'{"ok": true}')

        real_open, real_sleep = find_assets.urllib.request.urlopen, find_assets.time.sleep
        find_assets.urllib.request.urlopen, find_assets.time.sleep = flaky, lambda s: None
        try:
            self.assertEqual(find_assets._json("https://example.org/x"), {"ok": True})   # two 504s, then success
            self.assertEqual(calls["n"], 3)

            def refused(req, timeout=0):
                calls["n"] += 1
                raise urllib.error.HTTPError(req.full_url, 403, "Forbidden", {}, None)
            calls["n"] = 0
            find_assets.urllib.request.urlopen = refused
            with self.assertRaises(urllib.error.HTTPError):
                find_assets._get("https://example.org/x")
            self.assertEqual(calls["n"], 1)                                             # a refusal is not retried
        finally:
            find_assets.urllib.request.urlopen, find_assets.time.sleep = real_open, real_sleep
        saved = dict(find_assets.SOURCES)
        try:
            find_assets.SOURCES["openverse"] = lambda q, n: (_ for _ in ()).throw(TimeoutError())
            find_assets.SOURCES["commons"] = lambda q, n: [{"source": "commons", "title": "x"}]
            find_assets.SOURCES["nasa"] = find_assets.SOURCES["archive"] = lambda q, n: []
            results, errors = find_assets.search("anything")
            self.assertEqual(len(results), 1)
            self.assertEqual(len(errors), 1)
            self.assertIn("openverse", errors[0])
        finally:
            find_assets.SOURCES.update(saved)
        self.assertEqual(find_assets.GROUPS["icons"][0], "iconify")

    def test_wow_verdict_rules(self):
        import wow_check
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as tmp:
            qa = Path(tmp) / "qa"
            qa.mkdir()
            shots = [{"shot_id": "S-001", "status": "PASS"}, {"shot_id": "S-002", "status": "PASS"}]
            (qa / "wow-measure.json").write_text(json.dumps({"status": "PASS", "shots": shots, "reference": None}), encoding="utf-8")
            def verdict(sheet):
                (qa / "scores.json").write_text(json.dumps(sheet), encoding="utf-8")
                return wow_check.cmd_verdict(SimpleNamespace(project=tmp))
            good = {c: 9 for c in wow_check.CRITERIA}
            self.assertEqual(verdict({"shots": {}})["status"], "FAIL")                                   # nothing scored
            weak = verdict({"shots": {"S-001": good, "S-002": {**good, "motion": 5}}, "weakest_shot_and_why": "S-002 is static"})
            self.assertIn("S-002: motion scored 5", " ".join(weak["problems"]))
            same = verdict({"shots": {"S-001": good, "S-002": good}, "weakest_shot_and_why": "x"})
            self.assertIn("identical", " ".join(same["problems"]))                                     # no rubber-stamping
            ok = verdict({"shots": {"S-001": good, "S-002": {**good, "detail": 8}}, "weakest_shot_and_why": "S-002: fewer layers"})
            self.assertEqual((ok["status"], ok["problems"]), ("PASS", []))
            self.assertIn("weakest", " ".join(verdict({"shots": {"S-001": good, "S-002": {**good, "detail": 8}}})["problems"]))

    @unittest.skipUnless(shutil.which("ffmpeg"), "FFmpeg not installed")
    def test_wow_measure_catches_a_dead_shot(self):
        import wow_check
        with tempfile.TemporaryDirectory() as tmp:
            dead, alive = Path(tmp) / "dead.mp4", Path(tmp) / "alive.mp4"
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=gray:s=320x180:d=4", str(dead)], check=True)
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=320x180:d=4", str(alive)], check=True)
            _, a = wow_check.measure_video(dead)
            _, b = wow_check.measure_video(alive)
            self.assertEqual(a[0]["status"], "FAIL")
            self.assertTrue(any("nothing moves" in p for p in a[0]["problems"]))
            self.assertEqual(b[0]["status"], "PASS")

    def test_align_words_helpers(self):
        import align_words
        self.assertEqual(align_words.merge_to([(0, 1), (1.1, 2), (3, 4)], 2), [(0, 2), (3, 4)])
        self.assertEqual([p for p in align_words.SPLIT.split("جملة أولى. جملة تانية، وتالتة") if p.strip()], ["جملة أولى.", "جملة تانية،", "وتالتة"])

    def test_theme_implements_every_style_in_the_specs(self):
        theme = (STARTER / "src/theme.ts").read_text(encoding="utf-8")
        specs = (ROOT / "libraries/style-specs.yaml").read_text(encoding="utf-8")
        for style in ("cinematic-war-map", "modern-tactical", "archival-atlas", "satellite", "bold-kinetic", "cinematic-minimal", "infographic-arabic"):
            self.assertIn(f"'{style}'", theme)
            self.assertIn(f"  {style}:", specs)

    @unittest.skipUnless(shutil.which("ffmpeg"), "FFmpeg not installed")
    def test_style_check_recognises_each_reference(self):
        import style_check
        refs = style_check.references()
        self.assertEqual(sorted(refs), ["archival-atlas", "cinematic-war-map", "modern-tactical"])
        for style, path in refs.items():
            result = style_check.check(style_check.pixels(path), style, refs)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["closest_reference"], style)
        wrong = style_check.check(style_check.pixels(refs["modern-tactical"]), "cinematic-war-map", refs)
        self.assertEqual(wrong["status"], "REVIEW_REQUIRED")
        done = run("style_check.py", "--frame", str(refs["archival-atlas"]), "--style", "modern-tactical")
        self.assertEqual(done.returncode, 2)


if __name__ == "__main__":
    unittest.main()
