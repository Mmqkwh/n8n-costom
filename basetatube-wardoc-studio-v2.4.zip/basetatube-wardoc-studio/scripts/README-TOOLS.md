# Local developer tools

All paths are relative to the skill root; project files live in `output/<slug>/`.

| Command | What it does |
|---|---|
| `python scripts/route.py "<prompt>"` | Chooses free / higgs / both from `routing/mode-router.json`. Never generates or charges. |
| `python scripts/new_project.py --topic "<topic>" --slug <slug> --out output` | Creates the research-empty project scaffold. |
| `python scripts/make_narration.py --text-file output/<slug>/production/narration.txt --output output/<slug>/audio/narration.mp3 --subtitles output/<slug>/audio/narration.srt [--voice salma] [--rate=-8%]` | Edge TTS narration: MP3 + SRT + `narration.words.json`. Needs `pip install edge-tts`, network and usage rights. `--dry-run` works offline. |
| `python scripts/srt_to_captions.py --words output/<slug>/audio/narration.words.json --output output/<slug>/production/captions.json --style bold-kinetic` | Word-level captions (preferred). Use `--input <file.srt>` for phrase-level. |
| `python scripts/make_music.py --cue-sheet output/<slug>/production/music-cues.json --output output/<slug>/audio/original-score.wav [--duration N --scale-cues]` | Offline original soundtrack, Python stdlib only. |
| `python scripts/mix_audio.py --voice output/<slug>/audio/narration.mp3 --music output/<slug>/audio/original-score.wav --output output/<slug>/audio/documentary-mix.m4a [--fit voice]` | FFmpeg mix with ducking. |
| `python scripts/build_remotion_project.py --project output/<slug> [--force] [--allow-placeholders]` | Builds `output/<slug>/remotion/` and writes `production/render_commands.md`. `--demo` uses fictional data. |
| `python scripts/style_check.py --video output/<slug>/remotion/out/documentary.mp4 --project output/<slug>` | Compares each map shot with its style reference (colour and tonality). `--frame <png> --style <id>` checks one still. Needs FFmpeg. |
| `python scripts/clip_basemap.py --bbox W S E N --out output/<slug>/assets/geo/land.geojson [--source ne_10m_land.geojson]` | Cuts modern coastlines for one map from the bundled Natural Earth 1:50m land (or a finer file). |
| `python scripts/make_sfx.py --out <folder>` | Code-synthesised whoosh / hit / typewriter / ping WAVs. The builder runs this by itself. |
| `python scripts/make_presenter_assets.py --out output/<slug>/assets/presenter --variant cinematic` | Regenerates the 12 SVG poses of one variant (`all` = three variants; + demo GIF with CairoSVG and Pillow). |
| `python scripts/export_map_symbols.py --out <folder>` | Writes the unit and event symbols as editable SVG files. |
| `python scripts/fetch_basemap.py --bbox W S E N --out output/<slug>/assets/geo/satellite.jpg [--provider eox|nasa|esri]` | Fetches and stitches a satellite picture for one map (network + FFmpeg). The builder does this itself when `basemap.satellite` is set. |
| `python scripts/align_words.py --audio <narration> --text <script.txt> --output audio/narration.words.json` | Word timings for audio that came without them (recorded voice, ElevenLabs): real pauses + estimate. Offline fallback to speech-to-text. |
| `python scripts/key_video.py --input clip.mp4 --output output/<slug>/assets/presenter/talk/<shot_id>.webm` | Removes a green background from a generated host clip (alpha .webm). |
| `python scripts/find_assets.py search "<words>"` / `add --project output/<slug> --url <url> --id A-001` | Finds pictures on Openverse, Wikimedia Commons, NASA and the Internet Archive, and icons on Iconify (`--source icons`), with retries and per-source fallback; downloads any picture, icon or clip by URL and registers it in the manifest. |
| `python scripts/wow_check.py measure --project output/<slug> [--reference film.mp4]` then `verdict --project output/<slug>` | Mandatory gate after rendering: measures movement, colour and fullness of every shot against a reference level, saves frames for review, then checks the scores given by eye. |
| `python scripts/run_tests.py` | Runs every offline self-test. |
| `python scripts/validate_skill.py` | Package validator (needs PyYAML + jsonschema on the validator machine only). |

Statuses the scripts print: `PLAN_ONLY`, `VOICE_NEEDED`, `READY_FOR_MIX`, `READY_FOR_RENDER`, `RENDERED`, `CONVERTED`. A non-`RENDERED` status exits with code 2.
