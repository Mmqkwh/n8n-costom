#!/usr/bin/env python3
"""Convert real narration timing to typed, RTL-ready Remotion captions JSON.

Two inputs are supported:
  --words narration.words.json   word-level timestamps (preferred; kinetic word highlight)
  --input narration.srt          phrase/sentence timestamps (fallback)
"""
import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TIMING = re.compile(r"^\s*(\d{2}):(\d{2}):(\d{2})[,\.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,\.](\d{3})\s*$")
FALLBACK_STYLES = {"cinematic-minimal": 7, "bold-kinetic": 5, "infographic-arabic": 6}
SENTENCE_END = ".!?؟…"


def load_styles():
    """Read style ids and max_words_per_beat from libraries/subtitle-styles.yaml (no PyYAML needed)."""
    path = ROOT / "libraries" / "subtitle-styles.yaml"
    styles = {}
    try:
        current = None
        for line in path.read_text(encoding="utf-8").splitlines():
            m = re.match(r"\s*-\s*id:\s*([\w-]+)", line)
            if m:
                current = m.group(1)
                styles[current] = FALLBACK_STYLES.get(current, 6)
            m = re.match(r"\s*max_words_per_beat:\s*(\d+)", line)
            if m and current:
                styles[current] = int(m.group(1))
    except OSError:
        pass
    return styles or dict(FALLBACK_STYLES)


STYLES = load_styles()


def parse_time(g):
    hh, mm, ss, ms = map(int, g)
    if mm >= 60 or ss >= 60:
        raise ValueError("Invalid SRT timestamp")
    return hh * 3600 + mm * 60 + ss + ms / 1000.0


def _segment(st, en, text, style, words=None):
    seg = {"start_sec": st, "end_sec": en, "text_ar": text, "highlight_ar": None, "style_id": style, "claim_ids": []}
    if words:
        seg["words"] = words
    return seg


def convert(text, style):
    """SRT text -> captions with sentence/phrase timing."""
    if style not in STYLES:
        raise ValueError(f"Invalid style {style}")
    segments = []
    for block in re.split(r"\r?\n\s*\r?\n", text.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        if lines[0].isdigit():
            lines = lines[1:]
        if not lines:
            continue
        match = TIMING.fullmatch(lines[0])
        if not match:
            raise ValueError(f"Invalid SRT timing line: {lines[0]}")
        st, en = parse_time(match.groups()[:4]), parse_time(match.groups()[4:])
        content = " ".join(lines[1:]).strip()
        if not content or en <= st:
            raise ValueError("Missing text or non-positive segment duration")
        if segments and st < segments[-1]["start_sec"]:
            raise ValueError("SRT must be chronologically ordered")
        segments.append(_segment(st, en, content, style))
    if not segments:
        raise ValueError("No usable SRT segments")
    return {"language": "ar-EG", "timing_status": "actual_sentence_timestamps", "segments": segments}


def convert_words(doc, style, max_words=None, pause=0.40):
    """Word timestamp JSON -> short caption beats with per-word timing."""
    if style not in STYLES:
        raise ValueError(f"Invalid style {style}")
    words = doc.get("words") if isinstance(doc, dict) else doc
    if not words:
        raise ValueError("No words in word-timestamp file")
    max_words = max_words or STYLES[style]
    clean, last = [], -1.0
    for w in words:
        st, en, tx = float(w["start_sec"]), float(w["end_sec"]), str(w["text"]).strip()
        if not tx or en <= st or st < last:
            raise ValueError(f"Invalid word timing: {w}")
        clean.append({"text": tx, "start_sec": round(st, 3), "end_sec": round(en, 3)})
        last = st
    groups, current = [], []
    for i, w in enumerate(clean):
        current.append(w)
        nxt = clean[i + 1] if i + 1 < len(clean) else None
        gap = (nxt["start_sec"] - w["end_sec"]) if nxt else 0
        ends = w["text"].rstrip("\"'»)")[-1:] in SENTENCE_END
        natural = nxt is None or gap >= pause or ends
        if natural or len(current) >= max_words:
            groups.append((current, natural))
            current = []
    # Never leave a single orphan word after a beat that was cut only by the word limit.
    merged = []
    for words_, natural in groups:
        if merged and not merged[-1][1] and len(words_) == 1:
            merged[-1] = (merged[-1][0] + words_, natural)
        else:
            merged.append((words_, natural))
    segments = [_segment(g[0]["start_sec"], g[-1]["end_sec"], " ".join(x["text"] for x in g), style, g) for g, _ in merged]
    return {"language": "ar-EG", "timing_status": "actual_word_timestamps", "segments": segments}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", help="SRT file (sentence timing)")
    p.add_argument("--words", help="Word timestamp JSON from make_narration.py (preferred)")
    p.add_argument("--output", required=True)
    p.add_argument("--style", choices=sorted(STYLES), default="cinematic-minimal")
    p.add_argument("--max-words", type=int, help="Words per caption beat (default: the style's max_words_per_beat)")
    args = p.parse_args()
    if not args.input and not args.words:
        p.error("Give --words (preferred) or --input")
    if args.max_words is not None and not 1 <= args.max_words <= 12:
        p.error("--max-words must be 1..12")
    if args.words:
        source = Path(args.words)
        if not source.is_file():
            p.error("Word timestamp file does not exist")
        obj = convert_words(json.loads(source.read_text(encoding="utf-8")), args.style, args.max_words)
    else:
        source = Path(args.input)
        if not source.is_file():
            p.error("SRT input does not exist")
        obj = convert(source.read_text(encoding="utf-8-sig"), args.style)
    dest = Path(args.output)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "CONVERTED", "file": str(dest.resolve()), "segments": len(obj["segments"]),
                      "timing_status": obj["timing_status"]}))


if __name__ == "__main__":
    main()
