#!/usr/bin/env python3
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from route import CONFIG_PATH, decide

FREE = [
    "اعمل فيديو عن معركة العلمين",
    "Use MCP from another provider",
    "اعمل فيديو بدون هيجزفيلد",
    "اعمل فيديو من غير هيجزفيلد",
    "بدون استخدام هيجزفيلد",
    "لا أريد هيجزفيلد",
    "لا تستخدم هيجزفيلد",
    "مش عايز هيجز",
    "ماتستخدمش هيجزفيلد خالص",
    "اعمل الفيديو من غير ما تستخدم هيجزفيلد خالص، عايز النسخة المجانية.",
    "النسخة المجانية فقط مش هيجزفيلد",
    "Make it with no Higgsfield",
    "do not use higgsfield",
    "don't use Higgsfield",
    "Don\u2019t use Higgsfield please",
    "without using Higgsfield",
    "a free video instead of Higgsfield",
    "قارن بين معركة العلمين وستالينجراد",
    "فيديو عن فيزياء بوزون هيجز",
    "Peter Higgs biography documentary",
    "the Higgs boson explained",
    "",
]
HIGGS = [
    "اعمل فيديو معركة العلمين باستخدام هيجزفيلد MCP",
    "Make video using Higgsfield MCP",
    "استخدم Higgsfield",
    "اعمل الفيديو بهيجزفيلد",
    "عايز وثائقي عن ستالينجراد وهيجز يعمل اللقطات",
    "use Higgsfield, not the free route",
    "Rommel vs Montgomery using higgsfield",
    "قارن بين معركة العلمين وستالينجراد باستخدام هيجزفيلد",
    "No maps needed. Use Higgsfield for the cutaways.",
    "HIGGS FIELD please",
]
BOTH = [
    "قارن بين المسار المجاني وهيجزفيلد",
    "قارن إنتاج نفس 30 ثانية بمسار Remotion المجاني وبمسار هيجزفيلد MCP، وخلّي الخرائط الدقيقة مشتركة في النسختين.",
    "compare the free route with Higgsfield",
    "make both versions, one with higgsfield",
]


class RouterTest(unittest.TestCase):
    def check(self, prompts, mode):
        for prompt in prompts:
            with self.subTest(prompt=prompt):
                self.assertEqual(decide(prompt)["mode"], mode)

    def test_free(self):
        self.check(FREE, "free")

    def test_higgs(self):
        self.check(HIGGS, "higgs")

    def test_both(self):
        self.check(BOTH, "both")

    def test_structured_override(self):
        self.assertEqual(decide("هيجزفيلد", "free")["mode"], "free")
        self.assertEqual(decide("anything", "higgs")["mode"], "higgs")
        self.assertEqual(decide("قارن النسختين", "both")["mode"], "both")
        with self.assertRaises(ValueError):
            decide("x", "paid")

    def test_conflict_stays_free_and_asks(self):
        result = decide("بدون هيجزفيلد للخرائط. استخدم هيجزفيلد للصور")
        self.assertEqual(result["mode"], "free")
        self.assertTrue(result["needs_clarification"])

    def test_paid_generation_only_when_higgsfield_was_chosen(self):
        for prompt in FREE:
            self.assertFalse(decide(prompt)["paid_generation_allowed"])
        for prompt in HIGGS + BOTH:
            self.assertTrue(decide(prompt)["paid_generation_allowed"])
        self.assertTrue(decide("x", "higgs")["paid_generation_allowed"])
        self.assertFalse(decide("x", "free")["paid_generation_allowed"])
        self.assertFalse(decide("بدون هيجزفيلد للخرائط. استخدم هيجزفيلد للصور")["paid_generation_allowed"])   # conflict stays free

    def test_config_is_the_single_source(self):
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        for key in ["higgs_names", "higgs_short_names", "negation_words", "negation_phrases", "compare_words", "both_phrases", "free_identifiers"]:
            self.assertTrue(cfg[key], key)
        source = (Path(__file__).parent / "route.py").read_text(encoding="utf-8")
        self.assertNotIn("هيجزفيلد\"", source.split('"""', 2)[2])  # no keyword lists hard-coded in the code body


if __name__ == "__main__":
    unittest.main()
