#!/usr/bin/env python3
"""Cut a small basemap out of a land GeoJSON for one map's bounding box. Standard library only.

Default source: assets/geo/ne_50m_land.geojson (Natural Earth 1:50m land, public domain).
For battle-scale maps download the 1:10m file from naturalearthdata.com and pass it with --source.

The result shows MODERN coastlines. It is reference geography, never evidence of historical
borders or control; map-data.json must keep basemap.modern_reference = true.

Usage:
  python scripts/clip_basemap.py --bbox 24 28 34 33 --out output/<slug>/assets/geo/land.geojson
"""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "assets" / "geo" / "ne_50m_land.geojson"


def _clip_ring(ring, west, south, east, north):
    """Sutherland-Hodgman clip of one ring against a rectangle."""
    def clip(points, inside, intersect):
        out = []
        for i, cur in enumerate(points):
            prev = points[i - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(intersect(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(intersect(prev, cur))
        return out

    def x_cross(x):
        return lambda a, b: [x, a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])]

    def y_cross(y):
        return lambda a, b: [a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]), y]

    pts = ring[:-1] if ring and ring[0] == ring[-1] else list(ring)
    for inside, cross in ((lambda p: p[0] >= west, x_cross(west)), (lambda p: p[0] <= east, x_cross(east)),
                          (lambda p: p[1] >= south, y_cross(south)), (lambda p: p[1] <= north, y_cross(north))):
        if not pts:
            return []
        pts = clip(pts, inside, cross)
    if len(pts) < 3:
        return []
    pts = [[round(p[0], 4), round(p[1], 4)] for p in pts]
    return pts + [pts[0]]


def clip_collection(collection, bbox, margin=1.0):
    """Return a FeatureCollection with only the land inside bbox, grown by `margin` times its size on each side
    (the video frame is wider than the bbox and the camera needs room)."""
    west, south, east, north = bbox
    if not (west < east and south < north):
        raise ValueError("bbox must be west south east north with west<east and south<north")
    dx, dy = (east - west) * margin, (north - south) * margin
    box = (west - dx, max(-90.0, south - dy), east + dx, min(90.0, north + dy))
    features = []
    for feature in collection.get("features", []):
        geometry = feature.get("geometry") or {}
        if geometry.get("type") == "Polygon":
            polygons = [geometry["coordinates"]]
        elif geometry.get("type") == "MultiPolygon":
            polygons = geometry["coordinates"]
        else:
            continue
        kept = []
        for rings in polygons:
            xs = [p[0] for p in rings[0]]
            ys = [p[1] for p in rings[0]]
            if max(xs) < box[0] or min(xs) > box[2] or max(ys) < box[1] or min(ys) > box[3]:
                continue
            outer = _clip_ring(rings[0], *box)
            if not outer:
                continue
            holes = [h for h in (_clip_ring(r, *box) for r in rings[1:]) if h]
            kept.append([outer] + holes)
        if kept:
            features.append({"type": "Feature", "properties": {}, "geometry": {"type": "MultiPolygon", "coordinates": kept}})
    return {"type": "FeatureCollection",
            "source": collection.get("source", "user supplied land GeoJSON"),
            "note": "MODERN coastlines for reference only. Not historical borders or control.",
            "clip_bbox": [round(v, 4) for v in box], "features": features}


def _box(bbox, margin):
    west, south, east, north = bbox
    if not (west < east and south < north):
        raise ValueError("bbox must be west south east north with west<east and south<north")
    dx, dy = (east - west) * margin, (north - south) * margin
    return (max(-180.0, west - dx), max(-90.0, south - dy), min(180.0, east + dx), min(90.0, north + dy))


def clip_lines(collection, bbox, margin=1.0):
    """Keep the parts of LineString / MultiLineString features that lie inside the grown bbox."""
    box = _box(bbox, margin)
    features = []
    for feature in collection.get("features", []):
        geometry = feature.get("geometry") or {}
        if geometry.get("type") == "LineString":
            lines = [geometry["coordinates"]]
        elif geometry.get("type") == "MultiLineString":
            lines = geometry["coordinates"]
        else:
            continue
        kept = []
        for line in lines:
            run = []
            for point in line:
                if box[0] <= point[0] <= box[2] and box[1] <= point[1] <= box[3]:
                    run.append([round(point[0], 4), round(point[1], 4)])
                else:
                    if len(run) >= 2:
                        kept.append(run)
                    run = []
            if len(run) >= 2:
                kept.append(run)
        if kept:
            features.append({"type": "Feature", "properties": {"rank": (feature.get("properties") or {}).get("rank", 6)},
                             "geometry": {"type": "MultiLineString", "coordinates": kept}})
    return {"type": "FeatureCollection", "source": collection.get("source", "user supplied lines"),
            "note": "MODERN courses for reference only.", "features": features}


def crop_relief(bbox, out_path, margin=1.0, source=None, max_width=2400):
    """Cut the shaded-relief picture for the grown bbox with FFmpeg. Returns the bbox the picture covers, or None without FFmpeg."""
    import shutil
    import subprocess
    source = Path(source) if source else ROOT / "assets" / "geo" / "ne_shaded_relief.webp"
    if not shutil.which("ffmpeg") or not source.is_file():
        return None
    box = _box(bbox, margin)
    width, height = 10800, 5400
    x0, x1 = int((box[0] + 180) / 360 * width), int(round((box[2] + 180) / 360 * width))
    y0, y1 = int((90 - box[3]) / 180 * height), int(round((90 - box[1]) / 180 * height))
    w, h = max(2, x1 - x0), max(2, y1 - y0)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # The source is mostly light grey (flat land about 225); stretch it so slopes read clearly when multiplied over the paper.
    scale = f",scale={max_width}:-2:flags=bicubic" if w < max_width else ""
    done = subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", str(source), "-vf",
                           f"crop={w}:{h}:{x0}:{y0},format=gray,lutyuv=y='clip((val-150)*3.1+50\\,0\\,255)'{scale}", "-c:v", "libwebp", "-quality", "70", str(out_path)],
                          capture_output=True, text=True)
    if done.returncode != 0 or not out_path.is_file():
        return None
    # the exact area the cropped pixels cover
    return [x0 / width * 360 - 180, 90 - y1 / height * 180, x1 / width * 360 - 180, 90 - y0 / height * 180]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--bbox", nargs=4, type=float, required=True, metavar=("WEST", "SOUTH", "EAST", "NORTH"))
    p.add_argument("--out", required=True)
    p.add_argument("--source", default=str(DEFAULT_SOURCE), help="Land polygons GeoJSON (default: bundled Natural Earth 1:50m)")
    p.add_argument("--margin", type=float, default=1.0)
    a = p.parse_args()
    source = Path(a.source)
    if not source.is_file():
        p.error(f"Source not found: {source}")
    try:
        result = clip_collection(json.loads(source.read_text(encoding="utf-8")), a.bbox, a.margin)
    except ValueError as err:
        p.error(str(err))
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, separators=(",", ":")), encoding="utf-8")
    print(json.dumps({"status": "CLIPPED", "file": str(out.resolve()), "features": len(result["features"]),
                      "modern_reference": True, "source": result["source"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
