#!/usr/bin/env python3
"""Coarse style check: does a rendered frame look like its visual-style reference? Needs FFmpeg.

It compares colour palette, brightness and saturation of the frame with all visual style references
in assets/style-references/ and passes when the intended style is the closest one and close enough.
This is a blunt colour/tonality check, not a judgement of layout or accuracy. When image viewing is
available, also look at the frame next to the reference before signing the QA report.

Usage:
  python scripts/style_check.py --frame out/preview.png --style cinematic-war-map
  python scripts/style_check.py --video output/<slug>/remotion/out/documentary.mp4 --project output/<slug>
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
W, H = 64, 36
MIN_SCORE = 0.50
MARGIN = 0.03


def references():
    """style id -> reference image path, read from libraries/visual-styles.yaml without PyYAML."""
    refs, current = {}, None
    for line in (ROOT / "libraries" / "visual-styles.yaml").read_text(encoding="utf-8").splitlines():
        m = re.match(r"\s*-\s*id:\s*([\w-]+)", line)
        if m:
            current = m.group(1)
        m = re.match(r"\s*reference:\s*(\S+)", line)
        if m and current and m.group(1) not in ("null", "~"):
            refs[current] = ROOT / m.group(1)
    return refs


def pixels(path, at=None):
    cmd = ["ffmpeg", "-loglevel", "error"]
    if at is not None:
        cmd += ["-ss", f"{at:.3f}"]
    cmd += ["-i", str(path), "-frames:v", "1", "-vf", f"scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    done = subprocess.run(cmd, capture_output=True)
    if done.returncode != 0 or len(done.stdout) < W * H * 3:
        raise RuntimeError(f"FFmpeg could not read {path}: {done.stderr.decode(errors='ignore')[-200:]}")
    data = done.stdout[:W * H * 3]
    return [(data[i], data[i + 1], data[i + 2]) for i in range(0, len(data), 3)]


def features(px):
    hist = [0.0] * 64
    lum = sat = warm = 0.0
    for r, g, b in px:
        hist[(r >> 6) * 16 + (g >> 6) * 4 + (b >> 6)] += 1
        mx, mn = max(r, g, b), min(r, g, b)
        lum += (0.299 * r + 0.587 * g + 0.114 * b) / 255
        sat += (mx - mn) / mx if mx else 0
        warm += (r - b) / 255
    n = len(px)
    return {"hist": [h / n for h in hist], "lum": lum / n, "sat": sat / n, "warm": warm / n}


def similarity(a, b):
    palette = sum(min(x, y) for x, y in zip(a["hist"], b["hist"]))
    return round(0.45 * palette + 0.2 * (1 - abs(a["lum"] - b["lum"])) + 0.1 * (1 - abs(a["sat"] - b["sat"]))
                 + 0.25 * (1 - min(1.0, abs(a["warm"] - b["warm"]) * 2.5)), 4)


def check(frame_px, style, refs=None):
    refs = refs or references()
    if style not in refs:
        raise ValueError(f"Unknown style {style}; choose one of {sorted(refs)}")
    f = features(frame_px)
    scores = {sid: similarity(f, features(pixels(path))) for sid, path in refs.items()}
    best = max(scores, key=scores.get)
    ok = scores[style] >= MIN_SCORE and scores[style] >= scores[best] - MARGIN
    return {"style": style, "status": "PASS" if ok else "REVIEW_REQUIRED", "score": scores[style], "closest_reference": best, "scores": scores}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--frame", help="A rendered still (png/jpg)")
    p.add_argument("--style", help="Intended visual style id (with --frame)")
    p.add_argument("--video", help="Rendered video; map shots are sampled using the project's shot plan")
    p.add_argument("--project", help="Project folder (with --video)")
    a = p.parse_args()
    if not shutil.which("ffmpeg"):
        print(json.dumps({"status": "REVIEW_REQUIRED", "reason": "FFmpeg not available; compare the frame with the style reference by eye"}))
        sys.exit(2)
    results = []
    try:
        if a.frame:
            if not a.style:
                p.error("--frame needs --style")
            results.append(check(pixels(a.frame), a.style))
        elif a.video and a.project:
            plan = json.loads((Path(a.project) / "production" / "shot-plan.json").read_text(encoding="utf-8"))
            refs = references()
            for shot in plan.get("shots", []):
                if shot.get("shot_type") != "map_graphic" or shot.get("style_id") not in refs:
                    continue
                at = shot["start_sec"] + (shot["end_sec"] - shot["start_sec"]) * 0.7
                results.append({"shot_id": shot["shot_id"], "at_sec": round(at, 2), **check(pixels(a.video, at), shot["style_id"], refs)})
            if not results:
                p.error("No map shots with a known style in the shot plan")
        else:
            p.error("Give --frame with --style, or --video with --project")
    except (RuntimeError, ValueError, OSError) as err:
        print(json.dumps({"status": "REVIEW_REQUIRED", "reason": str(err)}, ensure_ascii=False))
        sys.exit(2)
    status = "PASS" if all(r["status"] == "PASS" for r in results) else "REVIEW_REQUIRED"
    print(json.dumps({"status": status, "checks": results,
                      "note": "Colour/tonality check only. Also compare layout with the reference image by eye."}, ensure_ascii=False, indent=2))
    if status != "PASS":
        sys.exit(2)


if __name__ == "__main__":
    main()
