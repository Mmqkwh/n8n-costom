#!/usr/bin/env python3
"""Optional Edge TTS adapter with honest failures. Requires an allowed network path.

Edge TTS is an unofficial client of Microsoft's Edge speech service. It is not
an offline model, and availability / usage permission are not guaranteed.

Outputs (only when the service really returns audio):
  narration.mp3          spoken track
  narration.srt          phrase subtitles
  narration.words.json   word-level timestamps for kinetic captions (Python API path)
"""
import argparse
import asyncio
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

VOICES = {"shakir": "ar-EG-ShakirNeural", "salma": "ar-EG-SalmaNeural"}
RATE_RE = re.compile(r"^[+-]\d{1,3}%$")
STRIP = " \t\n\"'«»()[]{}.,;:!?،؛؟…-–—"
SENTENCE_END = ".!?؟…"


def _srt_time(sec):
    ms = max(0, round(sec * 1000))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def _bare(token):
    return token.strip(STRIP)


def restore_punctuation(words, script_text):
    """Attach the script's own spelling/punctuation to the timed words when they line up."""
    tokens = script_text.split()
    idx = 0
    for word in words:
        target = _bare(word["text"])
        for look in range(idx, min(idx + 4, len(tokens))):
            if _bare(tokens[look]) == target and target:
                word["text"] = tokens[look]
                idx = look + 1
                break
    return words


def group_phrases(words, max_words=7, pause=0.40):
    """Group timed words into caption phrases at pauses, sentence ends or max_words."""
    groups, current = [], []
    for i, word in enumerate(words):
        current.append(word)
        nxt = words[i + 1] if i + 1 < len(words) else None
        gap = (nxt["start_sec"] - word["end_sec"]) if nxt else 0
        ends_sentence = word["text"].rstrip("\"'»)")[-1:] in SENTENCE_END
        if nxt is None or len(current) >= max_words or gap >= pause or ends_sentence:
            groups.append(current)
            current = []
    return groups


def words_to_srt(words, max_words=7):
    blocks = []
    for n, group in enumerate(group_phrases(words, max_words), 1):
        text = " ".join(w["text"] for w in group)
        blocks.append(f"{n}\n{_srt_time(group[0]['start_sec'])} --> {_srt_time(group[-1]['end_sec'])}\n{text}\n")
    return "\n".join(blocks)


async def _stream(text, voice, rate, output):
    import edge_tts
    try:
        comm = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    except TypeError:  # edge-tts < 7 has word boundaries by default
        comm = edge_tts.Communicate(text, voice, rate=rate)
    words = []
    with open(output, "wb") as f:
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                start = chunk["offset"] / 1e7
                words.append({"text": chunk["text"], "start_sec": round(start, 3),
                              "end_sec": round(start + chunk["duration"] / 1e7, 3)})
    return words


def _fail(reason, detail=None):
    out = {"status": "VOICE_NEEDED", "reason": reason,
           "fallback": "Use a user-recorded voice track or run in a network that permits Edge TTS. Do not claim a generated MP3."}
    if detail:
        out["diagnostic"] = str(detail)[-600:]
    return out


def generate(text_file, output, subtitles, voice="shakir", rate="-8%", timeout=180, dry_run=False, words_file=None):
    text_file, output, subtitles = map(Path, (text_file, output, subtitles))
    words_file = Path(words_file) if words_file else subtitles.with_suffix(".words.json")
    if not text_file.is_file() or not text_file.read_text(encoding="utf-8").strip():
        return {"status": "VOICE_NEEDED", "reason": "A non-empty UTF-8 narration script is required"}
    if voice not in VOICES:
        return {"status": "VOICE_NEEDED", "reason": f"Choose one of {list(VOICES)}"}
    if not RATE_RE.match(rate):
        return {"status": "VOICE_NEEDED", "reason": "rate must look like -8%, +0% or +5%"}
    text = text_file.read_text(encoding="utf-8").strip()
    cli = shutil.which("edge-tts")
    # NOTE: values starting with '-' must be passed as --rate=-8% (one token);
    # '--rate -8%' is rejected by edge-tts' argument parser.
    cmd = ([cli] if cli else [sys.executable, "-m", "edge_tts"]) + [
        "--voice", VOICES[voice], f"--rate={rate}",
        "--file", str(text_file), "--write-media", str(output), "--write-subtitles", str(subtitles)
    ]
    if dry_run:
        return {"status": "PLAN_ONLY", "voice": VOICES[voice], "command": cmd, "network_required": True,
                "word_timestamps": "written to %s when the edge_tts Python module is importable" % words_file.name}
    output.parent.mkdir(parents=True, exist_ok=True)
    subtitles.parent.mkdir(parents=True, exist_ok=True)

    # Preferred path: Python API, which also returns word-level timestamps.
    try:
        import edge_tts  # noqa: F401
        have_module = True
    except ImportError:
        have_module = False
    if have_module:
        try:
            words = asyncio.run(asyncio.wait_for(_stream(text, VOICES[voice], rate, output), timeout))
        except Exception as err:  # network denied, service change, timeout ...
            if output.exists():
                output.unlink()
            return _fail("Edge TTS request failed (%s)" % type(err).__name__, err)
        if not output.is_file() or output.stat().st_size == 0:
            return _fail("Edge TTS returned no audio")
        result = {"status": "RENDERED", "file": str(output.resolve()), "voice": VOICES[voice], "rate": rate}
        if words:
            words = restore_punctuation(words, text)
            subtitles.write_text(words_to_srt(words), encoding="utf-8")
            words_file.write_text(json.dumps({"language": "ar-EG", "voice": VOICES[voice], "words": words},
                                             ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            result.update(subtitles=str(subtitles.resolve()), words=str(words_file.resolve()),
                          timing="actual_word_timestamps", word_count=len(words))
        else:
            result.update(subtitles=None, words=None, timing="none",
                          note="Service returned audio without word boundaries; captions need estimated timing.")
        return result

    # Fallback path: CLI only (sentence-level SRT, no word timestamps).
    if not cli:
        return _fail("edge-tts is not installed (pip install edge-tts)")
    try:
        done = subprocess.run(cmd, timeout=timeout, capture_output=True, text=True, check=False)
    except (FileNotFoundError, subprocess.TimeoutExpired) as err:
        return _fail(type(err).__name__, err)
    if done.returncode != 0 or not output.is_file() or output.stat().st_size == 0:
        return _fail("edge-tts CLI failed (exit %s)" % done.returncode, done.stderr)
    return {"status": "RENDERED", "file": str(output.resolve()), "voice": VOICES[voice], "rate": rate,
            "subtitles": str(subtitles.resolve()) if subtitles.exists() else None, "words": None,
            "timing": "actual_sentence_timestamps"}


def main():
    p = argparse.ArgumentParser(description="Generate Arabic narration with Edge TTS where authorized")
    p.add_argument("--text-file", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--subtitles", required=True)
    p.add_argument("--words", help="Word timestamp JSON (default: <subtitles>.words.json)")
    p.add_argument("--voice", choices=list(VOICES), default="shakir")
    p.add_argument("--rate", default="-8%", help="Narration speed. Write it with '=' : --rate=-8%% , --rate=+0%% , --rate=+5%%")
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    result = generate(a.text_file, a.output, a.subtitles, a.voice, a.rate, a.timeout, a.dry_run, a.words)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "VOICE_NEEDED":
        sys.exit(2)


if __name__ == "__main__":
    main()
