#!/usr/bin/env python3
"""Package validator: entrypoint, YAML/JSON, schemas, templates, file references, starter, tests.

Requires pyyaml and jsonschema only for these QA checks; the runtime skill doesn't require them.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {"node_modules", "out", "__pycache__", "output", ".git", ".github"}   # repository-only folders are not part of the uploaded skill
REF_DIRS = ("system", "workflows", "libraries", "templates", "schemas", "scripts", "routing", "assets", "examples")
MAX_PACKAGE_MB = 15.0
MAX_ENTRIES = 190   # claude.ai upload limit is 200 files (the release zip is built with zip -D, without folder entries)


def main():
    try:
        import yaml
        from jsonschema import Draft202012Validator
    except ImportError:
        print("For package validation install pyyaml and jsonschema; production skill remains dependency-free")
        sys.exit(2)
    files = [p for p in ROOT.rglob("*") if p.is_file() and not (set(p.relative_to(ROOT).parts) & SKIP_DIRS)]
    errors = []

    # 1. Entrypoint
    entry = ROOT / "SKILL.md"
    if not entry.is_file():
        errors.append("Missing SKILL.md")
    else:
        m = re.match(r"\A---\n(.*?)\n---\n", entry.read_text(encoding="utf-8"), re.S)
        if not m:
            errors.append("Missing exact YAML frontmatter")
        else:
            front = yaml.safe_load(m.group(1))
            if front.get("name") != ROOT.name:
                errors.append("Skill folder name and YAML name mismatch")
            desc = front.get("description") or ""
            if not desc:
                errors.append("Missing skill description")
            if len(desc) > 1024:
                errors.append("Skill description longer than 1024 characters")

    # 2. Every YAML / JSON file parses
    for path in files:
        try:
            if path.suffix in {".yaml", ".yml"}:
                yaml.safe_load(path.read_text(encoding="utf-8"))
            elif path.suffix == ".json":
                json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            errors.append(f"Parse fail {path.relative_to(ROOT)}: {e}")

    # 3. Schemas are valid and every template/sample matches its schema
    schemas = {}
    for schema in (ROOT / "schemas").glob("*.schema.json"):
        try:
            doc = json.loads(schema.read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(doc)
            schemas[schema.name.replace(".schema.json", "")] = doc
        except Exception as e:
            errors.append(f"Invalid JSON schema {schema.name}: {e}")
    sample = "templates/remotion-starter/sample-data/"
    pairs = [
        ("production-brief", "templates/production-brief.example.json"), ("claims", "templates/claim-ledger.example.json"),
        ("shot-plan", "templates/shot-plan.example.json"), ("asset-manifest", "templates/asset-manifest.example.json"),
        ("captions", "templates/captions.example.json"), ("timeline", "templates/timeline.example.json"),
        ("map-data", "templates/map-data.example.json"),
        ("production-brief", sample + "brief.json"), ("shot-plan", sample + "shot-plan.json"),
        ("captions", sample + "captions.json"), ("map-data", sample + "map-data.json"),
    ]
    for stem, rel in pairs:
        try:
            instance = json.loads((ROOT / rel).read_text(encoding="utf-8"))
            for err in Draft202012Validator(schemas[stem]).iter_errors(instance):
                errors.append(f"{rel} doesn't match {stem} schema: {err.message[:160]}")
        except Exception as e:
            errors.append(f"Cannot validate {rel}: {e}")

    try:
        clip_schema = {"$schema": "https://json-schema.org/draft/2020-12/schema", **schemas["shot-plan"]["$defs"]["clipping"]}
        examples = json.loads((ROOT / "templates/clippings.example.json").read_text(encoding="utf-8"))
        for name, instance in examples.items():
            if name.startswith("_"):
                continue
            for err in Draft202012Validator(clip_schema).iter_errors(instance):
                errors.append(f"templates/clippings.example.json [{name}] doesn't match the clipping schema: {err.message[:160]}")
    except Exception as e:
        errors.append(f"Cannot validate clipping examples: {e}")

    # 4. Style references exist
    for library in ["visual-styles", "subtitle-styles"]:
        config = yaml.safe_load((ROOT / "libraries" / (library + ".yaml")).read_text(encoding="utf-8"))
        for style in config.get("visual_styles", config.get("subtitle_styles", [])):
            if style.get("reference") and not (ROOT / style["reference"]).is_file():
                errors.append(f"Missing reference asset: {style['reference']}")

    # 5. Every skill file mentioned in the docs/config exists
    pattern = re.compile(r"(?<![\w/.<>-])((?:%s)/[\w./-]+\.(?:md|ya?ml|json|py|csv|svg|webp|png|gif|tsx?))" % "|".join(REF_DIRS))
    for path in files:
        if path.suffix not in {".md", ".yaml", ".yml"} or "remotion-starter" in path.parts or path.name == "CHANGELOG.md":
            continue
        for ref in set(pattern.findall(path.read_text(encoding="utf-8"))):
            if "*" in ref or ref in ("assets/asset-manifest.json", "assets/geo/land.geojson", "assets/flag.png") or ref.startswith("assets/media/") or ref.startswith("assets/presenter/"):
                continue
            if not (ROOT / ref).is_file():
                errors.append(f"{path.relative_to(ROOT)} mentions a file that does not exist: {ref}")

    # 6. Router config, starter and consistency rules
    if (ROOT / "routing" / "mode-router.yaml").exists():
        errors.append("routing/mode-router.yaml must not exist; routing/mode-router.json is the single source")
    starter = ROOT / "templates" / "remotion-starter"
    for rel in ["package.json", "tsconfig.json", "src/index.ts", "src/Root.tsx", "src/Documentary.tsx", "src/fonts.ts", "src/theme.ts",
                "src/components/MapShot.tsx", "src/components/MediaShot.tsx", "src/components/CardShot.tsx",
                "src/components/Captions.tsx", "src/components/Presenter.tsx", "src/components/Badge.tsx", "src/components/Texture.tsx",
                "src/components/MapFurniture.tsx", "src/components/Transition.tsx", "src/components/LowerThird.tsx", "src/components/Icon.tsx",
                "src/geo.ts", "src/icons.json", "public/fonts/fonts.json", "public/textures/parchment.webp", "public/textures/desk.webp", "public/atmosphere/desert.webp",
                "public/silhouettes/tank.png", "src/components/Atmosphere.tsx", "src/components/Clipping.tsx", "public/icons/military.webp", "src/data/water.json", "sample-data/basemap.json"]:
        if not (starter / rel).is_file():
            errors.append(f"Remotion starter is missing {rel}")
    try:
        deps = json.loads((starter / "package.json").read_text(encoding="utf-8"))["dependencies"]
        versions = {deps[k] for k in deps if k == "remotion" or k.startswith("@remotion/")}
        if len(versions) != 1 or not re.fullmatch(r"\d+\.\d+\.\d+", next(iter(versions))):
            errors.append("All remotion packages must be pinned to the same exact version")
    except Exception as e:
        errors.append(f"Bad starter package.json: {e}")
    specs = yaml.safe_load((ROOT / "libraries/style-specs.yaml").read_text(encoding="utf-8"))
    visual = {v["id"] for v in yaml.safe_load((ROOT / "libraries/visual-styles.yaml").read_text(encoding="utf-8"))["visual_styles"]}
    subtitle = {v["id"] for v in yaml.safe_load((ROOT / "libraries/subtitle-styles.yaml").read_text(encoding="utf-8"))["subtitle_styles"]}
    if set(specs["visual_styles"]) != visual or set(specs["caption_styles"]) != subtitle:
        errors.append("libraries/style-specs.yaml must describe exactly the styles in visual-styles.yaml and subtitle-styles.yaml")
    poses = yaml.safe_load((ROOT / "libraries/presenter-poses.yaml").read_text(encoding="utf-8"))["free_presenter"]["poses"]
    affiliate = "https://higgsfield.ai/?fpr=discount"
    for rel in ["system/rules-higgs.md", "libraries/higgs-models.yaml"]:
        if affiliate not in (ROOT / rel).read_text(encoding="utf-8"):
            errors.append(f"Affiliate link missing from {rel}")
    for path in files:
        if path.suffix == ".md" and re.search(r"\b[78] (bundled SVG )?pose", path.read_text(encoding="utf-8")) and path.name != "CHANGELOG.md":
            errors.append(f"{path.relative_to(ROOT)} still gives an old pose count (there are 12)")
    if len(files) > MAX_ENTRIES:
        errors.append(f"{len(files)} files; Claude on the web rejects skills over 200 files, keep it at {MAX_ENTRIES} or fewer")
    for path in files:
        with open(path, "rb") as fh:
            if path.suffix.lower() in {".zip", ".skill"} or fh.read(4) == b"PK\x03\x04":
                errors.append(f"{path.relative_to(ROOT)} is a zip; Claude on the web rejects skills that contain nested zip files")
    size_mb = sum(p.stat().st_size for p in files) / 1e6
    if size_mb > MAX_PACKAGE_MB:
        errors.append(f"Package is {size_mb:.1f} MB; keep it under {MAX_PACKAGE_MB} MB (compress style references)")

    # 7. Self-tests
    tests = subprocess.run([sys.executable, str(ROOT / "scripts" / "run_tests.py")], capture_output=True, text=True)
    if tests.returncode != 0:
        errors.append("Self-tests failed:\n" + tests.stderr[-1500:])

    if errors:
        for e in errors:
            print("ERROR", e)
        sys.exit(1)
    summary = (tests.stderr.strip().splitlines() or ["tests ran"])[-3]
    print(f"PASS: {len(files)} files, {size_mb:.2f} MB; entrypoint, YAML/JSON, schemas, templates, file references, starter and self-tests OK ({summary})")


if __name__ == "__main__":
    main()
