#!/usr/bin/env python3
"""Create *honest*, source-empty research and storyboard scaffolds.

This intentionally does not fetch, invent research, download media, or render videos.
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from route import decide

ROOT = Path(__file__).resolve().parents[1]


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--topic", required=True)
    p.add_argument("--slug", required=True)
    p.add_argument("--mode", choices=["auto", "free", "higgs", "both"], default="auto")
    p.add_argument("--out", default="output")
    args = p.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{1,64}", args.slug):
        p.error("Slug must be 2-65 ASCII lowercase characters / digits / '-' / '_'")
    dest = (Path(args.out) / args.slug).resolve()
    if dest.exists() and any(dest.iterdir()):
        p.error("Output folder already contains files; refusing overwrite")
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "research").mkdir(exist_ok=True)
    (dest / "production").mkdir(exist_ok=True)
    (dest / "assets").mkdir(exist_ok=True)
    (dest / "audio").mkdir(exist_ok=True)
    mode_info = decide(args.topic, args.mode)
    brief = json.loads((ROOT / "templates/production-brief.example.json").read_text(encoding="utf-8"))
    brief.update(topic=args.topic, mode=mode_info["mode"])
    write_json(dest / "production-brief.json", brief)
    write_json(dest / "route-decision.json", mode_info)
    (dest / "research/source-log.csv").write_text((ROOT / "templates/source-log.template.csv").read_text(encoding="utf-8"), encoding="utf-8")
    write_json(dest / "research/claims.json", {"claims": []})
    write_json(dest / "research/timeline.json", {"events": []})
    (dest / "research/research-dossier.md").write_text("# Research dossier — RESEARCH_REQUIRED\n\nDo not add historical claims without source IDs and evidence.\n", encoding="utf-8")
    (dest / "production/script.ar.md").write_text("# سيناريو عربي — بانتظار البحث والتوثيق\n", encoding="utf-8")
    write_json(dest / "production/shot-plan.json", {"duration_seconds": 60, "fps": 30, "shots": []})
    write_json(dest / "production/captions.json", {"language": "ar-EG", "timing_status": "estimated", "segments": []})
    (dest / "production/narration.txt").write_text("", encoding="utf-8")
    (dest / "production/music-cues.json").write_text((ROOT / "templates/music-cues.example.json").read_text(encoding="utf-8"), encoding="utf-8")
    (dest / "production/map-data.json").write_text((ROOT / "templates/map-data.example.json").read_text(encoding="utf-8"), encoding="utf-8")
    (dest / "research/research-open-questions.md").write_text("# Open research questions\n\nList every gap, contested point or unverified number here. Empty file = nothing reviewed yet, not 'no open questions'.\n", encoding="utf-8")
    (dest / "production/render_commands.md").write_text("# Render commands\n\nNot built yet. After research, script, shot plan and captions exist, run:\n\n```bash\npython scripts/build_remotion_project.py --project \"%s\"\n```\n\nThat command rewrites this file with the exact install/render commands.\n" % dest, encoding="utf-8")
    (dest / "audio/README.txt").write_text("Real outputs only: narration.mp3 / narration.srt / narration.words.json via Edge TTS (network-dependent); original-score.wav via scripts/make_music.py (offline); documentary-mix.m4a via FFmpeg. No fake media is shipped.\n", encoding="utf-8")
    write_json(dest / "assets/asset-manifest.json", {"assets": []})
    (dest / "qa-report.md").write_text((ROOT / "templates/qa-report.template.md").read_text(encoding="utf-8"), encoding="utf-8")
    if mode_info["mode"] in ("higgs", "both"):
        (dest / "production/higgs-generation-queue.yaml").write_text((ROOT / "templates/higgs-generation-queue.example.yaml").read_text(encoding="utf-8"), encoding="utf-8")
    print(json.dumps({"path": str(dest), "mode": mode_info["mode"], "status": "RESEARCH_REQUIRED", "files_created": len(list(dest.rglob('*')))}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
