#!/usr/bin/env python3
"""Assemble a runnable Remotion project from a WarDoc project folder. Standard library only.

It copies templates/remotion-starter and feeds it the project's own data:
  production-brief.json, production/shot-plan.json, production/captions.json,
  production/map-data.json (+ its basemap GeoJSON), assets/asset-manifest.json, audio/*.

It does NOT install npm packages, render video, fetch media or invent data.
Rights gate: only assets whose license_status is verified_allowed or internal_original
are copied into the video project. Anything else blocks the build (or becomes a visible
placeholder with --allow-placeholders).

Usage:
  python scripts/build_remotion_project.py --project output/el-alamein
  python scripts/build_remotion_project.py --demo --project output/template-demo
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from clip_basemap import DEFAULT_SOURCE, clip_collection, clip_lines, crop_relief  # noqa: E402
from make_presenter_assets import POSES as PRESENTER_POSES, STYLE_TO_VARIANT, svg_for as classic_svg  # noqa: E402
import make_sfx  # noqa: E402
import radio_pack  # noqa: E402
import fetch_basemap  # noqa: E402

STARTER = ROOT / "templates" / "remotion-starter"
POSES = ROOT / "assets" / "vector" / "presenter-poses"
ALLOWED_LICENSE = {"verified_allowed", "internal_original"}
SHOT_TYPES = {"map_graphic", "archival_licensed", "ai_illustration", "presenter", "infographic", "transition"}
VIDEO_EXT = {".mp4", ".mov", ".webm", ".m4v"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"}
AUDIO_PRIORITY = ["audio/documentary-mix.m4a", "audio/narration.mp3", "audio/original-score.wav"]
EMPTY_FC = {"type": "FeatureCollection", "features": []}
TRANSITIONS = {"none", "cross_dissolve", "paper_slide", "paper_rip", "radar_wipe", "film_flash"}
ARROW_STYLES = {"main", "secondary", "flank", "retreat"}
ATMOSPHERES = {"desert", "winter", "city", "sea", "war_room", "mountain"}
UNIT_DISPLAYS = {"symbol", "silhouette", "card"}
CLIPPING_TEMPLATES = {"front_page", "banner", "column", "photo_report", "telegram"}
# Rough capacity of the body in characters; longer text is cut off at the torn edge.
CLIPPING_BODY_LIMIT = {"front_page": 900, "banner": 700, "column": 520, "photo_report": 420, "telegram": 320}


def shot_clippings(shot):
    many = shot.get("clippings") or []
    return list(many) if many else ([shot["clipping"]] if shot.get("clipping") else [])
GEO = ROOT / "assets" / "geo"
LAYER_TYPES = {"route", "front_line", "zone", "pin", "label", "unit", "event", "icon", "country", "arc", "range"}
BORDER_STYLES = {"glow", "solid", "marching"}
ICONS = json.loads((STARTER / "src" / "icons.json").read_text(encoding="utf-8"))
SPRITES = set(ICONS["_sprites"]["items"])


def read_json(path, default=None):
    if not path.is_file():
        if default is not None:
            return default
        raise FileNotFoundError(f"Missing required file: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def check_shots(plan):
    errors, warnings = [], []
    shots = plan.get("shots") or []
    if not shots:
        errors.append("shot-plan.json has no shots; write the shot plan after research first")
    last_end = 0.0
    for shot in shots:
        sid = shot.get("shot_id", "?")
        st, en = float(shot.get("start_sec", 0)), float(shot.get("end_sec", 0))
        if shot.get("shot_type") not in SHOT_TYPES:
            errors.append(f"{sid}: unknown shot_type {shot.get('shot_type')}")
        if en <= st:
            errors.append(f"{sid}: end_sec must be greater than start_sec")
        if st < last_end - 0.001:
            errors.append(f"{sid}: overlaps the previous shot")
        if st > last_end + 0.05:
            warnings.append(f"{sid}: {st - last_end:.2f}s black gap before this shot")
        last_end = max(last_end, en)
        if shot.get("transition_in") not in (None, *TRANSITIONS):
            errors.append(f"{sid}: unknown transition_in {shot.get('transition_in')}")
        if shot.get("icon") not in (None, *SPRITES):
            errors.append(f"{sid}: icon must be one of {sorted(SPRITES)}")
        if shot.get("atmosphere") not in (None, *ATMOSPHERES):
            errors.append(f"{sid}: atmosphere must be one of {sorted(ATMOSPHERES)}")
        if shot.get("clipping") and shot.get("clippings"):
            errors.append(f"{sid}: use either clipping or clippings, not both")
        for n, clip in enumerate(shot_clippings(shot), 1):
            template = clip.get("template", "front_page")
            if template not in CLIPPING_TEMPLATES:
                errors.append(f"{sid}: clipping {n} template must be one of {sorted(CLIPPING_TEMPLATES)}")
                continue
            if not str(clip.get("headline_ar") or "").strip():
                errors.append(f"{sid}: clipping {n} needs headline_ar")
            if clip.get("highlight_ar") and clip["highlight_ar"] not in str(clip.get("headline_ar") or ""):
                warnings.append(f"{sid}: clipping {n} highlight_ar is not part of the headline; no underline will be drawn")
            body = clip.get("body_ar") or ""
            length = len(" ".join(body) if isinstance(body, list) else str(body))
            if length > CLIPPING_BODY_LIMIT[template]:
                warnings.append(f"{sid}: clipping {n} body is {length} characters; the {template} template shows about {CLIPPING_BODY_LIMIT[template]} before the torn edge")
            image = clip.get("image") or {}
            if image and not image.get("asset_id") and not image.get("atmosphere"):
                warnings.append(f"{sid}: clipping {n} image has neither asset_id nor atmosphere; no picture will be shown")
        if shot.get("presenter_pose") not in (None, *PRESENTER_POSES):
            errors.append(f"{sid}: unknown presenter_pose {shot.get('presenter_pose')}")
        if shot.get("data_status") == "verified" and (shot.get("stat") or shot.get("quote") or shot_clippings(shot) or shot.get("date_label_ar")) and not shot.get("claim_ids"):
            errors.append(f"{sid}: verified shot shows a statistic, quote, clipping or date but carries no claim_ids")
        if shot.get("data_status") == "verified" and not shot.get("claim_ids") and shot.get("shot_type") in ("map_graphic", "archival_licensed"):
            errors.append(f"{sid}: marked verified but carries no claim_ids")
    duration = float(plan.get("duration_seconds", 0))
    if shots and last_end > duration + 0.001:
        errors.append(f"shots end at {last_end:g}s, after duration_seconds {duration:g}")
    return errors, warnings


def all_maps(map_data):
    """The top level of map-data.json is the map "default"; "maps" may add more, chosen per shot with map_id."""
    maps = {"default": {k: v for k, v in map_data.items() if k != "maps"}}
    for mid, extra in (map_data.get("maps") or {}).items():
        maps[str(mid)] = extra
    return maps


def layer_points(layer):
    kind = layer.get("type")
    if kind == "arc":
        return [p for p in (layer.get("from"), layer.get("to")) if p]
    if kind == "range":
        return [layer["center"]] if layer.get("center") else []
    if kind == "country":
        return []
    coords = layer.get("coordinates") or []
    return [coords] if coords and isinstance(coords[0], (int, float)) else coords


def check_map(map_data, plan, map_id="default"):
    errors, warnings = [], []
    tag = "" if map_id == "default" else f"map {map_id}: "
    bbox = (map_data.get("projection") or {}).get("bbox") or []
    if len(bbox) != 4 or bbox[0] >= bbox[2] or bbox[1] >= bbox[3]:
        errors.append(f"{tag}map-data.json projection.bbox must be [west, south, east, north]")
        return errors, warnings
    satellite = (map_data.get("basemap") or {}).get("satellite")
    if satellite not in (None, False, *fetch_basemap.PROVIDERS):
        errors.append(f"{tag}basemap.satellite must be one of {sorted(fetch_basemap.PROVIDERS)}")
    shot_ids = {s.get("shot_id") for s in plan.get("shots", [])}
    for layer in map_data.get("layers", []):
        lid = tag + str(layer.get("id", "?"))
        kind = layer.get("type")
        if kind not in LAYER_TYPES:
            errors.append(f"layer {lid}: type must be one of {sorted(LAYER_TYPES)}")
            continue
        if kind == "arc" and not (layer.get("from") and layer.get("to")):
            errors.append(f"layer {lid}: an arc needs from and to as [longitude, latitude]")
        if kind == "range" and not (layer.get("center") and float(layer.get("radius_km") or 0) > 0):
            errors.append(f"layer {lid}: a range needs center [longitude, latitude] and radius_km")
        if kind == "country" and not (layer.get("iso") or layer.get("name")):
            errors.append(f"layer {lid}: a country needs iso (three letters) or name")
        if kind not in ("arc", "range", "country") and not layer.get("coordinates"):
            errors.append(f"layer {lid}: coordinates are required")
        if layer.get("border") not in (None, *BORDER_STYLES):
            errors.append(f"layer {lid}: border must be one of {sorted(BORDER_STYLES)}")
        for lon, lat in layer_points(layer):
            if not (bbox[0] <= lon <= bbox[2] and bbox[1] <= lat <= bbox[3]):
                warnings.append(f"layer {lid}: point [{lon}, {lat}] is outside the map bbox")
                break
        if kind in ("unit", "event"):
            group = "units" if kind == "unit" else "events"
            if layer.get("symbol") not in ICONS[group]["items"]:
                errors.append(f"layer {lid}: symbol must be one of {sorted(ICONS[group]['items'])}")
        if kind == "icon" and not layer.get("asset_id") and layer.get("icon") not in SPRITES:
            errors.append(f"layer {lid}: icon must be one of {sorted(SPRITES)}, or give asset_id for your own picture")
        if kind == "arc" and layer.get("icon") not in (None, *SPRITES):
            errors.append(f"layer {lid}: icon must be one of {sorted(SPRITES)}")
        if layer.get("display") not in (None, *UNIT_DISPLAYS):
            errors.append(f"layer {lid}: display must be one of {sorted(UNIT_DISPLAYS)}")
        if layer.get("arrow_style") not in (None, *ARROW_STYLES):
            errors.append(f"layer {lid}: arrow_style must be one of {sorted(ARROW_STYLES)}")
        for sid in layer.get("shot_ids", []):
            if sid not in shot_ids:
                warnings.append(f"layer {lid}: unknown shot id {sid}")
        if map_data.get("data_status") == "verified" and not layer.get("claim_ids"):
            errors.append(f"layer {lid}: map is marked verified but this layer has no claim_ids")
    map_shots = [s for s in plan.get("shots", []) if s.get("shot_type") == "map_graphic" and (s.get("map_id") or "default") == map_id]
    if map_shots and not map_data.get("layers") and not satellite:
        warnings.append(f"{tag}map shots exist but the map has no layers; the map will be empty")
    return errors, warnings


_COUNTRIES = {}
DETAIL_URL = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/{name}.geojson"


def detailed(name):
    """Natural Earth 1:10m layer, downloaded once into the user's cache. Returns None when offline."""
    import urllib.request
    cache = Path.home() / ".cache" / "basetatube-wardoc" / f"{name}.geojson"
    try:
        if not cache.is_file():
            cache.parent.mkdir(parents=True, exist_ok=True)
            req = urllib.request.Request(DETAIL_URL.format(name=name), headers={"User-Agent": "basetatube-wardoc-studio"})
            with urllib.request.urlopen(req, timeout=90) as r:
                cache.write_bytes(r.read())
        return json.loads(cache.read_text(encoding="utf-8"))
    except Exception:
        return None


def country_features(fine):
    """Bundled 1:50m outlines, or the 1:10m ones (needed to sit cleanly on a satellite picture) when they can be fetched."""
    key = "10m" if fine else "50m"
    if key not in _COUNTRIES:
        features = None
        if fine:
            doc = detailed("ne_10m_admin_0_countries")
            if doc:
                features = [{"properties": {"iso": f["properties"].get("ADM0_A3"), "name": f["properties"].get("NAME"), "name_ar": f["properties"].get("NAME_AR")},
                             "geometry": f["geometry"]} for f in doc["features"] if f.get("geometry")]
        _COUNTRIES[key] = features or read_json(GEO / "ne_50m_countries.geojson")["features"]
    return _COUNTRIES[key]


def find_country(layer, fine=False):
    """Modern country outline by ISO code or English / Arabic name."""
    want_iso = str(layer.get("iso") or "").upper()
    want_name = str(layer.get("name") or "").strip().casefold()
    for feature in country_features(fine):
        props = feature["properties"]
        if want_iso and props.get("iso") == want_iso:
            return feature
        if want_name and want_name in (str(props.get("name") or "").casefold(), str(props.get("name_ar") or "").casefold()):
            return feature
    return None


def prepare_map(map_id, md, project, public, demo_basemap, warnings, errors, max_scale=1.0):
    """Resolve everything one map needs to render: land, water, relief, satellite picture, country outlines."""
    tag = "" if map_id == "default" else f"map {map_id}: "
    if not isinstance(md.get("basemap"), dict):
        md["basemap"] = {}
    base_cfg = md["basemap"]
    bbox = (md.get("projection") or {}).get("bbox") or []
    ok_box = len(bbox) == 4 and bbox[0] < bbox[2] and bbox[1] < bbox[3]
    land = base_cfg.get("land_geojson")
    if demo_basemap is not None:
        basemap = demo_basemap
    elif land == "natural_earth":
        # "detail": "10m" fetches the finer coastline once (network); otherwise the bundled 1:50m is used.
        fine = detailed("ne_10m_land") if base_cfg.get("detail") == "10m" else None
        if base_cfg.get("detail") == "10m" and not fine:
            warnings.append(f"{tag}1:10m coastline could not be downloaded; using the bundled 1:50m")
        basemap = clip_collection(fine or read_json(DEFAULT_SOURCE), bbox) if ok_box else EMPTY_FC
        base_cfg["modern_reference"] = True
    elif land:
        basemap = read_json(project / land)
        if basemap.get("type") != "FeatureCollection":
            errors.append(f"{tag}basemap land_geojson must be a GeoJSON FeatureCollection")
            basemap = EMPTY_FC
    else:
        basemap = EMPTY_FC
    water = {"rivers": EMPTY_FC, "lakes": EMPTY_FC}
    render = {"relief": None, "satellite": None}
    if ok_box:
        provider = base_cfg.get("satellite")
        if provider:
            # A real picture of the earth as the map base (needs network + FFmpeg at build time).
            try:
                wide = int(base_cfg.get("satellite_width") or 0)
                got = fetch_basemap.fetch(bbox, public / f"satellite_{map_id}.jpg", provider, width_px=wide or int(max(2600, 1920 * max_scale)),
                                          max_output=min(8192, int(wide * 1.7)) if wide else 5600)
                render["satellite"] = {"file": f"satellite_{map_id}.jpg", "bbox": got["bbox"], "credit": got["credit"]}
                base_cfg["modern_reference"] = True
            except (RuntimeError, ValueError, OSError) as err:
                warnings.append(f"{tag}satellite basemap not available ({err}); the map falls back to the drawn style")
        if base_cfg.get("rivers"):
            water["rivers"] = clip_lines(read_json(GEO / "ne_50m_rivers.geojson"), bbox)
        if base_cfg.get("lakes"):
            water["lakes"] = clip_collection(read_json(GEO / "ne_50m_lakes.geojson"), bbox)
        if base_cfg.get("relief") and not render["satellite"]:
            covered = crop_relief(bbox, public / f"relief_{map_id}.webp")
            if covered:
                render["relief"] = {"file": f"relief_{map_id}.webp", "bbox": covered}
            else:
                warnings.append(f"{tag}basemap.relief is on but FFmpeg is not available; the map is built without relief shading")
        if base_cfg.get("rivers") or base_cfg.get("lakes") or base_cfg.get("relief"):
            base_cfg["modern_reference"] = True
        for layer in md.get("layers", []):
            if layer.get("type") != "country":
                continue
            feature = find_country(layer, fine=bool(render["satellite"]) or base_cfg.get("detail") == "10m")
            if not feature:
                errors.append(f"{tag}layer {layer.get('id')}: country {layer.get('iso') or layer.get('name')!r} not found in the bundled list")
                continue
            clipped = clip_collection({"features": [feature]}, bbox, margin=1.5)
            layer["geometry"] = clipped["features"][0]["geometry"] if clipped["features"] else None
            layer.setdefault("name_ar", feature["properties"].get("name_ar"))
            base_cfg["modern_reference"] = True   # modern borders
    md["render"] = render
    return basemap, water


FILL_TYPES = {"zone", "country", "range"}
SYMBOL_TYPES = {"unit", "event", "icon"}
MAX_GAP = 3.5          # seconds a map may stand without something new
MAX_MAP_SHOT = 12.0
MAX_CARD_SHOT = 7.0


def reveal_times(layers, duration):
    """Start time of each layer inside its shot, mirroring revealWindow() in the video code."""
    slot = duration / max(1, len(layers) + 1)
    return [float(l["reveal_start_sec"]) if l.get("reveal_start_sec") is not None else slot * i * 0.8 for i, l in enumerate(layers)]


def check_quality(plan, maps, demo=False):
    """The map quality rule (system/rules-visual.md): colour on every map, something new all the time,
    and a mix of symbols. Returns a list of plain-language problems; empty means the gate passes."""
    issues = []
    shots = plan.get("shots", [])
    kinds = {s.get("shot_type") for s in shots}
    total = float(plan.get("duration_seconds") or 0)
    if total >= 30 and len(kinds) < 3:
        issues.append(f"film uses only {len(kinds)} kinds of shot; mix at least three (map, card, clipping, media, presenter)")
    if total >= 30 and shots and total / len(shots) > 6.5:
        issues.append(f"{len(shots)} shots in {total:g}s is too slow; aim for one shot every 4 to 6 seconds")
    # Wow rule: real or generated pictures, and elements made for this topic.
    if total >= 30 and not demo:
        pictures = set()
        special = 0
        for shot in shots:
            pictures.update(a for a in shot.get("asset_ids", []) if a)
            pictures.update((c.get("image") or {}).get("asset_id") for c in shot_clippings(shot))
            pictures.add(shot.get("icon_asset_id"))
            special += len(shot_clippings(shot)) + bool(shot.get("quote")) + bool(shot.get("stat"))
        for md in maps.values():
            for layer in md.get("layers", []):
                pictures.update((layer.get("asset_id"), layer.get("flag_asset_id")))
                special += bool(layer.get("asset_id"))
        pictures.discard(None)
        need = max(3, round(total / 15))
        if len(pictures) < need:
            issues.append(f"only {len(pictures)} picture(s) or clip(s) in a {total:g}s film; the wow rule asks for at least {need} (found with find_assets.py or generated)")
        if special < 3:
            issues.append(f"only {special} topic-specific element(s); add at least 3 (clipping, quote, statistic, or your own icon / picture on a map)")
    for shot in shots:
        sid = shot.get("shot_id")
        dur = float(shot.get("end_sec", 0)) - float(shot.get("start_sec", 0))
        if shot.get("shot_type") != "map_graphic":
            if dur > MAX_CARD_SHOT and shot.get("shot_type") in ("infographic", "transition"):
                issues.append(f"{sid}: a card held for {dur:.1f}s; keep cards under {MAX_CARD_SHOT:g}s")
            continue
        md = maps.get(shot.get("map_id") or "default") or {}
        layers = [l for l in md.get("layers", []) if not l.get("shot_ids") or sid in l["shot_ids"]]
        types = [l.get("type") for l in layers]
        if dur > MAX_MAP_SHOT:
            issues.append(f"{sid}: map shot of {dur:.1f}s; split it (maximum {MAX_MAP_SHOT:g}s)")
        if not FILL_TYPES & set(types):
            issues.append(f"{sid}: no colour on the map; add at least one zone, country or range fill")
        if len(set(types)) < 3:
            issues.append(f"{sid}: only {len(set(types))} kind(s) of map element; use at least three (for example a fill, an arrow or arc, and pins)")
        if not SYMBOL_TYPES & set(types):
            issues.append(f"{sid}: no unit, event or icon symbol on the map")
        if len(layers) < max(3, round(dur / 2.5)):
            issues.append(f"{sid}: {len(layers)} map elements for {dur:.1f}s; plan about one new element every 2.5 seconds")
        # moments when something new happens: layer reveals, camera keyframes, the overlay, the shot start and end
        moments = [0.0] + reveal_times(layers, dur)
        cam = shot.get("camera") or {}
        moments += [float(k.get("at_sec") or 0) for k in cam.get("path") or []]
        if shot.get("title_ar") or shot.get("stat"):
            moments.append(float(shot.get("overlay_at_sec") or 0.3))
        moments = sorted(m for m in moments if 0 <= m <= dur) + [dur]
        gap = max(b - a for a, b in zip(moments, moments[1:]))
        if gap > MAX_GAP:
            issues.append(f"{sid}: {gap:.1f}s with nothing new on the map; add a reveal, a camera keyframe or an overlay every {MAX_GAP:g}s at most")
        if not cam.get("path") and float(cam.get("scale_end") or 1.08) <= float(cam.get("scale_start") or 1):
            issues.append(f"{sid}: the camera does not move; give it a path or a push")
    return issues


def collect_assets(project, plan, dest_public, allow_placeholders, extra_ids=()):
    """Copy every picture / clip the film uses into the video project. The manifest records where a file came
    from; its licence fields are information for the owner and never block the build."""
    errors, warnings, out = [], [], {}
    manifest = read_json(project / "assets" / "asset-manifest.json", {"assets": []})
    by_id = {a.get("asset_id"): a for a in manifest.get("assets", [])}
    used = []
    for shot in plan.get("shots", []):
        clip_ids = [(c.get("image") or {}).get("asset_id") for c in shot_clippings(shot)]
        for aid in list(shot.get("asset_ids", [])) + [c for c in clip_ids if c] + [shot.get("icon_asset_id")]:
            if aid and aid not in used:
                used.append(aid)
    used += [a for a in extra_ids if a and a not in used]
    for aid in used:
        asset = by_id.get(aid)
        problem = None
        if not asset:
            problem = f"asset {aid}: not in assets/asset-manifest.json (add it with scripts/find_assets.py add)"
        elif not asset.get("file") or not (project / asset["file"]).is_file():
            problem = f"asset {aid}: file not found ({asset.get('file')})"
        elif Path(asset["file"]).suffix.lower() not in VIDEO_EXT | IMAGE_EXT:
            problem = f"asset {aid}: unsupported file type"
        if problem:
            (warnings if allow_placeholders else errors).append(problem + (" -> placeholder" if allow_placeholders else ""))
            continue
        src = project / asset["file"]
        target = dest_public / "assets" / (aid + src.suffix.lower())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
        out[aid] = {"file": f"assets/{target.name}", "kind": "video" if src.suffix.lower() in VIDEO_EXT else "image",
                    "attribution": asset.get("attribution_text")}
    return out, errors, warnings


def render_commands(dest, project, audio, status_notes):
    lines = [
        "# Render commands", "",
        f"Remotion project: `{dest}`", "",
        "```bash", f"cd \"{dest}\"", "npm install            # once; needs network", "npm run studio         # optional live preview",
        "npm run render         # -> out/documentary.mp4", "npm run still          # -> out/preview.png (single frame check)", "```", "",
        "Requirements: Node 18+ and network access for npm and for the headless browser Remotion downloads on first render.",
        "Fonts, textures and sound effects are inside the project, so the render itself needs no network.",
        "Check Remotion's license terms for your team size before commercial use.", "",
        f"Audio track in the render: `{audio}`" if audio else "Audio track in the render: none yet (silent video). Run make_narration.py / make_music.py / mix_audio.py, then rebuild.", "",
        "After editing anything under `production/`, `assets/` or `audio/`, re-run:", "",
        "```bash", f"python scripts/build_remotion_project.py --project \"{project}\" --force", "```", "",
    ]
    if status_notes:
        lines += ["## Open issues at build time", ""] + [f"- {n}" for n in status_notes] + [""]
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser(description="Build a runnable Remotion project from WarDoc project data")
    p.add_argument("--project", required=True, help="Project folder made by new_project.py (or any empty folder with --demo)")
    p.add_argument("--demo", action="store_true", help="Use the bundled fictional demo data to test the toolchain")
    p.add_argument("--force", action="store_true", help="Replace an existing remotion/ folder (node_modules is kept)")
    p.add_argument("--allow-placeholders", action="store_true", help="Uncleared/missing assets become visible placeholders instead of blocking")
    p.add_argument("--strict", action="store_true", help="(default behaviour now; kept so old commands still work)")
    p.add_argument("--draft", action="store_true", help="Preview only: report quality problems without stopping. A draft is never a deliverable.")
    args = p.parse_args()

    project = Path(args.project).resolve()
    dest = project / "remotion"
    if not STARTER.is_dir():
        p.error("templates/remotion-starter is missing from the skill")
    if not args.demo and not project.is_dir():
        p.error("Project folder does not exist; run new_project.py first")
    if dest.exists() and any(dest.iterdir()) and not args.force:
        p.error("remotion/ already exists; pass --force to rebuild it")

    errors, warnings = [], []
    demo_basemap = None
    try:
        if args.demo:
            sample = STARTER / "sample-data"
            brief, plan = read_json(sample / "brief.json"), read_json(sample / "shot-plan.json")
            captions, map_data = read_json(sample / "captions.json"), read_json(sample / "map-data.json")
            demo_basemap = read_json(sample / "basemap.json")
        else:
            brief = read_json(project / "production-brief.json")
            plan = read_json(project / "production" / "shot-plan.json")
            captions = read_json(project / "production" / "captions.json", {"language": "ar-EG", "timing_status": "estimated", "segments": []})
            map_data = read_json(project / "production" / "map-data.json",
                                 {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [0, 0, 10, 10]}, "layers": []})
    except (FileNotFoundError, json.JSONDecodeError) as err:
        print(json.dumps({"status": "PLAN_ONLY", "errors": [str(err)]}, ensure_ascii=False, indent=2))
        sys.exit(2)

    e, w = check_shots(plan); errors += e; warnings += w
    maps = all_maps(map_data)
    for mid, md in maps.items():
        e, w = check_map(md, plan, mid); errors += e; warnings += w
    for shot in plan.get("shots", []):
        if shot.get("shot_type") == "map_graphic" and (shot.get("map_id") or "default") not in maps:
            errors.append(f"{shot.get('shot_id')}: map_id {shot.get('map_id')!r} is not defined in map-data.json")
    if errors:
        print(json.dumps({"status": "PLAN_ONLY", "errors": errors, "warnings": warnings}, ensure_ascii=False, indent=2))
        sys.exit(2)

    # Copy the starter (keep an installed node_modules across rebuilds).
    dest.mkdir(parents=True, exist_ok=True)
    for child in list(dest.iterdir()):
        if child.name in ("node_modules", "out", "package-lock.json"):
            continue
        try:
            shutil.rmtree(child) if child.is_dir() else child.unlink()
        except OSError:
            pass   # a file still held open (e.g. a render log on a network drive) is simply left in place
    for child in STARTER.iterdir():
        if child.name in ("sample-data", "node_modules", "out"):
            continue
        target = dest / child.name
        shutil.copytree(child, target) if child.is_dir() else shutil.copy2(child, target)
    public = dest / "public"
    public.mkdir(exist_ok=True)

    assets = {}
    if not args.demo:
        layer_ids = [l.get(k) for md in maps.values() for l in md.get("layers", []) for k in ("asset_id", "flag_asset_id")]
        assets, e, w = collect_assets(project, plan, public, args.allow_placeholders, layer_ids)
        warnings += w
        if e:
            # Leave no half-built project behind (an installed node_modules is kept).
            for child in list(dest.iterdir()):
                if child.name in ("node_modules", "out", "package-lock.json"):
                    continue
                try:
                    shutil.rmtree(child) if child.is_dir() else child.unlink()
                except OSError:
                    pass
            if not any(dest.iterdir()):
                dest.rmdir()
            print(json.dumps({"status": "PLAN_ONLY", "errors": e, "warnings": warnings,
                              "hint": "Register the file with scripts/find_assets.py add, or pass --allow-placeholders"}, ensure_ascii=False, indent=2))
            sys.exit(2)

    # Map quality rule: colour, constant change, a mix of symbols. Reported always; blocking with --strict.
    quality = check_quality(plan, maps, demo=args.demo)
    if quality and not args.draft and not args.demo:
        print(json.dumps({"status": "PLAN_ONLY", "quality_gate": "FAIL", "errors": quality,
                          "hint": "Enrich the shot plan and map data (system/rules-visual.md: map quality rule and wow rule), then build again. --draft builds a preview only."}, ensure_ascii=False, indent=2))
        sys.exit(2)

    # Resolve every map: land, optional modern rivers / lakes / relief, satellite picture, country outlines.
    basemaps, waters = {}, {}
    try:
        for mid, md in maps.items():
            # How far the camera zooms on this map decides how detailed its satellite picture must be.
            scales = [1.0]
            for shot in plan.get("shots", []):
                if shot.get("shot_type") == "map_graphic" and (shot.get("map_id") or "default") == mid:
                    cam = shot.get("camera") or {}
                    scales += [float(k.get("scale") or 1) for k in cam.get("path") or []] + [float(cam.get("scale_end") or 1), float(cam.get("scale_start") or 1)]
            basemaps[mid], waters[mid] = prepare_map(mid, md, project, public, demo_basemap if mid == "default" else None, warnings, errors, max(scales))
    except (FileNotFoundError, json.JSONDecodeError) as err:
        errors.append(str(err))
    if errors:
        print(json.dumps({"status": "PLAN_ONLY", "errors": errors, "warnings": warnings}, ensure_ascii=False, indent=2))
        sys.exit(2)

    audio = None
    tracks = {"voice": None, "music": None}
    if not args.demo:
        (public / "audio").mkdir(exist_ok=True)
        for rel in AUDIO_PRIORITY:
            if (project / rel).is_file():
                shutil.copy2(project / rel, public / "audio" / Path(rel).name)
                audio = f"audio/{Path(rel).name}"
                break
        # Voice and music as separate tracks, used when a talking clip carries its own voice (see "talk" below).
        voice = next((project / "audio" / n for n in ("narration.mp3", "narration.wav") if (project / "audio" / n).is_file()), None)
        music = next((project / "audio" / n for n in ("music.mp3", "music.wav", "original-score.wav") if (project / "audio" / n).is_file()), None)
        for key, src in (("voice", voice), ("music", music)):
            if src:
                shutil.copy2(src, public / "audio" / src.name)
                tracks[key] = f"audio/{src.name}"

    style = brief.get("visual_style") or "cinematic-war-map"
    variant = STYLE_TO_VARIANT.get(style, "cinematic")
    wants_presenter = bool((brief.get("presenter") or {}).get("enabled")) or any(s.get("shot_type") == "presenter" for s in plan["shots"])
    ext = "svg"
    presenter_mode = "poses"
    character = None
    if wants_presenter:
        custom = project / "assets" / "presenter"
        character = (brief.get("presenter") or {}).get("character", "radio")
        has_custom = any((custom / f"neutral.{e}").is_file() for e in ("svg", "png", "webp"))
        (public / "presenter").mkdir(exist_ok=True)
        if character != "classic" and not has_custom:
            # Default host: the layered radio mascot (body + eyes + mouth overlays), in the look of the visual style.
            # The 42 layer files ship as one plain pack file to stay under upload file-count limits.
            radio_pack.extract(public / "presenter", "wood" if variant == "cinematic" else variant, flat=True)
            ext, presenter_mode = "webp", "layered"
        else:
            if has_custom:
                ext = next(e for e in ("svg", "png", "webp") if (custom / f"neutral.{e}").is_file())
                missing = []
                for pose in PRESENTER_POSES:
                    src = custom / f"{pose}.{ext}"
                    if not src.is_file():
                        missing.append(pose)
                        src = custom / f"neutral.{ext}"
                    shutil.copy2(src, public / "presenter" / f"{pose}.{ext}")
            else:
                # The classic SVG man is drawn by code, in the look of the visual style.
                missing = []
                for pose in PRESENTER_POSES:
                    (public / "presenter" / f"{pose}.svg").write_text(classic_svg(pose, variant), encoding="utf-8")
            if missing:
                warnings.append(f"presenter poses missing, neutral used instead: {missing}")

    # Generated talking clips for the host (HIGGS route): assets/presenter/talk/<shot_id>.webm|mov|mp4.
    # .webm / .mov with alpha are shown without a box (see scripts/key_video.py); .mp4 is shown in a rounded frame.
    talk = {}
    talk_dir = project / "assets" / "presenter" / "talk"
    if talk_dir.is_dir():
        shot_ids = {s.get("shot_id") for s in plan["shots"]}
        for clip in sorted(talk_dir.iterdir()):
            if clip.suffix.lower() in (".webm", ".mov", ".mp4") and clip.stem in shot_ids:
                (public / "presenter").mkdir(exist_ok=True)
                shutil.copy2(clip, public / "presenter" / f"talk_{clip.name}")
                talk[clip.stem] = {"file": f"presenter/talk_{clip.name}", "transparent": clip.suffix.lower() in (".webm", ".mov"),
                                   "audio": (brief.get("presenter") or {}).get("talk_audio", True) is not False}
        wants_presenter = wants_presenter or bool(talk)

    # Sound effects are synthesised here in code (no samples). Turn off with "audio": {"sfx": false} in the brief.
    wants_sfx = (brief.get("audio") or {}).get("sfx", True) is not False
    if wants_sfx:
        make_sfx.build(public / "sfx")
        # Your own or generated effects replace the built-in ones by name: audio/sfx/<whoosh|hit|pop|swish|pulse|ping|typewriter|riser>.wav
        custom_sfx = project / "audio" / "sfx"
        if custom_sfx.is_dir():
            for item in custom_sfx.glob("*.wav"):
                if item.stem in make_sfx.NAMES:
                    shutil.copy2(item, public / "sfx" / item.name)

    data = dest / "src" / "data"
    write_json(data / "brief.json", brief)
    write_json(data / "shot-plan.json", plan)
    write_json(data / "captions.json", captions)
    write_json(data / "map-data.json", {"maps": maps})
    write_json(data / "basemap.json", basemaps)
    write_json(data / "water.json", waters)
    write_json(data / "build.json", {"demo": bool(args.demo), "audio": audio, "presenter": wants_presenter, "presenter_ext": ext, "presenter_mode": presenter_mode,
                                    "presenter_variant": variant, "sfx": wants_sfx, "talk": talk, "tracks": tracks, "assets": assets})

    unverified = [s["shot_id"] for s in plan["shots"] if s.get("data_status") != "verified"]
    notes = list(warnings) + [f"map quality rule: {q}" for q in quality]
    if unverified and not args.demo:
        notes.append(f"shots not yet verified (shown with an on-screen notice): {unverified}")
    if captions.get("timing_status") == "estimated" and not args.demo:
        notes.append("caption timing is estimated; regenerate from real narration before release")
    commands = render_commands(dest, project, audio, notes)
    target = (project / "production" / "render_commands.md") if (project / "production").is_dir() else (dest / "render_commands.md")
    target.write_text(commands, encoding="utf-8")

    print(json.dumps({
        "status": "READY_FOR_RENDER", "remotion_project": str(dest), "render_commands": str(target),
        "shots": len(plan["shots"]), "audio": audio, "presenter": wants_presenter, "presenter_variant": variant if wants_presenter else None, "sfx": wants_sfx,
        "styles": sorted({s.get("style_id") for s in plan["shots"]}),
        "maps": {mid: {"satellite": bool(md["render"]["satellite"]), "relief": bool(md["render"]["relief"]), "rivers": len(waters[mid]["rivers"]["features"]),
                       "lakes": len(waters[mid]["lakes"]["features"]), "layers": len(md.get("layers", []))} for mid, md in maps.items()}, "assets_included": sorted(assets),
        "quality_gate": "FAIL" if quality else "PASS", "quality_issues": quality, "draft": bool(args.draft),
        "after_render": "python scripts/wow_check.py measure --project <project>  then look at qa/frames, fill qa/scores.json, and run wow_check.py verdict",
        "unverified_shots": unverified, "warnings": warnings,
        "next": f"cd \"{dest}\" && npm install && npm run render",
        "note": "READY_FOR_RENDER means files exist. No MP4 exists until the render command really succeeds.",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
