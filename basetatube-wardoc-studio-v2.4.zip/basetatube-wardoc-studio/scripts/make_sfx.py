#!/usr/bin/env python3
"""Original sound effects synthesised in code (WAV). Python standard library only.

No samples, no recordings, no third-party audio. Deterministic.
  whoosh      transition sweep
  hit         low impact for date / title cards
  typewriter  key click for archival labels
  ping        radar ping for tactical markers
  pop         an element appearing on the map
  swish       an arrow or arc being drawn
  pulse       an area or country lighting up
  riser       two seconds of rising tension
"""
import argparse
import json
import math
import random
import struct
import wave
from pathlib import Path

SR = 32000
NAMES = ["whoosh", "hit", "typewriter", "ping", "pop", "swish", "pulse", "riser"]


def _noise(rng):
    return rng.uniform(-1, 1)


def whoosh(rng):
    n = int(SR * 0.55)
    out, lp, bp = [], 0.0, 0.0
    for i in range(n):
        t = i / n
        env = math.sin(math.pi * t) ** 2
        # band-passed noise whose centre sweeps upward, then down
        cutoff = 0.02 + 0.32 * math.sin(math.pi * min(1.0, t * 1.15)) ** 2
        lp += cutoff * (_noise(rng) - lp)
        bp += 0.004 * (lp - bp)
        out.append((lp - bp) * env * 1.6)
    return out


def hit(rng):
    n = int(SR * 0.7)
    out = []
    for i in range(n):
        t = i / SR
        body = math.sin(2 * math.pi * (46 + 60 * math.exp(-t * 22)) * t) * math.exp(-t * 6.5)
        click = _noise(rng) * math.exp(-t * 180) * 0.35
        rumble = math.sin(2 * math.pi * 31 * t) * math.exp(-t * 3.2) * 0.35
        out.append(body * 0.9 + click + rumble)
    return out


def typewriter(rng):
    n = int(SR * 0.32)
    out = [0.0] * n
    for start, level in ((0.0, 1.0), (0.11, 0.8), (0.2, 0.9)):
        s = int(start * SR)
        for j in range(int(SR * 0.06)):
            if s + j >= n:
                break
            t = j / SR
            tick = _noise(rng) * math.exp(-t * 260)
            ring = math.sin(2 * math.pi * 2300 * t) * math.exp(-t * 120) * 0.4
            thud = math.sin(2 * math.pi * 170 * t) * math.exp(-t * 70) * 0.5
            out[s + j] += (tick + ring + thud) * level
    return out


def ping(rng):
    n = int(SR * 0.9)
    out = []
    for i in range(n):
        t = i / SR
        tone = math.sin(2 * math.pi * 1320 * t) + 0.35 * math.sin(2 * math.pi * 1980 * t)
        env = math.exp(-t * 5.5) * min(1.0, t * 400)
        echo = 0.0
        if t > 0.28:
            te = t - 0.28
            echo = math.sin(2 * math.pi * 1320 * te) * math.exp(-te * 7) * 0.3
        out.append(tone * env * 0.6 + echo)
    return out


def pop(rng):
    """Short soft pop for an element appearing on the map."""
    n = int(SR * 0.16)
    out = []
    for i in range(n):
        t = i / SR
        body = math.sin(2 * math.pi * (620 - 380 * min(1.0, t / 0.08)) * t) * math.exp(-t * 34)
        out.append(body + _noise(rng) * math.exp(-t * 300) * 0.25)
    return out


def swish(rng):
    """Quick airy sweep for an arrow or arc being drawn."""
    n = int(SR * 0.34)
    out, lp = [], 0.0
    for i in range(n):
        t = i / n
        env = math.sin(math.pi * t) ** 1.5
        lp += (0.08 + 0.5 * t) * (_noise(rng) - lp)
        out.append(lp * env * 1.4 + math.sin(2 * math.pi * (300 + 1500 * t) * (i / SR)) * env * 0.12)
    return out


def pulse(rng):
    """Low soft boom for an area lighting up."""
    n = int(SR * 0.6)
    out = []
    for i in range(n):
        t = i / SR
        out.append(math.sin(2 * math.pi * (58 + 30 * math.exp(-t * 14)) * t) * math.exp(-t * 7) * min(1.0, t * 300) + _noise(rng) * math.exp(-t * 90) * 0.08)
    return out


def riser(rng):
    """Two-second rising tension before a reveal."""
    n = int(SR * 2.0)
    out, lp = [], 0.0
    for i in range(n):
        t = i / n
        lp += (0.02 + 0.3 * t * t) * (_noise(rng) - lp)
        tone = math.sin(2 * math.pi * (90 + 420 * t * t) * (i / SR))
        out.append((lp * 0.9 + tone * 0.35) * t * t)
    return out


MAKERS = {"whoosh": whoosh, "hit": hit, "typewriter": typewriter, "ping": ping, "pop": pop, "swish": swish, "pulse": pulse, "riser": riser}


def render(name, seed=27):
    if name not in MAKERS:
        raise ValueError(f"Unknown effect: {name}")
    samples = MAKERS[name](random.Random(seed + NAMES.index(name)))
    peak = max((abs(x) for x in samples), default=0) or 1.0
    fade = int(SR * 0.01)
    for i in range(min(fade, len(samples))):
        samples[-1 - i] *= i / fade
    return [x * 0.8 / peak for x in samples]


def save(path, samples):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(b"".join(struct.pack("<h", round(max(-1.0, min(1.0, x)) * 32767)) for x in samples))


def build(out_dir, names=None, seed=27):
    out_dir = Path(out_dir)
    made = []
    for name in names or NAMES:
        save(out_dir / f"{name}.wav", render(name, seed))
        made.append(name)
    return {"status": "RENDERED", "path": str(out_dir.resolve()), "effects": made, "original_procedural_audio": True}


def main():
    p = argparse.ArgumentParser(description="Original code-synthesised sound effects (no samples)")
    p.add_argument("--out", required=True, help="Destination folder for the WAV files")
    p.add_argument("--only", nargs="+", choices=NAMES)
    p.add_argument("--seed", type=int, default=27)
    a = p.parse_args()
    print(json.dumps(build(a.out, a.only, a.seed), ensure_ascii=False))


if __name__ == "__main__":
    main()
