#!/usr/bin/env python3
"""Build the original vector explainer host: 12 poses x 3 style variants (+ optional demo GIF).

No AI service or internet access required. GIF requires locally installed CairoSVG and Pillow.
The GIF is a pose-loop demonstration, NOT true speech or audio lip sync.

Writes to --out (default: output/presenter-poses). The poses are not shipped as files:
the builder draws them with svg_for() when a project asks for the classic host.
"""
import argparse
import json
from io import BytesIO
from pathlib import Path

BUNDLED = Path(__file__).resolve().parents[1] / 'assets' / 'vector' / 'presenter-poses'

POSES = ['neutral', 'speaking_closed', 'speaking_mid', 'speaking_open', 'pointing_left', 'pointing_right', 'pointing_up',
         'explaining', 'thinking', 'holding_paper', 'surprised', 'blinking']
# One look per visual style. "cinematic" is the default and lives at the folder root.
VARIANTS = {
    'cinematic': {'j1': '#4D352B', 'j2': '#765447', 'lapel': '#7A5749', 'shirt': '#697153', 'arm': '#5A4439', 'line': '#3B2D2A',
                  'skin': '#BE8766', 'skin2': '#B27C60', 'neck': '#B37A5D', 'hair': '#59534A', 'brow': '#514039', 'eye': '#2E2826',
                  'nose': '#8E5948', 'tash': '#676159', 'mouth': '#54352D', 'lip': '#6D3E35', 'paper': '#EFE4CE'},
    'tactical': {'j1': '#16222C', 'j2': '#243746', 'lapel': '#2B4254', 'shirt': '#0E7C86', 'arm': '#1D2D3A', 'line': '#0B141B',
                 'skin': '#BE8766', 'skin2': '#B27C60', 'neck': '#B37A5D', 'hair': '#3B3F45', 'brow': '#33373C', 'eye': '#1F2225',
                 'nose': '#8E5948', 'tash': '#4F545A', 'mouth': '#54352D', 'lip': '#6D3E35', 'paper': '#D8F6FA'},
    'archival': {'j1': '#4A4136', 'j2': '#6B5F50', 'lapel': '#74685A', 'shirt': '#8C8372', 'arm': '#51483D', 'line': '#2E2822',
                 'skin': '#B9A48A', 'skin2': '#A99479', 'neck': '#AD987E', 'hair': '#4E463C', 'brow': '#463E35', 'eye': '#2B2621',
                 'nose': '#8A775F', 'tash': '#62594D', 'mouth': '#4A3F35', 'lip': '#5E5145', 'paper': '#EFE4CE'},
}
STYLE_TO_VARIANT = {'cinematic-war-map': 'cinematic', 'modern-tactical': 'tactical', 'archival-atlas': 'archival', 'satellite': 'tactical'}
GIF_LOOP = ['neutral', 'speaking_mid', 'speaking_open', 'speaking_mid', 'speaking_closed', 'blinking', 'explaining', 'pointing_up', 'neutral']
GIF_MS = [550, 110, 130, 110, 140, 150, 380, 420, 420]


def svg_for(pose, variant='cinematic'):
    if pose not in POSES:
        raise ValueError(f'Unknown pose: {pose}')
    if variant not in VARIANTS:
        raise ValueError(f'Unknown variant: {variant}')
    c = VARIANTS[variant]
    arm = f'fill="none" stroke="{c["arm"]}" stroke-linecap="round" stroke-linejoin="round"'
    smile = f'<path d="M151 166 Q163 175 175 166" fill="none" stroke="{c["lip"]}" stroke-width="4" stroke-linecap="round"/>'
    mouth = smile
    if pose == 'speaking_open':
        mouth = f'<ellipse cx="162" cy="166" rx="12" ry="14" fill="{c["mouth"]}"/>'
    elif pose == 'speaking_mid':
        mouth = f'<ellipse cx="162" cy="167" rx="9" ry="6.5" fill="{c["mouth"]}"/>'
    elif pose == 'surprised':
        mouth = f'<ellipse cx="162" cy="166" rx="10" ry="13" fill="{c["mouth"]}"/>'
    elif pose == 'thinking':
        mouth = f'<path d="M153 168 H173" fill="none" stroke="{c["lip"]}" stroke-width="4" stroke-linecap="round"/>'
    eyes = (f'<path d="M125 113 h17 M182 113 h17" stroke="{c["eye"]}" stroke-width="4" stroke-linecap="round" />' if pose == 'blinking' else
            f'<ellipse cx="135" cy="115" rx="5" ry="6" fill="{c["eye"]}"/><ellipse cx="189" cy="115" rx="5" ry="6" fill="{c["eye"]}"/>')
    brows = 'M127 113 Q136 108 144 113 M181 112 Q189 108 200 112'
    if pose in ('surprised', 'thinking'):
        brows = 'M127 107 Q136 101 144 106 M181 105 Q189 101 200 106'
    arm_left = f'<path d="M105 238 Q70 250 75 317 L88 372" {arm} stroke-width="28"/>'
    arm_right = f'<path d="M213 238 Q250 252 245 317 L237 371" {arm} stroke-width="28"/>'
    hand_l = f'<circle cx="88" cy="370" r="16" fill="{c["skin"]}"/>'
    hand_r = f'<circle cx="237" cy="370" r="16" fill="{c["skin"]}"/>'
    front = ''  # drawn above the torso
    if pose == 'pointing_left':
        arm_left = f'<path d="M105 239 Q83 252 63 235 L26 218" {arm} stroke-width="27"/>'
        hand_l = f'<path d="M16 212 L31 200 L39 203 L27 217 L12 227 Z" fill="{c["skin"]}"/>'
    if pose == 'pointing_right':
        arm_right = f'<path d="M211 239 Q235 250 260 231 L297 211" {arm} stroke-width="27"/>'
        hand_r = f'<path d="M304 208 L291 192 L285 196 L293 209 L306 219 Z" fill="{c["skin"]}"/>'
    if pose == 'pointing_up':
        arm_right = f'<path d="M211 240 Q246 246 258 214 L270 150" {arm} stroke-width="26"/>'
        hand_r = f'<circle cx="271" cy="140" r="14" fill="{c["skin"]}"/><path d="M266 132 L270 104 L278 105 L277 133 Z" fill="{c["skin"]}"/>'
    if pose == 'explaining':
        arm_left = f'<path d="M106 244 Q78 231 63 263 L50 280" {arm} stroke-width="26"/>'
        arm_right = f'<path d="M210 244 Q236 232 254 261 L273 280" {arm} stroke-width="26"/>'
        hand_l = f'<ellipse cx="50" cy="284" rx="19" ry="15" fill="{c["skin"]}"/>'
        hand_r = f'<ellipse cx="273" cy="284" rx="19" ry="15" fill="{c["skin"]}"/>'
    if pose == 'thinking':
        arm_right = ''
        hand_r = ''
        front = (f'<path d="M213 244 L244 306 L200 204" {arm} stroke-width="25"/>'
                 f'<circle cx="198" cy="196" r="15" fill="{c["skin"]}"/>')
    if pose == 'holding_paper':
        arm_left = arm_right = hand_l = hand_r = ''
        front = (f'<path d="M106 242 Q78 292 126 322" {arm} stroke-width="25"/><path d="M212 242 Q242 292 194 322" {arm} stroke-width="25"/>'
                 f'<rect x="121" y="258" width="78" height="96" rx="3" fill="{c["paper"]}" stroke="{c["line"]}" stroke-width="2" transform="rotate(-3 160 306)"/>'
                 f'<path d="M134 280 H186 M134 294 H186 M134 308 H176 M134 322 H182" stroke="{c["line"]}" stroke-width="3" opacity="0.45" stroke-linecap="round" transform="rotate(-3 160 306)"/>'
                 f'<circle cx="124" cy="324" r="14" fill="{c["skin"]}"/><circle cx="196" cy="324" r="14" fill="{c["skin"]}"/>')
    label = f'Original vector host — {pose} pose ({variant})'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="320" height="400" viewBox="0 0 320 400" role="img" aria-label="{label}">
    <defs><linearGradient id="jacket" x1="0" x2="1"><stop offset="0" stop-color="{c["j1"]}"/><stop offset="1" stop-color="{c["j2"]}"/></linearGradient></defs>
    <g>{arm_left}{arm_right}<path d="M106 220 Q160 204 214 220 L240 397 H78 Z" fill="url(#jacket)" stroke="{c["line"]}" stroke-width="2"/>
    <path d="M145 219 L172 219 L194 397 L124 397 Z" fill="{c["shirt"]}"/>
    <path d="M145 218 L159 246 L133 263 L106 221" fill="{c["lapel"]}"/><path d="M173 220 L159 247 L187 265 L213 220" fill="{c["lapel"]}"/>
    <rect x="146" y="203" width="30" height="38" rx="10" fill="{c["neck"]}"/>
    <ellipse cx="161" cy="125" rx="66" ry="83" fill="{c["skin"]}"/>
    <ellipse cx="98" cy="132" rx="11" ry="16" fill="{c["skin2"]}"/><ellipse cx="224" cy="132" rx="11" ry="16" fill="{c["skin2"]}"/>
    <path d="M104 94 Q100 69 123 55 Q160 34 203 61 L219 96 Q202 63 169 67 Q130 66 104 94" fill="{c["hair"]}"/>
    <path d="{brows}" stroke="{c["brow"]}" stroke-width="5" fill="none" stroke-linecap="round"/>
    {eyes}
    <path d="M162 113 Q171 141 166 147" stroke="{c["nose"]}" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M133 148 Q160 143 189 148" stroke="{c["tash"]}" stroke-width="8" stroke-linecap="round" fill="none"/>
    {mouth}{hand_l}{hand_r}{front}</g></svg>'''


def write_variant(out_dir, variant):
    out_dir.mkdir(parents=True, exist_ok=True)
    for pose in POSES:
        (out_dir / f'{pose}.svg').write_text(svg_for(pose, variant), encoding='utf-8')


def build(out_dir, variant='all', gif=True, flat=False):
    """variant='all' writes cinematic at the root plus tactical/ and archival/ subfolders.
    A single variant (or flat=True) writes just that variant's 12 files into out_dir."""
    out_dir = Path(out_dir)
    if variant == 'all':
        write_variant(out_dir, 'cinematic')
        for name in ('tactical', 'archival'):
            write_variant(out_dir / name, name)
        variants = list(VARIANTS)
        main = 'cinematic'
    else:
        write_variant(out_dir, variant)
        variants, main = [variant], variant
    result = {'status': 'RENDERED', 'path': str(out_dir.resolve()), 'svg_poses': len(POSES), 'variants': variants, 'gif': None}
    if not gif:
        return result
    try:
        import cairosvg
        from PIL import Image
    except ImportError:
        result['gif_note'] = 'Optional GIF needs CairoSVG and Pillow (pip install cairosvg pillow).'
        return result
    frames = [Image.open(BytesIO(cairosvg.svg2png(bytestring=svg_for(p, main).encode(), output_width=320, output_height=400))).convert('RGBA') for p in GIF_LOOP]
    target = out_dir / 'original-host-pose-demo.gif'
    # Pillow keeps the alpha channel as GIF transparency when saving RGBA frames.
    frames[0].save(target, save_all=True, append_images=frames[1:], duration=GIF_MS, loop=0, disposal=2)
    result['gif'] = str(target.resolve())
    return result


def main():
    p = argparse.ArgumentParser(description='Original SVG presenter poses in three style variants (+ optional demo GIF)')
    p.add_argument('--out', default='output/presenter-poses', help='Destination folder (default: output/presenter-poses)')
    p.add_argument('--variant', choices=['all'] + list(VARIANTS), default='all', help='all = cinematic at the root + tactical/ and archival/ subfolders')
    p.add_argument('--no-gif', action='store_true')
    a = p.parse_args()
    print(json.dumps(build(a.out, a.variant, gif=not a.no_gif), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
