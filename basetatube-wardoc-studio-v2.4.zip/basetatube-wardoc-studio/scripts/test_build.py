#!/usr/bin/env python3
"""Scaffold + Remotion project builder tests. Offline; never runs npm or renders."""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


def run(script, *args):
    # These tests exercise the mechanics with tiny plans, so they build drafts; the quality gate has its own tests with --strict.
    if script == "build_remotion_project.py" and "--strict" not in args and "--demo" not in args:
        args = (*args, "--draft")
    args = tuple(a for a in args if a != "--strict")
    done = subprocess.run([sys.executable, str(SCRIPTS / script), *args], capture_output=True, text=True)
    try:
        return done, json.loads(done.stdout)
    except json.JSONDecodeError:
        return done, None


def shot(sid, st, en, kind="infographic", **extra):
    base = {"shot_id": sid, "start_sec": st, "end_sec": en, "shot_type": kind, "style_id": "cinematic-war-map",
            "caption_style": "cinematic-minimal", "claim_ids": [], "asset_ids": [], "script_ar": "", "data_status": "research_required"}
    base.update(extra)
    return base


class BuildTests(unittest.TestCase):
    def new_project(self, tmp, topic="معركة تجريبية", mode="auto"):
        done, out = run("new_project.py", "--topic", topic, "--slug", "demo-proj", "--out", tmp, "--mode", mode)
        self.assertEqual(done.returncode, 0, done.stderr)
        return Path(out["path"])

    def write_plan(self, project, shots, duration=6):
        (project / "production/shot-plan.json").write_text(json.dumps({"duration_seconds": duration, "fps": 30, "shots": shots}, ensure_ascii=False), encoding="utf-8")

    def test_scaffold_layout_matches_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            for rel in ["production-brief.json", "route-decision.json", "qa-report.md", "research/research-dossier.md", "research/source-log.csv",
                        "research/claims.json", "research/timeline.json", "research/research-open-questions.md", "production/script.ar.md",
                        "production/narration.txt", "production/shot-plan.json", "production/map-data.json", "production/captions.json",
                        "production/music-cues.json", "production/render_commands.md", "assets/asset-manifest.json", "audio/README.txt"]:
                self.assertTrue((project / rel).is_file(), rel)
            self.assertFalse((project / "production/higgs-generation-queue.yaml").exists())
            self.assertEqual(json.loads((project / "production-brief.json").read_text(encoding="utf-8"))["mode"], "free")

    def test_higgs_scaffold_has_queue(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp, "معركة تجريبية باستخدام هيجزفيلد")
            self.assertTrue((project / "production/higgs-generation-queue.yaml").is_file())

    def test_demo_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            done, out = run("build_remotion_project.py", "--demo", "--project", tmp)
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(out["status"], "READY_FOR_RENDER")
            remotion = Path(tmp) / "remotion"
            for rel in ["package.json", "src/index.ts", "src/Root.tsx", "src/Documentary.tsx", "src/components/MapShot.tsx", "src/components/Captions.tsx",
                        "src/data/shot-plan.json", "src/data/map-data.json", "src/data/build.json", "public/presenter/body_neutral.webp", "public/presenter/eyes_blink.webp", "public/presenter/mouth_open.webp",
                        "public/sfx/whoosh.wav", "public/sfx/ping.wav", "public/fonts/fonts.json", "public/fonts/OFL-Cairo.txt", "public/textures/parchment.webp",
                        "public/textures/desk.webp", "public/atmosphere/desert.webp", "public/atmosphere/desert-band.webp", "public/silhouettes/tank.png", "public/icons/military.webp", "public/icons/civil.webp",
                        "src/data/water.json", "src/components/Atmosphere.tsx", "src/icons.json", "src/geo.ts", "src/components/Transition.tsx", "render_commands.md"]:
                self.assertTrue((remotion / rel).is_file(), rel)
            self.assertFalse((remotion / "sample-data").exists())
            info = json.loads((remotion / "src/data/build.json").read_text())
            self.assertTrue(info["demo"])
            self.assertTrue(info["sfx"])
            self.assertEqual(sorted(out["styles"]), ["archival-atlas", "cinematic-war-map", "modern-tactical", "satellite"])
            self.assertEqual(len(list((remotion / "public/presenter").glob("*.webp"))), 14)  # layered radio mascot is the default host
            self.assertEqual(info["presenter_mode"], "layered")
            self.assertFalse((remotion / "out").exists())  # the builder never renders

    def test_empty_shot_plan_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 2)
            self.assertEqual(out["status"], "PLAN_ONLY")

    def test_overlap_and_unclaimed_verified_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot("S-001", 0, 4), shot("S-002", 3, 6, "map_graphic", data_status="verified")])
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 2)
            joined = " ".join(out["errors"])
            self.assertIn("overlaps", joined)
            self.assertIn("no claim_ids", joined)

    def test_assets_need_registration_not_a_licence(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            (project / "assets/photo.jpg").write_bytes(b"not-a-real-image")
            self.write_plan(project, [shot("S-001", 0, 6, "archival_licensed", asset_ids=["A-001"])])
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 2)                       # not registered in the manifest
            self.assertIn("find_assets.py", " ".join(out["errors"]))
            manifest = {"assets": [{"asset_id": "A-001", "role": "archival", "file": "assets/photo.jpg", "license_status": "unchecked", "historical_evidence": True}]}
            (project / "assets/asset-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            done, out = run("build_remotion_project.py", "--project", str(project), "--force")
            self.assertEqual(done.returncode, 0, done.stderr)          # licence status never blocks
            self.assertEqual(out["assets_included"], ["A-001"])
            self.assertTrue((project / "remotion/public/assets/A-001.jpg").is_file())

    def test_own_icons_talk_audio_and_custom_sfx(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            (project / "assets/media").mkdir(parents=True)
            (project / "assets/media/I-1.png").write_bytes(b"png")
            manifest = {"assets": [{"asset_id": "I-1", "role": "icon", "file": "assets/media/I-1.png", "license_status": "unchecked", "historical_evidence": False}]}
            (project / "assets/asset-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            map_data = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [0, 0, 10, 10]}, "layers": [
                {"id": "L1", "type": "icon", "asset_id": "I-1", "framed": True, "coordinates": [3, 3], "claim_ids": [], "accuracy": "illustrative"}]}
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic"), shot("S-002", 6, 9, icon_asset_id="I-1")], duration=9)
            (project / "audio/narration.mp3").write_bytes(b"mp3")
            (project / "audio/music.mp3").write_bytes(b"mp3")
            (project / "audio/sfx").mkdir()
            (project / "audio/sfx/pop.wav").write_bytes(b"MINE")
            (project / "assets/presenter/talk").mkdir(parents=True)
            (project / "assets/presenter/talk/S-002.mp4").write_bytes(b"mp4")
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(out["assets_included"], ["I-1"])
            info = json.loads((project / "remotion/src/data/build.json").read_text(encoding="utf-8"))
            self.assertEqual(info["tracks"], {"voice": "audio/narration.mp3", "music": "audio/music.mp3"})
            self.assertEqual(info["talk"]["S-002"], {"file": "presenter/talk_S-002.mp4", "transparent": False, "audio": True})
            self.assertEqual((project / "remotion/public/sfx/pop.wav").read_bytes(), b"MINE")

    def test_wow_rule_counts_pictures_and_topic_elements(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot(f"S-{i:03d}", i * 5, i * 5 + 5) for i in range(8)], duration=40)
            done, out = run("build_remotion_project.py", "--project", str(project))
            joined = " ".join(out["quality_issues"])
            self.assertIn("wow rule", joined)
            self.assertIn("topic-specific", joined)

    def test_audio_is_picked_up_and_rebuild_needs_force(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot("S-001", 0, 6)])
            (project / "audio/original-score.wav").write_bytes(b"RIFF")
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(out["audio"], "audio/original-score.wav")
            self.assertEqual(out["unverified_shots"], ["S-001"])
            done, _ = run("build_remotion_project.py", "--project", str(project))
            self.assertNotEqual(done.returncode, 0)

    def test_presenter_generator_writes_three_variants(self):
        with tempfile.TemporaryDirectory() as tmp:
            done, out = run("make_presenter_assets.py", "--out", tmp, "--no-gif")
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(out["svg_poses"], 12)
            for folder in ("", "tactical", "archival"):
                self.assertEqual(len(list((Path(tmp) / folder).glob("*.svg"))), 12)

    def test_style_variant_sfx_switch_and_natural_earth(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            brief = json.loads((project / "production-brief.json").read_text(encoding="utf-8"))
            brief["visual_style"] = "modern-tactical"
            brief["presenter"]["enabled"] = True
            brief["presenter"]["character"] = "classic"
            brief["audio"]["sfx"] = False
            (project / "production-brief.json").write_text(json.dumps(brief, ensure_ascii=False), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic", style_id="modern-tactical")])
            map_data = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [24, 28, 34, 33]},
                        "basemap": {"land_geojson": "natural_earth", "modern_reference": False, "rivers": True, "lakes": True, "relief": True}, "layers": []}
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(out["presenter_variant"], "tactical")
            self.assertFalse(out["sfx"])
            remotion = project / "remotion"
            self.assertFalse((remotion / "public/sfx").exists())
            self.assertIn("#16222C", (remotion / "public/presenter/neutral.svg").read_text(encoding="utf-8"))
            basemap = json.loads((remotion / "src/data/basemap.json").read_text(encoding="utf-8"))["default"]
            self.assertGreater(len(basemap["features"]), 0)
            written = json.loads((remotion / "src/data/map-data.json").read_text(encoding="utf-8"))["maps"]["default"]
            self.assertTrue(written["basemap"]["modern_reference"])  # bundled coastlines are always flagged modern
            water = json.loads((remotion / "src/data/water.json").read_text(encoding="utf-8"))["default"]
            self.assertGreater(len(water["rivers"]["features"]), 0)  # the Nile
            self.assertEqual(out["maps"]["default"]["rivers"], len(water["rivers"]["features"]))
            info = json.loads((remotion / "src/data/build.json").read_text(encoding="utf-8"))
            if shutil.which("ffmpeg"):
                self.assertTrue((remotion / "public/relief_default.webp").is_file())
                west, south, east, north = written["render"]["relief"]["bbox"]
                self.assertTrue(west <= 24 and east >= 34 and south <= 28 and north >= 33)
            else:
                self.assertIsNone(written["render"]["relief"])
                self.assertIn("FFmpeg", " ".join(out["warnings"]))

    def test_bad_symbol_arrow_and_transition_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic", transition_in="star_wipe", atmosphere="moon")])
            map_data = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [0, 0, 10, 10]}, "layers": [
                {"id": "L1", "type": "unit", "symbol": "dragon", "coordinates": [1, 1], "claim_ids": [], "accuracy": "illustrative"},
                {"id": "L2", "type": "route", "arrow_style": "zigzag", "coordinates": [[1, 1], [2, 2]], "claim_ids": [], "accuracy": "illustrative"},
                {"id": "L3", "type": "icon", "icon": "unicorn", "coordinates": [3, 3], "claim_ids": [], "accuracy": "illustrative"}]}
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 2)
            joined = " ".join(out["errors"])
            for word in ("transition_in", "symbol", "arrow_style", "atmosphere", "icon must be"):
                self.assertIn(word, joined)

    def test_new_layers_second_map_and_country_lookup(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            layers = [
                {"id": "C1", "type": "country", "iso": "EGY", "color": "red", "claim_ids": [], "accuracy": "exact"},
                {"id": "A1", "type": "arc", "from": [31.2, 30.0], "to": [35.2, 31.8], "icon": "drone", "claim_ids": [], "accuracy": "illustrative"},
                {"id": "R1", "type": "range", "center": [31.2, 30.0], "radius_km": 300, "claim_ids": [], "accuracy": "illustrative"}]
            map_data = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [0, 0, 10, 10]}, "layers": [],
                        "maps": {"egypt": {"projection": {"type": "equirectangular", "bbox": [24, 21, 37, 32]}, "layers": layers}}}
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic", map_id="egypt", stat={"value": 300}, overlay_at_sec=1,
                                           camera={"path": [{"at_sec": 0, "focus": [30, 27], "scale": 1}, {"at_sec": 5, "focus": [31.2, 30], "scale": 2}]})])
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            written = json.loads((project / "remotion/src/data/map-data.json").read_text(encoding="utf-8"))["maps"]
            self.assertEqual(sorted(written), ["default", "egypt"])
            country = written["egypt"]["layers"][0]
            self.assertEqual(country["geometry"]["type"], "MultiPolygon")   # outline resolved from the bundled list
            self.assertEqual(country["name_ar"], "مصر")
            self.assertTrue(written["egypt"]["basemap"]["modern_reference"])  # modern borders are flagged
            self.assertEqual(out["maps"]["egypt"]["layers"], 3)
            # unknown map id, unknown country and incomplete arc / range stop the build
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic", map_id="mars")])
            done, out = run("build_remotion_project.py", "--project", str(project), "--force")
            self.assertEqual(done.returncode, 2)
            self.assertIn("map_id", " ".join(out["errors"]))
            map_data["maps"]["egypt"]["layers"] = [{"id": "A2", "type": "arc", "from": [31, 30], "claim_ids": [], "accuracy": "exact"},
                                                   {"id": "R2", "type": "range", "center": [31, 30], "claim_ids": [], "accuracy": "exact"}]
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic", map_id="egypt")])
            done, out = run("build_remotion_project.py", "--project", str(project), "--force")
            self.assertEqual(done.returncode, 2)
            joined = " ".join(out["errors"])
            for word in ("arc needs", "range needs"):
                self.assertIn(word, joined)
            map_data["maps"]["egypt"]["layers"] = [{"id": "C2", "type": "country", "iso": "ZZZ", "claim_ids": [], "accuracy": "exact"}]
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            done, out = run("build_remotion_project.py", "--project", str(project), "--force")
            self.assertEqual(done.returncode, 2)
            self.assertIn("not found", " ".join(out["errors"]))

    def test_map_quality_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            thin = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [24, 21, 37, 32]}, "layers": [
                {"id": "P1", "type": "pin", "coordinates": [31.2, 30.0], "claim_ids": [], "accuracy": "exact"}]}
            (project / "production/map-data.json").write_text(json.dumps(thin), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 20, "map_graphic")], duration=20)
            # reported, not blocking, without --strict
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(out["quality_gate"], "FAIL")
            joined = " ".join(out["quality_issues"])
            for word in ("no colour", "split it", "nothing new", "symbol"):
                self.assertIn(word, joined)
            self.assertIn("map quality rule", (project / "production/render_commands.md").read_text(encoding="utf-8"))
            # blocking with --strict
            done, out = run("build_remotion_project.py", "--project", str(project), "--force", "--strict")
            self.assertEqual(done.returncode, 2)
            self.assertEqual(out["quality_gate"], "FAIL")
            # a coloured, layered, moving map passes
            rich = dict(thin)
            rich["layers"] = [
                {"id": "C1", "type": "country", "iso": "EGY", "color": "red", "claim_ids": [], "accuracy": "exact", "reveal_start_sec": 0.2},
                {"id": "P1", "type": "pin", "coordinates": [31.2, 30.0], "claim_ids": [], "accuracy": "exact", "reveal_start_sec": 2.0},
                {"id": "I1", "type": "icon", "icon": "warehouse", "coordinates": [30.0, 29.0], "claim_ids": [], "accuracy": "illustrative", "reveal_start_sec": 4.0},
                {"id": "A1", "type": "arc", "from": [31.2, 30.0], "to": [35.0, 31.5], "claim_ids": [], "accuracy": "illustrative", "reveal_start_sec": 6.0}]
            (project / "production/map-data.json").write_text(json.dumps(rich), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 9, "map_graphic", camera={"path": [{"at_sec": 0, "focus": [30, 27], "scale": 1}, {"at_sec": 8, "focus": [31.2, 30], "scale": 1.8}]})], duration=9)
            done, out = run("build_remotion_project.py", "--project", str(project), "--force", "--strict")
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual((out["quality_gate"], out["quality_issues"]), ("PASS", []))

    def test_talk_clip_is_picked_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot("S-001", 0, 6)])
            (project / "assets/presenter/talk").mkdir(parents=True)
            (project / "assets/presenter/talk/S-001.webm").write_bytes(b"webm")
            (project / "assets/presenter/talk/S-999.webm").write_bytes(b"webm")   # no such shot: ignored
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            info = json.loads((project / "remotion/src/data/build.json").read_text(encoding="utf-8"))
            self.assertEqual(info["talk"], {"S-001": {"file": "presenter/talk_S-001.webm", "transparent": True, "audio": True}})
            self.assertTrue(info["presenter"])

    def test_flag_comes_from_the_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            (project / "assets/flag.png").write_bytes(b"png")
            manifest = {"assets": [{"asset_id": "A-FLAG", "role": "flag", "file": "assets/flag.png", "license_status": "unchecked", "historical_evidence": False}]}
            (project / "assets/asset-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            self.write_plan(project, [shot("S-001", 0, 6, "map_graphic")])
            map_data = {"data_status": "research_required", "projection": {"type": "equirectangular", "bbox": [0, 0, 10, 10]}, "layers": [
                {"id": "L1", "type": "unit", "symbol": "armor", "display": "card", "flag_asset_id": "A-FLAG", "coordinates": [1, 1], "claim_ids": [], "accuracy": "illustrative"}]}
            (project / "production/map-data.json").write_text(json.dumps(map_data), encoding="utf-8")
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertTrue((project / "remotion/public/assets/A-FLAG.png").is_file())

    def test_verified_stat_needs_claims(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = self.new_project(tmp)
            self.write_plan(project, [shot("S-001", 0, 6, stat={"value": 5}, data_status="verified")])
            done, out = run("build_remotion_project.py", "--project", str(project))
            self.assertEqual(done.returncode, 2)
            self.assertIn("statistic", " ".join(out["errors"]))


if __name__ == "__main__":
    unittest.main()
