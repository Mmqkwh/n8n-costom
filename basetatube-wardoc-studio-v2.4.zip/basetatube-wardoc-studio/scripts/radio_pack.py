#!/usr/bin/env python3
"""Read the radio presenter layers from assets/presenter-radio/radio-layers.pack. Standard library only.

The pack is a plain container (not a zip, because skill uploads reject nested zips):
first line = JSON index {"look/name.webp": [offset, length]}, then the file bytes back to back.

  python scripts/radio_pack.py --list
  python scripts/radio_pack.py --extract output/radio-layers        # all three looks as .webp files
"""
import argparse
import json
from pathlib import Path

PACK = Path(__file__).resolve().parents[1] / "assets" / "presenter-radio" / "radio-layers.pack"
LOOKS = ("wood", "tactical", "archival")


def read_index(pack=PACK):
    with open(pack, "rb") as f:
        index = json.loads(f.readline().decode("utf-8"))
        return index, f.tell()


def extract(dest, look=None, pack=PACK, flat=False):
    """Write the layers of one look (or all) into dest. flat=True drops the look folder."""
    index, start = read_index(pack)
    dest = Path(dest)
    written = []
    with open(pack, "rb") as f:
        for name, (offset, length) in index.items():
            if look and not name.startswith(look + "/"):
                continue
            target = dest / (Path(name).name if flat else name)
            target.parent.mkdir(parents=True, exist_ok=True)
            f.seek(start + offset)
            target.write_bytes(f.read(length))
            written.append(str(target))
    return written


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--list", action="store_true")
    p.add_argument("--extract", metavar="FOLDER")
    p.add_argument("--look", choices=LOOKS)
    a = p.parse_args()
    if a.extract:
        print(json.dumps({"status": "EXTRACTED", "files": len(extract(a.extract, a.look))}))
    else:
        print(json.dumps(sorted(read_index()[0]), indent=1))
