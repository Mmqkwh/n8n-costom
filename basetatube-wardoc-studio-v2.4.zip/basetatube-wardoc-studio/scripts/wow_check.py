#!/usr/bin/env python3
"""Wow check: is the rendered film lively and rich enough to deliver? Needs FFmpeg. Standard library only.

Three layers, all required before a film is called finished:

  measure   Reads the rendered video and measures every shot: how much the picture moves, how colourful
            and how detailed it is, and the longest stretch where almost nothing changes. Dead, flat or
            empty shots FAIL. Also saves frames of every shot (and of the reference video, if given) to
            <project>/qa/ for the next step, and writes a blank score sheet.
  verdict   Checks the score sheet you filled after LOOKING at those frames: five criteria per shot,
            0 to 10. Any criterion under 7, a film average under 8, or a film judged below the reference
            FAILS. Scores are your honest judgement; the file stays in the project for the owner to audit.

  python scripts/wow_check.py measure --project output/<slug> [--reference path/to/reference.mp4]
  python scripts/wow_check.py verdict --project output/<slug>

Numbers cannot prove a film is impressive. They catch what is clearly not: stillness, flatness, emptiness.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

W, H, FPS = 96, 54, 4
CRITERIA = ["composition", "readability", "detail", "motion", "style"]
MIN_CRITERION, MIN_FILM_AVERAGE, MIN_VS_REFERENCE = 7, 8.0, 7
# Floors per shot (calibrated on the skill's own renders; see BENCHMARK for a strong reference film).
LIMITS = {"motion": 1.0, "colour": 0.2, "detail": 1.5, "still_sec": 2.5}
STILL = 0.45           # a frame-to-frame change under this counts as "nothing happening"
FILM_STILL_LIMIT = 3.0
# Measured on a professional satellite-map explainer the owner chose as the target level (numbers only).
BENCHMARK = {"motion": 3.37, "colour": 0.63}
REFERENCE_SHARE = {"motion": 0.75, "colour": 0.7}   # the film must reach this share of the reference level


def read_frames(video):
    done = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(video), "-vf", f"fps={FPS},scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                          capture_output=True)
    size = W * H * 3
    if done.returncode != 0 or len(done.stdout) < size * 2:
        raise RuntimeError("FFmpeg could not read the video: " + done.stderr.decode(errors="ignore")[-200:])
    return [done.stdout[i:i + size] for i in range(0, len(done.stdout) - size + 1, size)]


def frame_stats(frame):
    """(colour, detail) of one small frame: mean saturation 0..1 and mean horizontal edge strength 0..100."""
    sat = edge = 0
    step = 3
    for i in range(0, len(frame) - 3, step * 2):          # every second pixel is plenty
        r, g, b = frame[i], frame[i + 1], frame[i + 2]
        mx = max(r, g, b)
        sat += (mx - min(r, g, b)) / mx if mx else 0
        edge += abs(r - frame[i + 3]) + abs(g - frame[i + 4]) + abs(b - frame[i + 5]) if i + 5 < len(frame) else 0
    n = len(range(0, len(frame) - 3, step * 2))
    return sat / n, edge / n / 7.65


def diff(a, b):
    """Mean change between two frames in percent of full scale."""
    return sum(abs(x - y) for x, y in zip(a[::4], b[::4])) / (len(a[::4]) * 2.55)


def measure_span(frames, diffs, start, end):
    i0, i1 = max(0, int(start * FPS)), min(len(frames), max(int(start * FPS) + 2, int(end * FPS)))
    part = frames[i0:i1]
    moves = diffs[i0:i1 - 1] or [0.0]
    stats = [frame_stats(f) for f in part[::2]] or [(0, 0)]
    # ignore the first half second (the transition in) when judging stillness
    run = longest = 0
    for d in moves[2:]:
        run = run + 1 if d < STILL else 0
        longest = max(longest, run)
    return {"motion": round(sum(moves) / len(moves), 3), "colour": round(sum(s[0] for s in stats) / len(stats), 3),
            "detail": round(sum(s[1] for s in stats) / len(stats), 2), "still_sec": round(longest / FPS, 2)}


def measure_video(video, shots=None):
    frames = read_frames(video)
    diffs = [diff(a, b) for a, b in zip(frames, frames[1:])]
    total = len(frames) / FPS
    if not shots:
        shots = [{"shot_id": f"T-{int(t):03d}", "start_sec": t, "end_sec": min(total, t + 4)} for t in range(0, int(total), 4)]
    out = []
    for shot in shots:
        m = measure_span(frames, diffs, float(shot["start_sec"]), float(shot["end_sec"]))
        problems = []
        if m["motion"] < LIMITS["motion"]:
            problems.append(f"almost nothing moves (motion {m['motion']}, need {LIMITS['motion']})")
        if m["colour"] < LIMITS["colour"]:
            problems.append(f"flat, colourless picture (colour {m['colour']}, need {LIMITS['colour']})")
        if m["detail"] < LIMITS["detail"]:
            problems.append(f"empty frame, too little on screen (detail {m['detail']}, need {LIMITS['detail']})")
        if m["still_sec"] > LIMITS["still_sec"]:
            problems.append(f"{m['still_sec']}s with a frozen picture (limit {LIMITS['still_sec']}s)")
        out.append({"shot_id": shot["shot_id"], "shot_type": shot.get("shot_type"), **m, "status": "FAIL" if problems else "PASS", "problems": problems})
    run = longest = 0
    for d in diffs:
        run = run + 1 if d < STILL else 0
        longest = max(longest, run)
    film = {"duration_sec": round(total, 1), "motion": round(sum(diffs) / len(diffs), 3),
            "colour": round(sum(s["colour"] for s in out) / len(out), 3), "detail": round(sum(s["detail"] for s in out) / len(out), 2),
            "longest_still_sec": round(longest / FPS, 2)}
    return film, out


def save_frames(video, shots, folder, prefix=""):
    folder.mkdir(parents=True, exist_ok=True)
    for old in folder.glob(f"{prefix}*.jpg"):
        old.unlink()
    files = []
    for shot in shots:
        st, en = float(shot["start_sec"]), float(shot["end_sec"])
        for tag, t in (("a", st + min(0.7, (en - st) * 0.2)), ("b", (st + en) / 2), ("c", en - min(0.5, (en - st) * 0.15))):
            target = folder / f"{prefix}{shot['shot_id']}_{tag}.jpg"
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1", "-vf", "scale=960:-2", "-q:v", "4", str(target)],
                           capture_output=True)
            if target.is_file():
                files.append(target.name)
    return files


def cmd_measure(args):
    project = Path(args.project)
    video = Path(args.video) if args.video else project / "remotion" / "out" / "documentary.mp4"
    if not video.is_file():
        return {"status": "PLAN_ONLY", "reason": f"no rendered video at {video}; render first"}
    plan_path = project / "production" / "shot-plan.json"
    shots = json.loads(plan_path.read_text(encoding="utf-8")).get("shots") if plan_path.is_file() else None
    film, per_shot = measure_video(video, shots)
    qa = project / "qa"
    frames = save_frames(video, shots or per_shot_windows(per_shot), qa / "frames")
    failed = [s for s in per_shot if s["status"] == "FAIL"]
    problems = [f"{s['shot_id']}: {p}" for s in failed for p in s["problems"]]
    if film["longest_still_sec"] > FILM_STILL_LIMIT:
        problems.append(f"film: {film['longest_still_sec']}s somewhere with a frozen picture (limit {FILM_STILL_LIMIT}s)")
    reference = None
    ref_path = Path(args.reference) if args.reference else next(iter(sorted((project / "reference").glob("*.mp4"))), None) if (project / "reference").is_dir() else None
    if ref_path and ref_path.is_file():
        ref_film, ref_shots = measure_video(ref_path)
        save_frames(ref_path, per_shot_windows(ref_shots)[:10], qa / "reference", "ref_")
        reference = {"file": str(ref_path), **ref_film}
    target = reference or ({"file": "built-in benchmark", **BENCHMARK} if BENCHMARK.get("motion") else None)
    if target:
        for key, share in REFERENCE_SHARE.items():
            if target.get(key) and film[key] < share * target[key]:
                problems.append(f"film: overall {key} {film[key]} is below {int(share * 100)}% of the reference level {target[key]}; add movement, colour and pictures across the film")
    sheet = qa / "scores.json"
    if not sheet.is_file() or args.reset_scores:
        sheet.write_text(json.dumps({"_how": "Look at qa/frames/<shot>_a|b|c.jpg (and qa/reference/ if present). Score each shot 0-10 honestly. Fix and re-render anything under 7, then score again.",
                                     "_criteria": {"composition": "balanced, intentional framing; nothing cut off or colliding", "readability": "all text clear, correct Arabic, good contrast",
                                                   "detail": "rich: colour, layers, symbols, pictures; not an empty frame", "motion": "the three frames differ in a meaningful way; things arrive, move, build",
                                                   "style": "one coherent look that fits the film; nothing looks pasted on"},
                                     "shots": {s["shot_id"]: {c: None for c in CRITERIA} | {"note": ""} for s in per_shot},
                                     "vs_reference": None, "weakest_shot_and_why": ""}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result = {"status": "PASS" if not problems else "FAIL", "film": film, "reference": target, "problems": problems, "shots": per_shot,
              "frames_folder": str(qa / "frames"), "frames": len(frames), "score_sheet": str(sheet),
              "next": "Look at the frames, fill qa/scores.json, then run: wow_check.py verdict" if not problems else "Fix the listed shots, re-render, and measure again."}
    (qa / "wow-measure.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def per_shot_windows(per_shot):
    return [{"shot_id": s["shot_id"], "start_sec": i * 4, "end_sec": i * 4 + 4} for i, s in enumerate(per_shot)] if per_shot and str(per_shot[0]["shot_id"]).startswith("T-") else per_shot


def cmd_verdict(args):
    project = Path(args.project)
    qa = project / "qa"
    problems = []
    measure = json.loads((qa / "wow-measure.json").read_text(encoding="utf-8")) if (qa / "wow-measure.json").is_file() else None
    if not measure:
        return {"status": "FAIL", "problems": ["run `wow_check.py measure` first"]}
    if measure["status"] != "PASS":
        problems.append("the measured check has not passed yet")
    video = project / "remotion" / "out" / "documentary.mp4"
    if video.is_file() and (qa / "wow-measure.json").stat().st_mtime < video.stat().st_mtime:
        problems.append("the video was rendered again after the last measure; measure and score the new render")
    sheet = json.loads((qa / "scores.json").read_text(encoding="utf-8")) if (qa / "scores.json").is_file() else {"shots": {}}
    values = []
    for shot in measure["shots"]:
        sid = shot["shot_id"]
        scores = (sheet.get("shots") or {}).get(sid) or {}
        for c in CRITERIA:
            v = scores.get(c)
            if not isinstance(v, (int, float)) or not 0 <= v <= 10:
                problems.append(f"{sid}: no score for {c}")
            else:
                values.append(v)
                if v < MIN_CRITERION:
                    problems.append(f"{sid}: {c} scored {v}; fix this shot (minimum {MIN_CRITERION})")
    average = round(sum(values) / len(values), 2) if values else 0
    if values and average < MIN_FILM_AVERAGE:
        problems.append(f"film average {average} is under {MIN_FILM_AVERAGE}; raise the weakest shots")
    if values and len(set(values)) == 1:
        problems.append("every score is identical; score each shot on its own merits")
    if measure.get("reference") and str(measure["reference"].get("file", "")) != "built-in benchmark":
        v = sheet.get("vs_reference")
        if not isinstance(v, (int, float)):
            problems.append("vs_reference is not scored (compare qa/frames with qa/reference)")
        elif v < MIN_VS_REFERENCE:
            problems.append(f"judged below the reference film ({v}); minimum {MIN_VS_REFERENCE}")
    if not str(sheet.get("weakest_shot_and_why") or "").strip():
        problems.append("name the weakest shot and why (weakest_shot_and_why); every film has one")
    result = {"status": "PASS" if not problems else "FAIL", "film_average": average, "problems": problems}
    (qa / "wow-verdict.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("measure")
    m.add_argument("--project", required=True)
    m.add_argument("--video", help="default: <project>/remotion/out/documentary.mp4")
    m.add_argument("--reference", help="a film at the level you are aiming for (default: first .mp4 in <project>/reference/)")
    m.add_argument("--reset-scores", action="store_true")
    v = sub.add_parser("verdict")
    v.add_argument("--project", required=True)
    args = ap.parse_args()
    if not shutil.which("ffmpeg"):
        print(json.dumps({"status": "PLAN_ONLY", "reason": "FFmpeg is needed"}))
        sys.exit(2)
    try:
        result = cmd_measure(args) if args.cmd == "measure" else cmd_verdict(args)
    except (RuntimeError, OSError, ValueError) as err:
        result = {"status": "FAIL", "problems": [str(err)]}
    slim = {k: v for k, v in result.items() if k != "shots"} | ({"failed_shots": [s["shot_id"] for s in result.get("shots", []) if s["status"] == "FAIL"]} if "shots" in result else {})
    print(json.dumps(slim, ensure_ascii=False, indent=2))
    if result["status"] != "PASS":
        sys.exit(2)


if __name__ == "__main__":
    main()
