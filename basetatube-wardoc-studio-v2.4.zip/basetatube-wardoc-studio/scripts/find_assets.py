#!/usr/bin/env python3
"""Find pictures and icons on the open web, download them, and register them in the project. Standard library only.

  search   look for pictures or icons about the topic. No key needed. Sources:
             openverse  open-licence pictures from many collections   commons  Wikimedia Commons
             nasa       NASA image library                            archive  Internet Archive
             iconify    open icon sets as SVG (use --source icons)
           Requests are retried with a growing pause; a source that stays down is skipped and reported
           in "source_errors", and the others still answer.
  add      download one picture / icon / clip by URL into the project and add it to assets/asset-manifest.json

The manifest keeps where each file came from (page, creator, licence when the source states it) so the
owner can credit or replace it later. Nothing here blocks on a licence: what to publish is the owner's call.

  python scripts/find_assets.py search "El Alamein 1942" --limit 8
  python scripts/find_assets.py search "tank" --source icons
  python scripts/find_assets.py add --project output/<slug> --url https://.../photo.jpg --id A-001 \\
         --role archival_photo --page https://.../File:Photo.jpg --creator "..." --license "CC BY-SA 4.0"
"""
import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

UA = {"User-Agent": "basetatube-wardoc-studio/2 (documentary asset finder)"}
EXT_BY_TYPE = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif", "image/svg+xml": ".svg",
               "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov"}
KNOWN_EXT = set(EXT_BY_TYPE.values()) | {".jpeg", ".m4v"}


RETRY_STATUS = {408, 425, 429, 500, 502, 503, 504}


def _get(url, timeout=30, tries=4, pause=1.5):
    """GET with retries. Slow first answers, gateway errors and rate limits are retried with a growing pause
    (1.5 s, 3 s, 6 s); a clear refusal (403, 404 ...) is not retried and is never worked around."""
    last = None
    for attempt in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                return r.read(), r.headers.get("Content-Type", "").split(";")[0].strip().lower()
        except urllib.error.HTTPError as err:
            last = err
            if err.code not in RETRY_STATUS:
                raise
            wait = err.headers.get("Retry-After") if err.headers else None
            delay = min(20.0, float(wait)) if wait and str(wait).isdigit() else pause * (2 ** attempt)
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as err:
            last = err
            delay = pause * (2 ** attempt)
        if attempt < tries - 1:
            time.sleep(delay)
    raise last


def _json(url, **kw):
    return json.loads(_get(url, **kw)[0].decode("utf-8"))


def _clean(text):
    return re.sub(r"<[^>]+>", "", str(text or "")).strip()[:200]


def search_openverse(query, limit=8):
    url = "https://api.openverse.org/v1/images/?" + urllib.parse.urlencode({"q": query, "page_size": limit})
    data = _json(url, timeout=40)   # the first answer for a new query can take ten seconds or more
    return [{"source": "openverse", "title": _clean(r.get("title")), "url": r.get("url"), "page": r.get("foreign_landing_url"),
             "creator": _clean(r.get("creator")), "license": " ".join(x for x in (str(r.get("license") or "").upper(), str(r.get("license_version") or "")) if x),
             "width": r.get("width"), "height": r.get("height")} for r in data.get("results", [])]


def search_commons(query, limit=8):
    params = {"action": "query", "generator": "search", "gsrsearch": query, "gsrnamespace": 6, "gsrlimit": limit, "prop": "imageinfo",
              "iiprop": "url|size|extmetadata", "iiurlwidth": 1920, "format": "json"}
    data = json.loads(_get("https://commons.wikimedia.org/w/api.php?" + urllib.parse.urlencode(params))[0].decode("utf-8"))
    out = []
    for page in sorted((data.get("query") or {}).get("pages", {}).values(), key=lambda p: p.get("index", 0)):
        info = (page.get("imageinfo") or [{}])[0]
        meta = info.get("extmetadata") or {}
        out.append({"source": "commons", "title": page.get("title", "").replace("File:", ""), "url": info.get("thumburl") or info.get("url"),
                    "page": info.get("descriptionurl"), "creator": _clean((meta.get("Artist") or {}).get("value")),
                    "license": _clean((meta.get("LicenseShortName") or {}).get("value")), "width": info.get("width"), "height": info.get("height")})
    return out


def search_nasa(query, limit=8):
    data = _json("https://images-api.nasa.gov/search?" + urllib.parse.urlencode({"q": query, "media_type": "image", "page_size": limit}))
    out = []
    for item in (data.get("collection") or {}).get("items", [])[:limit]:
        meta = (item.get("data") or [{}])[0]
        links = [l.get("href") for l in item.get("links", []) if l.get("href")]
        nid = meta.get("nasa_id", "")
        big = f"https://images-assets.nasa.gov/image/{urllib.parse.quote(nid)}/{urllib.parse.quote(nid)}~large.jpg" if nid else None
        out.append({"source": "nasa", "title": _clean(meta.get("title")), "url": big or (links[0] if links else None), "preview": links[0] if links else None,
                    "page": f"https://images.nasa.gov/details/{nid}" if nid else None, "creator": _clean(meta.get("center") or "NASA"), "license": "NASA media (generally public domain)"})
    return out


def search_archive(query, limit=8):
    params = [("q", f"({query}) AND mediatype:image"), ("fl[]", "identifier"), ("fl[]", "title"), ("fl[]", "creator"), ("fl[]", "licenseurl"), ("rows", limit), ("output", "json")]
    data = _json("https://archive.org/advancedsearch.php?" + urllib.parse.urlencode(params))
    out = []
    for doc in (data.get("response") or {}).get("docs", []):
        ident = doc.get("identifier")
        creator = doc.get("creator")
        out.append({"source": "archive", "title": _clean(doc.get("title")), "url": f"https://archive.org/services/img/{ident}", "page": f"https://archive.org/details/{ident}",
                    "creator": _clean(creator[0] if isinstance(creator, list) else creator), "license": _clean(doc.get("licenseurl")),
                    "note": "url is a small preview; open the page for the full-size file"})
    return out


def search_iconify(query, limit=8, color="#ffffff"):
    """Open icon sets (Tabler, Material, Game Icons ...) as SVG, tinted with `color`."""
    data = _json("https://api.iconify.design/search?" + urllib.parse.urlencode({"query": query, "limit": max(limit, 32)}))
    sets = data.get("collections") or {}
    out = []
    for name in (data.get("icons") or [])[:limit]:
        prefix, icon = name.split(":", 1)
        info = sets.get(prefix) or {}
        out.append({"source": "iconify", "title": name, "url": f"https://api.iconify.design/{prefix}/{icon}.svg?" + urllib.parse.urlencode({"height": 512, "color": color}),
                    "page": f"https://icon-sets.iconify.design/{prefix}/{icon}/", "creator": _clean((info.get("author") or {}).get("name") or info.get("name")),
                    "license": _clean((info.get("license") or {}).get("title"))})
    return out


SOURCES = {"openverse": search_openverse, "commons": search_commons, "nasa": search_nasa, "archive": search_archive, "iconify": search_iconify}
GROUPS = {"all": ["openverse", "commons", "nasa", "archive"], "photos": ["openverse", "commons", "nasa", "archive"], "icons": ["iconify", "openverse"]}


def search(query, source="all", limit=8):
    """Ask each source in turn; one being down or refusing never stops the others. Returns (results, errors)."""
    results, errors = [], []
    for name in GROUPS.get(source, [source]):
        try:
            results += SOURCES[name](query, limit)
        except Exception as err:
            code = getattr(err, "code", None)
            errors.append(f"{name}: {type(err).__name__}{' ' + str(code) if code else ''} after retries")
    return results, errors


def add(project, url, asset_id, role="picture", page=None, creator=None, license_name=None, credit=None, note=None):
    project = Path(project)
    manifest_path = project / "assets" / "asset-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.is_file() else {"assets": []}
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,40}", asset_id):
        raise ValueError("id must be letters, digits, - or _")
    data, ctype = _get(url, timeout=60)
    ext = Path(urllib.parse.urlparse(url).path).suffix.lower()   # the path only, so ?query parts do not confuse it
    if ext not in KNOWN_EXT:
        ext = EXT_BY_TYPE.get(ctype)
    if not ext:
        raise ValueError(f"not a picture or video file (content type {ctype or 'unknown'})")
    ext = ".jpg" if ext == ".jpeg" else ext
    target = project / "assets" / "media" / f"{asset_id}{ext}"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    entry = {"asset_id": asset_id, "role": role, "file": f"assets/media/{target.name}", "origin": url, "exact_item_url": page or url,
             "license_name": license_name, "attribution_text": credit or (f"{creator}" if creator else None),
             "license_status": "unchecked", "historical_evidence": role.startswith("archival"), "status": note}
    manifest["assets"] = [a for a in manifest.get("assets", []) if a.get("asset_id") != asset_id] + [entry]
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "ADDED", "asset_id": asset_id, "file": entry["file"], "bytes": len(data)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search", help="search Openverse and Wikimedia Commons")
    s.add_argument("query")
    s.add_argument("--source", choices=sorted(GROUPS) + sorted(SOURCES), default="all",
                   help="all / photos = openverse, commons, nasa, archive; icons = iconify, openverse; or one source by name")
    s.add_argument("--limit", type=int, default=8)
    a = sub.add_parser("add", help="download a file by URL and register it")
    a.add_argument("--project", required=True)
    a.add_argument("--url", required=True)
    a.add_argument("--id", required=True)
    a.add_argument("--role", default="picture", help="e.g. archival_photo, picture, icon, flag, video, ai_illustration")
    a.add_argument("--page")
    a.add_argument("--creator")
    a.add_argument("--license")
    a.add_argument("--credit", help="credit line shown on screen (optional)")
    args = ap.parse_args()
    try:
        if args.cmd == "search":
            results, errors = search(args.query, args.source, args.limit)
            print(json.dumps({"status": "FOUND" if results else "NOTHING_FOUND", "results": results, "source_errors": errors}, ensure_ascii=False, indent=1))
        else:
            print(json.dumps(add(args.project, args.url, args.id, args.role, args.page, args.creator, args.license, args.credit), ensure_ascii=False))
    except Exception as err:
        print(json.dumps({"status": "FAILED", "reason": f"{type(err).__name__}: {err}"}, ensure_ascii=False))
        sys.exit(2)


if __name__ == "__main__":
    main()
