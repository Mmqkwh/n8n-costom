#!/usr/bin/env python3
"""Run every offline self-test of the skill. Standard library only; no network, no npm, no paid calls."""
import sys
import unittest
from pathlib import Path

if __name__ == "__main__":
    here = Path(__file__).parent
    sys.path.insert(0, str(here))
    suite = unittest.defaultTestLoader.discover(str(here), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
