#!/usr/bin/env python3
"""Audio-only tests: offline, no network access, no paid tools required."""
import json
import subprocess
import sys
import tempfile
import unittest
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from make_music import synthesize, save_wav, parse_cues
from make_narration import generate, group_phrases, restore_punctuation, words_to_srt
from srt_to_captions import STYLES, convert, convert_words

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
WORDS = [
    {"text": "بدأ", "start_sec": 0.10, "end_sec": 0.45},
    {"text": "الهجوم", "start_sec": 0.47, "end_sec": 0.95},
    {"text": "مع", "start_sec": 0.97, "end_sec": 1.10},
    {"text": "شروق", "start_sec": 1.12, "end_sec": 1.50},
    {"text": "الشمس", "start_sec": 1.52, "end_sec": 2.00},
    {"text": "وتقدمت", "start_sec": 2.60, "end_sec": 3.10},
    {"text": "القوات", "start_sec": 3.12, "end_sec": 3.60},
]


def run(script, *args):
    return subprocess.run([sys.executable, str(SCRIPTS / script), *args], capture_output=True, text=True)


class AudioTests(unittest.TestCase):
    def test_procedural_track_is_real_pcm(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "bed.wav"
            samples, gain = synthesize(1.25, sr=24000, preset="suspense", seed=99)
            save_wav(output, samples, 24000, gain)
            with wave.open(str(output), "rb") as f:
                self.assertEqual(f.getnframes(), 30000)
                self.assertEqual(f.getnchannels(), 1)
                self.assertEqual(f.getsampwidth(), 2)
            self.assertGreater(output.stat().st_size, 1000)

    def test_synthesis_is_deterministic(self):
        a, ga = synthesize(0.25, sr=24000, seed=29)
        b, gb = synthesize(0.25, sr=24000, seed=29)
        self.assertEqual(a.tolist(), b.tolist())
        self.assertEqual(ga, gb)

    def test_cue_sheet_is_contiguous(self):
        duration, cues = parse_cues(ROOT / "templates/music-cues.example.json")
        self.assertEqual(duration, 60)
        self.assertEqual(len(cues), 3)

    def test_cue_sheet_scales_to_duration(self):
        duration, cues = parse_cues(ROOT / "templates/music-cues.example.json", scale_to=30)
        self.assertEqual(duration, 30)
        self.assertEqual(cues[0]["start"], 0)
        self.assertEqual(cues[0]["end"], 7)
        self.assertEqual(cues[-1]["end"], 30)

    def test_duration_conflict_with_cue_sheet_is_an_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "x.wav"
            done = run("make_music.py", "--cue-sheet", str(ROOT / "templates/music-cues.example.json"), "--duration", "5", "--output", str(out))
            self.assertNotEqual(done.returncode, 0)
            self.assertIn("conflicts", done.stderr)
            self.assertFalse(out.exists())

    def test_scale_cues_cli_renders_requested_length(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "x.wav"
            done = run("make_music.py", "--cue-sheet", str(ROOT / "templates/music-cues.example.json"), "--duration", "3", "--scale-cues",
                       "--sample-rate", "24000", "--output", str(out))
            self.assertEqual(done.returncode, 0, done.stderr)
            with wave.open(str(out), "rb") as f:
                self.assertEqual(f.getnframes(), 72000)

    def test_narration_dry_run_no_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "narration.txt"
            script.write_text("بدأ الهجوم مع شروق الشمس.", encoding="utf-8")
            result = generate(script, Path(tmp) / "voice.mp3", Path(tmp) / "voice.srt", dry_run=True)
            self.assertEqual(result["status"], "PLAN_ONLY")
            self.assertIn("ar-EG-ShakirNeural", result["command"])
            self.assertFalse((Path(tmp) / "voice.mp3").exists())

    def test_rate_is_one_token_so_edge_tts_accepts_it(self):
        # Regression: '--rate', '-8%' as two tokens is rejected by edge-tts and made narration always fail.
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "narration.txt"
            script.write_text("نص", encoding="utf-8")
            cmd = generate(script, Path(tmp) / "v.mp3", Path(tmp) / "v.srt", dry_run=True)["command"]
            self.assertIn("--rate=-8%", cmd)
            self.assertNotIn("--rate", cmd)
            self.assertNotIn("-8%", cmd)

    def test_bad_rate_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "narration.txt"
            script.write_text("نص", encoding="utf-8")
            self.assertEqual(generate(script, Path(tmp) / "v.mp3", Path(tmp) / "v.srt", rate="fast")["status"], "VOICE_NEEDED")

    def test_cli_help_and_rate_flag(self):
        self.assertEqual(run("make_narration.py", "--help").returncode, 0)
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "narration.txt"
            script.write_text("نص", encoding="utf-8")
            done = run("make_narration.py", "--text-file", str(script), "--output", str(Path(tmp) / "v.mp3"),
                       "--subtitles", str(Path(tmp) / "v.srt"), "--rate=+5%", "--dry-run")
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertIn("--rate=+5%", done.stdout)

    def test_every_script_help_works(self):
        for script in ["route.py", "new_project.py", "make_music.py", "mix_audio.py", "srt_to_captions.py",
                       "build_remotion_project.py", "make_presenter_assets.py", "make_sfx.py", "clip_basemap.py", "export_map_symbols.py", "style_check.py", "radio_pack.py", "fetch_basemap.py", "align_words.py", "key_video.py", "find_assets.py", "wow_check.py"]:
            with self.subTest(script=script):
                self.assertEqual(run(script, "--help").returncode, 0)

    def test_empty_text_fails_not_fake_voice(self):
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "empty.txt"
            script.write_text("  ", encoding="utf-8")
            self.assertEqual(generate(script, Path(tmp) / "voice.mp3", Path(tmp) / "voice.srt")["status"], "VOICE_NEEDED")

    def test_word_grouping_and_srt(self):
        words = restore_punctuation([dict(w) for w in WORDS], "بدأ الهجوم مع شروق الشمس، وتقدمت القوات.")
        self.assertEqual(words[4]["text"], "الشمس،")
        self.assertEqual(words[-1]["text"], "القوات.")
        groups = group_phrases(words, max_words=7)
        self.assertEqual([len(g) for g in groups], [5, 2])  # split at the 0.6 s pause
        srt = words_to_srt(words)
        self.assertIn("00:00:00,100 --> 00:00:02,000", srt)
        self.assertEqual(convert(srt, "bold-kinetic")["segments"][1]["text_ar"], "وتقدمت القوات.")

    def test_srt_to_caption_timing_preserves_arabic(self):
        srt = "1\n00:00:01,000 --> 00:00:02,500\nبدأ الهجوم مع شروق الشمس.\n\n2\n00:00:02,500 --> 00:00:04,000\nتقدمت القوات نحو العلمين.\n"
        result = convert(srt, "bold-kinetic")
        self.assertEqual(result["timing_status"], "actual_sentence_timestamps")
        self.assertEqual(result["segments"][0]["text_ar"], "بدأ الهجوم مع شروق الشمس.")
        self.assertEqual(result["segments"][1]["end_sec"], 4.0)

    def test_word_level_captions(self):
        result = convert_words({"words": WORDS}, "bold-kinetic", max_words=3)
        self.assertEqual(result["timing_status"], "actual_word_timestamps")
        self.assertEqual([len(s["words"]) for s in result["segments"]], [3, 2, 2])
        first = result["segments"][0]
        self.assertEqual(first["text_ar"], "بدأ الهجوم مع")
        self.assertEqual((first["start_sec"], first["end_sec"]), (0.10, 1.10))
        for seg in result["segments"]:
            self.assertEqual(seg["text_ar"], " ".join(w["text"] for w in seg["words"]))
        # an orphan single word joins the previous beat instead of standing alone
        orphan = convert_words({"words": WORDS[:5] + [{"text": "بس.", "start_sec": 2.02, "end_sec": 2.30}]}, "bold-kinetic", max_words=5)
        self.assertEqual([len(s["words"]) for s in orphan["segments"]], [6])
        with self.assertRaises(ValueError):
            convert_words({"words": []}, "bold-kinetic")

    def test_styles_come_from_library(self):
        self.assertEqual(STYLES, {"bold-kinetic": 5, "cinematic-minimal": 7, "infographic-arabic": 6})

    def test_mix_dry_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a.mp3", Path(tmp) / "b.wav"
            a.write_bytes(b"x"); b.write_bytes(b"x")
            done = run("mix_audio.py", "--voice", str(a), "--music", str(b), "--output", str(Path(tmp) / "m.m4a"), "--fit", "voice", "--dry-run")
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertIn("duration=first", done.stdout)
            self.assertEqual(json.loads(done.stdout)["status"], "PLAN_ONLY")


if __name__ == "__main__":
    unittest.main()
