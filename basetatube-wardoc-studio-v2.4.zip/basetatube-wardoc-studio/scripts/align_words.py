#!/usr/bin/env python3
"""Word timings for a narration file that came without them (recorded voice, ElevenLabs, any TTS). Needs FFmpeg.

It finds the pauses in the audio with FFmpeg, splits the script at its punctuation, pairs speech
stretches with phrases, and spreads the words of each phrase over its stretch by length.
Phrase starts therefore sit on real pauses; words inside a phrase are ESTIMATES. The result is
marked "estimated" and is good for captions and reveals, not for lip sync.

When a speech-to-text service with word timestamps is available (the HIGGS route has one), use that
instead: it is exact. This script is the offline fallback.

  python scripts/align_words.py --audio audio/narration.mp3 --text production/narration.txt --output audio/narration.words.json
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

SPLIT = re.compile(r"(?<=[.!?؟…،؛:])\s+|\n+")


def speech_spans(audio, noise_db=-32, min_silence=0.22):
    """[(start, end)] of speech between detected silences, and the total duration."""
    done = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(audio), "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}", "-f", "null", "-"],
                          capture_output=True, text=True)
    log = done.stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", log)
    if not m:
        raise RuntimeError("FFmpeg could not read the audio file")
    total = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", log)]
    ends = [float(x) for x in re.findall(r"silence_end: (-?[\d.]+)", log)]
    spans, cursor = [], 0.0
    for i, s0 in enumerate(starts):
        if s0 - cursor > 0.08:
            spans.append((max(0.0, cursor), s0))
        cursor = ends[i] if i < len(ends) else total
    if total - cursor > 0.08:
        spans.append((cursor, total))
    return spans or [(0.0, total)], total


def merge_to(spans, count):
    """Join the closest neighbours until there are `count` spans (pauses inside a phrase)."""
    spans = list(spans)
    while len(spans) > count:
        gaps = [spans[i + 1][0] - spans[i][1] for i in range(len(spans) - 1)]
        i = gaps.index(min(gaps))
        spans[i:i + 2] = [(spans[i][0], spans[i + 1][1])]
    return spans


def align(audio, text):
    phrases = [p.strip() for p in SPLIT.split(text.strip()) if p.strip()]
    if not phrases:
        raise ValueError("The script text is empty")
    spans, total = speech_spans(audio)
    if len(spans) >= len(phrases):
        spans = merge_to(spans, len(phrases))
        groups = [[p] for p in phrases]
    else:
        # fewer pauses than phrases: share the phrases out over the spans by length
        groups, weights = [[] for _ in spans], [e - s for s, e in spans]
        chars = sum(len(p) for p in phrases)
        acc, k = 0.0, 0
        for p in phrases:
            groups[k].append(p)
            acc += len(p) / chars * sum(weights)
            while k < len(spans) - 1 and acc >= sum(weights[:k + 1]) - 1e-6:
                k += 1
        groups = [g for g in groups]
    words = []
    for (start, end), group in zip(spans, groups):
        tokens = " ".join(group).split()
        if not tokens:
            continue
        weight = sum(len(t) + 1.5 for t in tokens)
        t = start
        for tok in tokens:
            d = (end - start) * (len(tok) + 1.5) / weight
            words.append({"text": tok, "start_sec": round(t, 3), "end_sec": round(t + d * 0.94, 3)})
            t += d
    return {"language": "ar-EG", "timing": "estimated", "method": "pauses_from_ffmpeg_then_spread_by_length", "duration_sec": round(total, 3), "words": words}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--text", required=True, help="Plain UTF-8 script exactly as spoken")
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    if not shutil.which("ffmpeg"):
        print(json.dumps({"status": "PLAN_ONLY", "reason": "FFmpeg is needed to find the pauses"}))
        sys.exit(2)
    try:
        result = align(a.audio, Path(a.text).read_text(encoding="utf-8"))
    except (RuntimeError, ValueError, OSError) as err:
        print(json.dumps({"status": "PLAN_ONLY", "reason": str(err)}, ensure_ascii=False))
        sys.exit(2)
    out = Path(a.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "ALIGNED", "file": str(out.resolve()), "words": len(result["words"]), "timing": "estimated"}))


if __name__ == "__main__":
    main()
