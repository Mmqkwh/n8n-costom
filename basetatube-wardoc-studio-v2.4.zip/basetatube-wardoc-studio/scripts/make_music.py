#!/usr/bin/env python3
"""Create an original ambient documentary music bed (WAV) using Python stdlib only.

No samples, soundfonts, copied melodies, model APIs, or third-party music assets.
The score is procedural, deterministic from --seed, and can be used offline.
"""
import argparse
import json
import math
import random
import struct
import wave
from array import array
from pathlib import Path

SCALES = {
    "suspense": [55.00, 65.41, 73.42, 82.41, 98.00],
    "advance": [73.42, 87.31, 98.00, 110.00, 130.81],
    "aftermath": [65.41, 77.78, 98.00, 116.54, 146.83],
}
DEFAULT_BPM = {"suspense": 68, "advance": 100, "aftermath": 58}


def create_section(n, sr, preset, intensity, seed, bpm=None):
    if preset not in SCALES:
        raise ValueError(f"Unknown preset: {preset}")
    if not (0 <= intensity <= 1):
        raise ValueError("intensity must be 0..1")
    rng = random.Random(seed)
    out = array("f", [0.0]) * n
    root, second, third, fourth, fifth = SCALES[preset]
    bpm = bpm or DEFAULT_BPM[preset]
    beat = 60.0 / bpm
    # A continuous cinematic pad, with slowly modulated partials. No imported audio.
    base = 0.10 + 0.08 * intensity
    lowpass_noise = 0.0
    step = 1.0 / sr
    for i in range(n):
        t = i * step
        swell = 0.70 + 0.30 * math.sin(2 * math.pi * 0.065 * t + 0.5)
        drone = (
            0.50 * math.sin(2 * math.pi * root * t)
            + 0.22 * math.sin(2 * math.pi * (root * 2.003) * t)
            + 0.17 * math.sin(2 * math.pi * third * t)
            + 0.11 * math.sin(2 * math.pi * (fifth / 2.0) * t)
        )
        # Slowly filtered ambient grain; deliberately quiet and not a sampled effect.
        noise = rng.uniform(-1, 1)
        lowpass_noise = 0.985 * lowpass_noise + 0.015 * noise
        airy = 0.016 * lowpass_noise * (0.75 + 0.25 * math.sin(t * 0.19))
        out[i] = base * swell * drone + airy
    # Original pitched pulses, procedural variation of a minor-mode collection.
    pulse_every = beat if preset == "advance" else (beat * 2.0 if preset == "suspense" else beat * 3.0)
    notes = [root * 2, third * 2, fifth, second * 2, fourth * 2]
    onset = 0.0
    hit = 0
    while onset < n / sr:
        note = notes[(hit * 2 + rng.randrange(2)) % len(notes)]
        count = min(int((0.42 if preset == "advance" else 0.72) * sr), n - int(onset * sr))
        start = int(onset * sr)
        for j in range(count):
            t = j / sr
            decay = math.exp(-5.5 * t)
            pluck = (math.sin(2 * math.pi * note * t) + 0.17 * math.sin(2 * math.pi * 2 * note * t)) * decay
            out[start + j] += (0.025 + 0.07 * intensity) * pluck
        if preset in ("advance", "suspense"):
            # Low thump, no percussive audio sample and no borrowed drum rhythm.
            count = min(int(0.22 * sr), n - start)
            for j in range(count):
                t = j / sr
                envelope = math.exp(-24 * t)
                kick = math.sin(2 * math.pi * (48.0 - 26.0 * min(1.0, t / 0.22)) * t) * envelope
                out[start + j] += (0.055 if preset == "advance" else 0.02) * intensity * kick
        onset += pulse_every
        hit += 1
    return out


def synthesize(duration, sr=32000, preset="suspense", intensity=0.65, seed=27, bpm=None, cues=None, impacts=True):
    n = round(sr * duration)
    if cues is None:
        cues = [{"start": 0, "end": duration, "preset": preset, "intensity": intensity}]
    track = array("f", [0.0]) * n
    for k, cue in enumerate(cues):
        st = float(cue["start"])
        en = float(cue["end"])
        if st < 0 or en > duration + 0.0001 or en <= st:
            raise ValueError(f"Invalid cue section: {cue}")
        # Extend each section 0.35s on both sides; crossfade overlapping layers.
        begin = max(0, round((st - (0.35 if k else 0)) * sr))
        finish = min(n, round((en + (0.35 if k < len(cues) - 1 else 0)) * sr))
        sample = create_section(finish - begin, sr, cue["preset"], float(cue.get("intensity", 0.65)), seed + 113 * k, bpm)
        fade = min(int(0.7 * sr), max(1, (finish - begin) // 2))
        for i, value in enumerate(sample):
            global_i = begin + i
            t = global_i / sr
            weight = 1.0
            if k > 0 and t < st + 0.35:
                weight *= max(0.0, min(1.0, (t - (st - 0.35)) / 0.70))
            if k < len(cues) - 1 and t > en - 0.35:
                weight *= max(0.0, min(1.0, ((en + 0.35) - t) / 0.70))
            track[global_i] += value * weight
    # Cinematic punctuation: a sub-bass impact where each section starts and a short riser leading into it.
    if impacts:
        rng = random.Random(seed + 7919)
        for k, cue in enumerate(cues):
            level = 0.16 + 0.22 * float(cue.get("intensity", 0.65))
            at = round(float(cue["start"]) * sr)
            length = min(int(1.6 * sr), n - at)
            for j in range(max(0, length)):
                t = j / sr
                boom = math.sin(2 * math.pi * (38 + 34 * math.exp(-t * 9)) * t) * math.exp(-t * 3.4)
                track[at + j] += level * (boom + rng.uniform(-1, 1) * math.exp(-t * 60) * 0.12)
            if k > 0:
                rise = int(1.8 * sr)
                begin = max(0, at - rise)
                lp = 0.0
                for j in range(at - begin):
                    u = j / max(1, at - begin)
                    lp += (0.03 + 0.25 * u * u) * (rng.uniform(-1, 1) - lp)
                    tone = math.sin(2 * math.pi * (70 + 260 * u * u) * (j / sr))
                    track[begin + j] += level * 0.55 * u * u * (lp + tone * 0.4)
    # Smooth start/end for single-section or cue-based compositions.
    fade_in = max(1, int(min(1.2, duration * 0.12) * sr))
    fade_out = max(1, int(min(1.5, duration * 0.14) * sr))
    for i in range(min(fade_in, n)):
        track[i] *= math.sin(0.5 * math.pi * i / fade_in) ** 2
    for i in range(min(fade_out, n)):
        ix = n - 1 - i
        track[ix] *= math.sin(0.5 * math.pi * i / fade_out) ** 2
    peak = max((abs(x) for x in track), default=0)
    gain = min(1.0, 0.86 / peak) if peak > 0 else 1.0
    return track, gain


def save_wav(path, samples, sr, gain):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(sr)
        # Keep PCM under -1.3 dBFS; all synthesis is deterministic and unclipped.
        buf = bytearray()
        for x in samples:
            buf.extend(struct.pack("<h", round(max(-0.86, min(0.86, x * gain)) * 32767)))
            if len(buf) >= 32768:
                f.writeframesraw(buf)
                buf.clear()
        if buf:
            f.writeframesraw(buf)


def parse_cues(path, scale_to=None):
    """Read a cue sheet. With scale_to, stretch/shrink all sections proportionally to that duration."""
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    secs = [dict(c) for c in doc["sections"]]
    if not secs:
        raise ValueError("Cue sheet sections cannot be empty")
    duration = float(doc["duration_seconds"])
    expected = 0.0
    for cue in secs:
        start, end = float(cue["start"]), float(cue["end"])
        if abs(start - expected) > 0.001 or end <= start:
            raise ValueError("Cue sections must cover the full duration in order with no gaps/overlaps")
        if cue["preset"] not in SCALES:
            raise ValueError(f"Unknown cue preset: {cue['preset']}")
        expected = end
    if abs(expected - duration) > 0.001:
        raise ValueError("Last section must end at duration_seconds")
    if scale_to is not None and abs(scale_to - duration) > 0.001:
        factor = float(scale_to) / duration
        for cue in secs:
            cue["start"] = round(float(cue["start"]) * factor, 4)
            cue["end"] = round(float(cue["end"]) * factor, 4)
        secs[-1]["end"] = float(scale_to)
        duration = float(scale_to)
    return duration, secs


def main():
    p = argparse.ArgumentParser(description="Original procedural ambient documentary soundtrack (no third-party samples)")
    p.add_argument("--output", required=True)
    p.add_argument("--duration", type=float, default=None, help="Seconds (default 30, or the cue sheet's own duration)")
    p.add_argument("--preset", choices=sorted(SCALES), default="suspense")
    p.add_argument("--intensity", type=float, default=0.65)
    p.add_argument("--bpm", type=int, default=None)
    p.add_argument("--seed", type=int, default=27)
    p.add_argument("--sample-rate", type=int, choices=[24000, 32000, 44100, 48000], default=32000)
    p.add_argument("--cue-sheet", help="Optional JSON sections aligned to storyboard")
    p.add_argument("--no-impacts", action="store_true", help="Leave out the sub-bass impacts and risers at section starts")
    p.add_argument("--scale-cues", action="store_true",
                   help="With --cue-sheet and --duration: stretch the cue sections proportionally to --duration (e.g. the real narration length)")
    args = p.parse_args()
    if args.duration is not None and not 0 < args.duration <= 900:
        p.error("duration must be >0 and <=900 s")
    if not 0 <= args.intensity <= 1:
        p.error("intensity must be 0..1")
    if args.bpm is not None and not 40 <= args.bpm <= 180:
        p.error("bpm must be 40..180")
    if args.scale_cues and not (args.cue_sheet and args.duration):
        p.error("--scale-cues needs both --cue-sheet and --duration")
    if args.cue_sheet:
        try:
            duration, cues = parse_cues(args.cue_sheet, args.duration if args.scale_cues else None)
        except (OSError, KeyError, ValueError) as err:
            p.error(f"Bad cue sheet: {err}")
        if args.duration is not None and not args.scale_cues and abs(args.duration - duration) > 0.001:
            p.error(f"--duration {args.duration:g} conflicts with the cue sheet duration {duration:g}. "
                    "Drop --duration, edit the cue sheet, or add --scale-cues.")
    else:
        duration, cues = (args.duration or 30.0), None
    samples, gain = synthesize(duration, args.sample_rate, args.preset, args.intensity, args.seed, args.bpm, cues, impacts=not args.no_impacts)
    save_wav(args.output, samples, args.sample_rate, gain)
    print(json.dumps({"status": "RENDERED", "file": str(Path(args.output).resolve()), "duration_seconds": duration, "sample_rate": args.sample_rate, "preset": args.preset if not cues else "cue-sheet", "original_procedural_music": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
