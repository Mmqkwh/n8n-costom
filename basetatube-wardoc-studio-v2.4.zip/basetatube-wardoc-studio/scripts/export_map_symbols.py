#!/usr/bin/env python3
"""Write the map symbols as standalone, editable SVG files. Standard library only.

Single source of truth: templates/remotion-starter/src/icons.json (the same shapes the video uses).
Default output: output/map-symbols/{units,events}/, or --out. The copies are not shipped inside the skill.
"""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ICONS = ROOT / "templates" / "remotion-starter" / "src" / "icons.json"
BUNDLED = Path("output") / "map-symbols"   # not shipped in the skill; written on request
COLORS = {"red": "#B94035", "blue": "#225B9D"}


def svg(group, name, body, view_box, color):
    _, _, w, h = view_box.split()
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{view_box}" width="{int(float(w)) * 4}" height="{int(float(h)) * 4}" '
            f'role="img" aria-label="{group[:-1]} symbol: {name}" color="{color}">{body}</svg>\n')


def export(out_dir=BUNDLED):
    out_dir = Path(out_dir)
    icons = json.loads(ICONS.read_text(encoding="utf-8"))
    written = []
    for group, spec in icons.items():
        if group.startswith("_"):   # sprite-sheet index, not SVG symbols
            continue
        for name, body in spec["items"].items():
            for side, color in COLORS.items():
                target = out_dir / group / f"{name}-{side}.svg"
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(svg(group, name, body, spec["viewBox"], color), encoding="utf-8")
                written.append(str(target.relative_to(out_dir)))
    return written


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--out", default=str(BUNDLED))
    a = p.parse_args()
    files = export(a.out)
    print(json.dumps({"status": "EXPORTED", "path": str(Path(a.out).resolve()), "files": len(files)}))
