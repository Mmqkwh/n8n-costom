#!/usr/bin/env python3
"""Deterministic FREE/HIGGS/BOTH router. Standard library only.

All keyword lists live in routing/mode-router.json (single source of truth).

Usage:
  python scripts/route.py 'معركة العلمين باستخدام هيجزفيلد MCP'
  python scripts/route.py --mode free 'معركة العلمين بدون هيجزفيلد'
  python scripts/route.py --mode both 'قارن النسختين'
"""
import argparse
import json
import re
import unicodedata
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parents[1] / "routing" / "mode-router.json"
CLAUSE_PUNCT = ".,;:!?()[]{}\n،؛؟"
AR_PREFIXES = ("و", "ف")
_CONFIG = None


def load_config():
    global _CONFIG
    if _CONFIG is None:
        _CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    return _CONFIG


def _normalize(s):
    s = unicodedata.normalize("NFKC", s).casefold()
    s = s.replace("\u2019", "'").replace("\u2018", "'")
    # Remove Arabic diacritics/tatweel and unify alef forms for robust matching.
    s = re.sub(r"[\u0640\u064b-\u065f\u0670]", "", s)
    s = re.sub(r"[أإآ]", "ا", s)
    return re.sub(r"[ \t\r\f\v]+", " ", s).strip()


def _norm_list(items):
    return [_normalize(x) for x in items]


def _is_arabic(word):
    return any("\u0600" <= ch <= "\u06ff" for ch in word)


def _find(term, text):
    """Yield (start, end) of term. Latin terms need Latin word boundaries; Arabic
    terms may carry an attached prefix (و، ب، ل ...), so only the end is bounded
    for single-word negations elsewhere, not here."""
    if _is_arabic(term):
        pattern = re.escape(term)
    else:
        pattern = r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])"
    for m in re.finditer(pattern, text):
        yield m.start(), m.end()


def _tokens(fragment):
    out = []
    for raw in fragment.split():
        tok = raw.strip(CLAUSE_PUNCT + "\"'«»-")
        if tok:
            out.append(tok)
    return out


def _strip_prefix(tok):
    if len(tok) > 2 and tok[0] in AR_PREFIXES:
        return tok[1:]
    return tok


def _contains_word(words, text):
    return any(True for w in words for _ in _find(w, text))


def _clause_before(text, pos, cfg):
    """Words of the same clause that precede position pos (nearest last)."""
    start = 0
    for i in range(pos - 1, -1, -1):
        if text[i] in CLAUSE_PUNCT:
            start = i + 1
            break
    toks = _tokens(text[start:pos])
    breaks = set(_norm_list(cfg["clause_break_words"]))
    for i in range(len(toks) - 1, -1, -1):
        if _strip_prefix(toks[i]) in breaks or toks[i] in breaks:
            toks = toks[i + 1:]
            break
    return toks[-int(cfg.get("negation_window_words", 5)):]


def _is_negated(text, pos, cfg):
    toks = _clause_before(text, pos, cfg)
    if not toks:
        return False
    words = set(_norm_list(cfg["negation_words"]))
    for tok in toks:
        bare = _strip_prefix(tok)
        if tok in words or bare in words:
            return True
        # Egyptian circumfix negation: ماتستخدمش / متستعملش ...
        if re.fullmatch(r"(ما|م)[\u0621-\u064a]{2,}ش", bare):
            return True
    joined = " ".join(toks)
    return any(p in joined for p in _norm_list(cfg["negation_phrases"]))


def _mentions(text, cfg):
    """Return list of (position, term, negated) for genuine Higgsfield mentions."""
    spans = []
    for name in _norm_list(cfg["higgs_names"]):
        spans.extend((s, e, name) for s, e in _find(name, text))
    friends = set(_norm_list(cfg["short_name_false_friends"]))
    for short in _norm_list(cfg["higgs_short_names"]):
        for s, e in _find(short, text):
            if any(s >= fs and e <= fe for fs, fe, _ in spans):
                continue  # part of a full name already counted
            if _is_arabic(short) and e < len(text) and "\u0621" <= text[e] <= "\u064a":
                continue  # a longer unrelated Arabic word
            around = _tokens(text[max(0, s - 40):s])[-3:] + _tokens(text[e:e + 40])[:3]
            if any(t in friends or _strip_prefix(t) in friends for t in around):
                continue  # Higgs boson / Peter Higgs, not the product
            spans.append((s, e, short))
    spans.sort()
    return [(s, term, _is_negated(text, s, cfg)) for s, e, term in spans]


def decide(text, mode="auto"):
    mode = (mode or "auto").strip().lower()
    if mode in ("free", "higgs", "both"):
        return {"mode": mode, "reason": "explicit structured mode", "paid_generation_allowed": mode in ("higgs", "both"), "needs_clarification": False}
    if mode != "auto":
        raise ValueError("mode must be one of auto|free|higgs|both")
    cfg = load_config()
    t = _normalize(text or "")
    found = _mentions(t, cfg)
    positive = [x for x in found if not x[2]]
    negative = [x for x in found if x[2]]
    base = {"paid_generation_allowed": False, "needs_clarification": False}
    if positive and negative:
        return {**base, "mode": "free", "needs_clarification": True,
                "reason": "conflicting Higgsfield mentions (one excluded, one requested); ask the user, stay free meanwhile"}
    if negative:
        return {**base, "mode": "free", "reason": "explicitly excluded Higgsfield"}
    if positive:
        compare = _contains_word(_norm_list(cfg["compare_words"]), t)
        free_word = _contains_word(_norm_list(cfg["free_identifiers"]), t)
        both_phrase = _contains_word(_norm_list(cfg["both_phrases"]), t)
        if both_phrase or (compare and free_word):
            return {**base, "mode": "both", "paid_generation_allowed": True, "reason": "explicit request to compare the free route with Higgsfield"}
        return {**base, "mode": "higgs", "paid_generation_allowed": True, "reason": "explicit Higgsfield mention"}
    return {**base, "mode": "free", "reason": "default free; no explicit Higgsfield"}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Choose the production route. Never generates and never charges.")
    p.add_argument("prompt", nargs="+", help="User prompt")
    p.add_argument("--mode", choices=["auto", "free", "higgs", "both"], default="auto")
    a = p.parse_args()
    print(json.dumps(decide(" ".join(a.prompt), a.mode), ensure_ascii=False, indent=2))
