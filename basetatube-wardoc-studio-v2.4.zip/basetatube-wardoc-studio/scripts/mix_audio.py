#!/usr/bin/env python3
"""Mix voice with a low-volume original music bed using FFmpeg, if available.

Provides a single deterministic invocation; verifies audio files actually exist.
Optional sidechain compression ducks the bed during spoken dialogue.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def mix(voice, bed, output, dry_run=False, fit="longest"):
    voice, bed, output = map(Path, (voice, bed, output))
    if not voice.is_file() or not bed.is_file():
        raise FileNotFoundError("Existing narration and music files are both required")
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg and not dry_run:
        return {"status": "READY_FOR_MIX", "reason": "FFmpeg not installed or not on PATH"}
    output.parent.mkdir(parents=True, exist_ok=True)
    # Voice foreground; bed at -17 dB, sidechain ducked under speech.
    span = "first" if fit == "voice" else "longest"
    filters = (
        "[1:a]volume=0.14[quietbed];"
        "[quietbed][0:a]sidechaincompress=threshold=0.05:ratio=8:attack=35:release=400[ducked];"
        f"[0:a][ducked]amix=inputs=2:duration={span}:normalize=0,"
        "alimiter=limit=0.89[out]"
    )
    cmd = [ffmpeg or "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
           "-i", str(voice), "-i", str(bed), "-filter_complex", filters,
           "-map", "[out]", "-c:a", "aac", "-b:a", "192k", str(output)]
    if dry_run:
        return {"status": "PLAN_ONLY", "command": cmd}
    completed = subprocess.run(cmd, text=True, capture_output=True, check=False)
    if completed.returncode != 0 or not output.exists():
        return {"status": "READY_FOR_MIX", "reason": "FFmpeg failed", "diagnostic": completed.stderr[-800:]}
    return {"status": "RENDERED", "file": str(output.resolve())}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--voice", required=True)
    p.add_argument("--music", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--fit", choices=["longest", "voice"], default="longest",
                   help="longest: keep the full music bed (default); voice: end the mix when narration ends")
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    try:
        result = mix(a.voice, a.music, a.output, a.dry_run, a.fit)
    except (FileNotFoundError, OSError) as err:
        result = {"status": "READY_FOR_MIX", "reason": str(err)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "READY_FOR_MIX":
        sys.exit(2)


if __name__ == "__main__":
    main()
