#!/usr/bin/env python3
"""Fetch a satellite basemap picture for one map area. Standard library + FFmpeg; needs network.

Downloads Web Mercator tiles for the bounding box (grown by a margin for camera moves), stitches
them with FFmpeg, and writes one JPEG plus the exact area it covers.

Providers (pick with --provider or map-data basemap.satellite):
  eox   Sentinel-2 cloudless 2016 by EOX, CC BY 4.0, detailed. DEFAULT.
  nasa  NASA Blue Marble with relief and bathymetry, public domain, coarse (good for whole regions).
  esri  Esri World Imagery, very detailed. Its use is governed by Esri's own terms; choosing it is the
        user's decision and responsibility. The required credit line is shown on screen.

The credit line of the provider is returned and must stay visible on every shot that uses the picture.
This is a MODERN picture of the earth: coastlines, cities, lakes and rivers are today's.

  python scripts/fetch_basemap.py --bbox 24 22 37 32 --out output/<slug>/assets/geo/satellite.jpg
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

PROVIDERS = {
    "eox": {"url": "https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless_3857/default/g/{z}/{y}/{x}.jpg", "max_zoom": 13,
            "credit": "Sentinel-2 cloudless 2016 by EOX (s2maps.eu), Copernicus Sentinel data, CC BY 4.0"},
    "nasa": {"url": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_ShadedRelief_Bathymetry/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpeg",
             "max_zoom": 8, "credit": "NASA Blue Marble / GIBS"},
    "esri": {"url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", "max_zoom": 15,
             "credit": "Esri, Maxar, Earthstar Geographics"},
}
MAX_LAT = 85.0
TILE = 256


def merc_y(lat):
    lat = max(-MAX_LAT, min(MAX_LAT, lat))
    return (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2


def inv_merc_y(v):
    return math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * v))))


def grow(bbox, margin):
    west, south, east, north = bbox
    if not (west < east and south < north):
        raise ValueError("bbox must be west south east north with west<east and south<north")
    dx, dy = (east - west) * margin, (north - south) * margin
    return (max(-179.9, west - dx), max(-MAX_LAT, south - dy), min(179.9, east + dx), min(MAX_LAT, north + dy))


def plan(bbox, width_px, provider, max_tiles=1100):
    """Choose the zoom level and tile range for the box."""
    west, south, east, north = bbox
    spec = PROVIDERS[provider]
    zoom = 1
    for z in range(1, spec["max_zoom"] + 1):
        zoom = z
        n = 2 ** z
        x0, x1 = int((west + 180) / 360 * n), int((east + 180) / 360 * n)
        y0, y1 = int(merc_y(north) * n), int(merc_y(south) * n)
        tiles = (x1 - x0 + 1) * (y1 - y0 + 1)
        if tiles > max_tiles:
            zoom = z - 1
            break
        if (east - west) / 360 * n * TILE >= width_px:
            break
    n = 2 ** zoom
    x0, x1 = int((west + 180) / 360 * n), min(n - 1, int((east + 180) / 360 * n))
    y0, y1 = int(merc_y(north) * n), min(n - 1, int(merc_y(south) * n))
    return {"zoom": zoom, "x0": x0, "x1": x1, "y0": y0, "y1": y1, "cols": x1 - x0 + 1, "rows": y1 - y0 + 1}


def fetch(bbox, out_path, provider="eox", width_px=4096, margin=0.35, grade=True, timeout=25, max_output=5600):
    """Returns {"file", "bbox": [west, south, east, north] actually covered, "credit", "zoom"} or raises RuntimeError."""
    if provider not in PROVIDERS:
        raise ValueError(f"provider must be one of {sorted(PROVIDERS)}")
    if not shutil.which("ffmpeg"):
        raise RuntimeError("FFmpeg is needed to stitch the tiles")
    box = grow(bbox, margin)
    # The stitched picture is capped (default 5600 px wide) so a 2 GB machine can still render it;
    # ask for no more tiles than that cap can show.
    width_px = min(width_px, int(max_output / (1 + 2 * margin)))
    p = plan(box, width_px, provider)
    spec = PROVIDERS[provider]
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        jobs = []
        for row in range(p["rows"]):
            for col in range(p["cols"]):
                url = spec["url"].format(z=p["zoom"], x=p["x0"] + col, y=p["y0"] + row)
                jobs.append((url, Path(tmp) / f"t_{row * p['cols'] + col:05d}.jpg"))

        def grab(job):
            url, dest = job
            for attempt in range(6):
                try:
                    req = urllib.request.Request(url, headers={"User-Agent": "basetatube-wardoc-studio"})
                    with urllib.request.urlopen(req, timeout=timeout) as r:
                        data = r.read()
                    if data[:2] == b"\xff\xd8" or data[:4] == b"\x89PNG":   # a plain sea tile can be only ~100 bytes
                        dest.write_bytes(data)
                        return True
                except Exception:
                    pass
                time.sleep(0.4 * (attempt + 1))   # be polite to the tile server and ride out rate limits
            return False

        with ThreadPoolExecutor(max_workers=5) as pool:
            ok = list(pool.map(grab, jobs))
        if not all(ok):
            raise RuntimeError(f"{ok.count(False)} of {len(ok)} tiles could not be downloaded from {provider}")
        # A mild grade so labels and arrows read well on top: slightly darker, a little more contrast.
        look = ",eq=brightness=-0.09:contrast=1.14:saturation=1.18" if grade else ""
        if p["cols"] * TILE > max_output:   # keep the picture a size browsers decode comfortably
            look += f",scale={max_output}:-2:flags=lanczos"
        done = subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-framerate", "1", "-i", str(Path(tmp) / "t_%05d.jpg"),
                               "-vf", f"tile={p['cols']}x{p['rows']}{look}", "-frames:v", "1", "-q:v", "4", str(out_path)],
                              capture_output=True, text=True)
        if done.returncode != 0 or not out_path.is_file():
            raise RuntimeError("FFmpeg could not stitch the tiles: " + done.stderr[-300:])
    n = 2 ** p["zoom"]
    covered = [p["x0"] / n * 360 - 180, inv_merc_y((p["y1"] + 1) / n), (p["x1"] + 1) / n * 360 - 180, inv_merc_y(p["y0"] / n)]
    return {"file": str(out_path), "bbox": [round(v, 6) for v in covered], "credit": spec["credit"], "zoom": p["zoom"],
            "pixels": [p["cols"] * TILE, p["rows"] * TILE], "provider": provider}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bbox", nargs=4, type=float, required=True, metavar=("WEST", "SOUTH", "EAST", "NORTH"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--provider", choices=sorted(PROVIDERS), default="eox")
    ap.add_argument("--width", type=int, default=4096, help="Target picture width in pixels before the margin")
    ap.add_argument("--margin", type=float, default=0.35)
    a = ap.parse_args()
    try:
        result = fetch(a.bbox, a.out, a.provider, a.width, a.margin)
    except (RuntimeError, ValueError) as err:
        print(json.dumps({"status": "PLAN_ONLY", "reason": str(err)}, ensure_ascii=False))
        sys.exit(2)
    print(json.dumps({"status": "FETCHED", **result}, ensure_ascii=False))


if __name__ == "__main__":
    main()
