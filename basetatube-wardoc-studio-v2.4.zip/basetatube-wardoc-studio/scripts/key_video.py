#!/usr/bin/env python3
"""Remove a flat green (or blue) background from a generated host clip. Needs FFmpeg.

Writes a .webm with an alpha channel (VP9) that the video project shows without a box.
Put the result in output/<slug>/assets/presenter/talk/<shot_id>.webm and rebuild.

  python scripts/key_video.py --input clip.mp4 --output output/<slug>/assets/presenter/talk/S-003.webm
  python scripts/key_video.py --input clip.mp4 --output out.webm --color 0x0B3B49 --similarity 0.14   # any flat colour
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def key(src, dest, color="0x00FF00", similarity=0.16, blend=0.06, despill=True, dry_run=False):
    src, dest = Path(src), Path(dest)
    if not src.is_file():
        raise FileNotFoundError(f"Input not found: {src}")
    ffmpeg = shutil.which("ffmpeg")
    chain = f"chromakey={color}:{similarity}:{blend}"
    if despill and color.lower() in ("0x00ff00", "green"):
        chain += ",despill=type=green"
    cmd = [ffmpeg or "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-vf", chain + ",format=yuva420p",
           "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", "30", "-an", str(dest)]
    if dry_run:
        return {"status": "PLAN_ONLY", "command": cmd}
    if not ffmpeg:
        return {"status": "PLAN_ONLY", "reason": "FFmpeg not installed or not on PATH"}
    dest.parent.mkdir(parents=True, exist_ok=True)
    done = subprocess.run(cmd, capture_output=True, text=True)
    if done.returncode != 0 or not dest.is_file():
        return {"status": "PLAN_ONLY", "reason": "FFmpeg failed", "diagnostic": done.stderr[-600:]}
    return {"status": "RENDERED", "file": str(dest.resolve()), "note": "Watch it once: hair and glove edges are where keying fails first."}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--color", default="0x00FF00", help="Background colour as 0xRRGGBB (default pure green)")
    ap.add_argument("--similarity", type=float, default=0.16)
    ap.add_argument("--blend", type=float, default=0.06)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    try:
        result = key(a.input, a.output, a.color, a.similarity, a.blend, dry_run=a.dry_run)
    except FileNotFoundError as err:
        result = {"status": "PLAN_ONLY", "reason": str(err)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "PLAN_ONLY" and not a.dry_run:
        sys.exit(2)


if __name__ == "__main__":
    main()
