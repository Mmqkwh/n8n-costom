# Prompt examples (not historical output)

**Free by default:**
> اعمل فيديو وثائقي مدته 60 ثانية عن معركة العلمين، بالخرائط السينمائية مع ترجمة عربية متحركة.

**Higgs MCP:**
> اعمل وثائقي عن معركة العلمين باستخدام هيجزفيلد MCP، استخدم WAN 3 Prime بدقة 720p للقطات السينمائية وGPT Image 2.6 للصور. وريني التكلفة قبل ما تبدأ أي توليد.

**Presenter GIF:**
> اعمل وثائقي عن الحروب مع شخصية افتراضية مجانية GIF بتشير على الخريطة بأوضاع مختلفة.

**Dual comparison:**
> قارن إنتاج نفس 30 ثانية بمسار Remotion المجاني وبمسار هيجزفيلد MCP، وخلّي الخرائط الدقيقة مشتركة في النسختين.

**No live research or Node:**
> اصنع الملفات المنظمة للمشروع وبيّن بوضوح أي بحث أو رندر غير متاح عندك، من غير ما تخترع مصادر أو فيديو.

**Explicitly without Higgsfield (routes to FREE):**
> اعمل الفيديو من غير ما تستخدم هيجزفيلد خالص، عايز النسخة المجانية.

**Test the video toolchain first (no research needed):**
> ابني المشروع التجريبي وطلّع لي الفيديو التجريبي عشان أتأكد إن الرندر شغال عندي.

**Choose a look:**
> اعمل الفيديو بستايل الأطلس الأرشيفي مع ترجمة إنفوجرافيك، وحط كارت إحصائية لعدد الأيام وخط الجبهة على الخريطة.

**Recent events, fast pace:**
> اعمل فيديو رأسي 60 ثانية عن آخر تطورات [الموضوع] بإيقاع سريع، كل عنصر على الخريطة يظهر مع الكلمة اللي بتتقال عنه، وفي الآخر كارت متابعة لقناة [اسم القناة]. استخدم مصادر رسمية ووكالات بس واكتب تاريخ آخر تحديث.

**Newspaper clipping:**
> اعرض مانشيت الجريدة يوم إعلان الهدنة بقالب الصفحة الأولى: العنوان والتاريخ من المصدر الموثّق، والصورة من الأصل المرخّص A-003 على اليمين، وحط خط أحمر تحت كلمة «الهدنة».

## What this version ships and what it does not

Ships: the full pipeline (router, scaffold, narration with word timing, music, mix, captions, Remotion project builder) and a fictional 33-second demo in all three styles that renders to MP4. Does not ship: any researched episode. A real film still needs sources, a cited map and cleared assets for each project.
