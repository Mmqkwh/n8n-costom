# Radio presenter (default host of the FREE route)

A living 1940s wooden radio, generated once for this skill (GPT Image 2.6, 2026-11-12) and bundled. Using it costs nothing at render time.

All layer files are inside `radio-layers.pack` (looks `wood/`, `tactical/`, `archival/`); the builder unpacks the look it needs. It is a plain pack file, not a zip, because skill uploads reject nested zips and more than 200 files. To get the pictures as ordinary files: `python scripts/radio_pack.py --extract output/radio-layers`.

It is layered, so any gesture combines with any eye and mouth state:

- `body_*.webp` (7): neutral, point_left, point_right, point_up, explaining, holding_paper, thinking
- `eyes_*.webp` (5 overlays; none = open, looking at the viewer): blink, left, right, up, wide
- `mouth_*.webp` (2 overlays; none = closed smile): mid, open

Three looks, picked from the brief's visual style: `wood/` (cinematic-war-map), `tactical/` (gunmetal with cyan dial), `archival/` (sepia). The two recolours are made in code from the same files, so every layer lines up exactly.

The video animates it by itself: three-state mouth on caption word timing, a blink about every three seconds, eyes following a pointing hand, pointing at the start of map shots, the note card on statistic / quote / clipping shots. A shot can force one of the 12 `presenter_pose` names; they map onto these layers.

Choose the host in `production-brief.json`: `"presenter": {"enabled": true, "character": "radio"}` (default) or `"character": "classic"` for the drawn SVG man.
