# Bundled reference geography

All files are from Natural Earth (naturalearthdata.com), which is in the public domain. Coordinates were rounded to 3 decimals and attributes removed to keep the skill small.

| File | Source layer | Notes |
|---|---|---|
| `ne_50m_land.geojson` | 1:50m Land | coastlines |
| `ne_50m_rivers.geojson` | 1:50m Rivers + lake centerlines | `rank` = Natural Earth scalerank |
| `ne_50m_lakes.geojson` | 1:50m Lakes | includes modern reservoirs |
| `ne_shaded_relief.webp` | 1:50m Shaded Relief (SR_50M), greyscale, 10800x5400 | covers longitude -180..180, latitude 90..-90, plate carree |

Everything here shows the MODERN world. Coastlines, river courses and especially lakes and reservoirs can differ from the period of a film (for example a reservoir built after the war). The video shows a "modern reference" notice whenever any of these is used. They are never evidence of historical borders or control.

For battle-scale maps the 1:50m detail is coarse. Download the 1:10m files from Natural Earth and pass them to `scripts/clip_basemap.py --source`.

`ne_50m_countries.geojson` is Natural Earth 1:50m Admin 0 (public domain) with `iso`, `name` and `name_ar` per country: modern de facto borders for `country` layers. On a satellite picture the builder downloads the 1:10m version once into `~/.cache/basetatube-wardoc/` so outlines sit cleanly on the coast, and falls back to this file when offline.

Satellite pictures are not bundled; `scripts/fetch_basemap.py` fetches them per map.
