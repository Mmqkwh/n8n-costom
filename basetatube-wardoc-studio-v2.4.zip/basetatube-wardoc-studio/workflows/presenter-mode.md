# Presenter / explainer host

**Character identity:** Only use a photo with user permission; do not infer a person from an unspecified file. If user provided no picture, offer procedural original 2D host for FREE or original AI host in HIGGS, clearly presented as synthetic.

## FREE: bundled host

The default host is the radio mascot in `assets/presenter-radio/radio-layers.pack` (layered body, eyes and mouth files in three looks: wood, tactical, archival; bundled, no cost; see the README beside it). Set `"presenter": {"character": "classic"}` in the brief for the drawn SVG man described below.

Design a simple scalable SVG bust/body with one canonical model sheet. The 12 poses are drawn by `scripts/make_presenter_assets.py` in three variants (cinematic, tactical, archival; the build draws the one matching the brief's visual style): neutral, speaking_closed, speaking_mid, speaking_open, pointing_left, pointing_right, pointing_up, explaining, thinking, holding_paper, surprised, blinking. The Remotion starter animates them from caption timing; force a pose on a shot with `presenter_pose` in the shot plan. For a custom host, put the same 12 file names (SVG or PNG) in `output/<slug>/assets/presenter/`. `python scripts/make_presenter_assets.py --out <folder>` regenerates the poses and an optional demo GIF without touching the skill folder. Use CSS/Remotion frame-based face/mouth/arm keyframes, 3–5 second loops. Export GIF via local FFmpeg/ImageMagick only when available; otherwise preserve reusable SVG assets and Remotion clips. All artwork original and editable; do not claim accurate lip sync without an actual audio timing model.

## HIGGS: the same radio host by default, or a photo-consistent presenter on request

The bundled radio host and the classic host work in the HIGGS route exactly as in FREE and cost nothing. In HIGGS you may also generate a new character or make the host really talk: voice line from `elevenlabs_v4` first, then `wan3_0_prime` / `wan3_0` or `minimax_h3_max` with the character picture as image reference and that line as audio reference, the Arabic line written in the prompt. The clip's own audio is used in its shots.

Prefer source photo + identity preserving generation. Require approved photo and live model's reference-image roles; keep face, clothing, age and build stable across shots. Generate clean plain green or transparent background for keying; maintain even illumination, no color spill, waist-up framing, no hair clipping. If native GIF available from preferred image model, make a uniform no-border frame loop with gestures. Inspect per-frame consistency. When compositing with map shots, put character outside strategic route lines, lower corner if needed.

## Result artifacts

All under `output/<slug>/assets/presenter/`: `presenter-identity.md` (explicit references/permissions), the 12 pose files, optional `presenter-spritesheet.png`, optional `presenter-loop.gif`, and `presenter-overlay.spec.json`. Mark absent media accurately.
