# Free audio production: Edge TTS narration + procedurally composed music

## Goals

- A voiced Arabic documentary with safe and readable timed subtitles **where the runtime permits Edge TTS**.
- An **original instrumental music track created with code only**, without stock samples or third-party paid models; this part runs offline using Python 3 standard library.
- Music should follow story beats and remain quieter than narration; never replace a factual source with narration synthesized by a model.

## Capability / rights gate before audio work

1. Detect Python, `edge-tts`, outbound speech-service access, FFmpeg and Remotion separately. An online chatbot's ability to write Python **does not prove outbound WebSocket access or local rendering**.
2. `edge-tts` is a **community/unofficial client** for Microsoft Edge online voices. It may break, be blocked, or have terms that need review. **Do not claim unrestricted commercial rights, uptime, universal browser support, or zero internet dependency.**
3. If allowed, use `ar-EG-ShakirNeural` as preferred narrator (or `ar-EG-SalmaNeural` on request), render genuine MP3 and SRT. Review pronunciation of names/dates and fix the spoken script before finalization.
4. If it is not available or is unsuitable for rights/commercial use, ask for a recorded voice track or a licensed accessible TTS alternative; provide script and captions marked `timing_status: estimated` when no audio is present. No invented MP3/SRT timings.
5. Original code-composed soundtrack can always be exported as WAV if Python and filesystem access exist. **Without code/file execution, export runnable scripts and status `READY_FOR_RENDER`, not a fictional WAV.**

## Narration command

```bash
python -m pip install edge-tts
python scripts/make_narration.py \
  --text-file output/el-alamein/production/narration.txt \
  --voice shakir \
  --output output/el-alamein/audio/narration.mp3 \
  --subtitles output/el-alamein/audio/narration.srt \
  --rate=-8%
```

This writes three real files: `narration.mp3`, `narration.srt` (phrases) and `narration.words.json` (word-level timestamps). Write the rate with `=` (`--rate=-8%`); a value that starts with `-` is otherwise read as a new option. On failure the JSON result carries a `diagnostic` field with the real cause.

- Egyptian male: `shakir` (`ar-EG-ShakirNeural`), Egyptian female: `salma` (`ar-EG-SalmaNeural`).
- Export human-verified plain UTF-8 narration text; don't pass Markdown headings or pronunciation guide as spoken text.
- Once the files exist, run `python scripts/srt_to_captions.py --words output/el-alamein/audio/narration.words.json --output output/el-alamein/production/captions.json --style bold-kinetic` for word-highlight captions. If only the SRT exists (CLI fallback), use `--input .../narration.srt` instead for phrase-level captions.
- Word timestamps come from the service's own word-boundary markers; review them against playback. They time captions; they are not lip sync.
- CLI dry run is always available without network: `python scripts/make_narration.py ... --dry-run`.

## Original music: fully offline

Three original procedural moods:

- `suspense`: atmospheric opening, slow drones and restrained pulses.
- `advance`: higher rhythmic energy for advancing arrows and key turns.
- `aftermath`: reflective, sparse closing without triumphal glorification.

```bash
python scripts/make_music.py --preset suspense --duration 30 \
  --seed 27 --output output/el-alamein/audio/music-suspense.wav

# Recommended: align story beats to music cues (three evolving moods).
python scripts/make_music.py \
  --cue-sheet output/el-alamein/production/music-cues.json \
  --output output/el-alamein/audio/original-score.wav

# Fit the same cue sheet to the real narration length (e.g. 73.5 s):
python scripts/make_music.py \
  --cue-sheet output/el-alamein/production/music-cues.json \
  --duration 73.5 --scale-cues \
  --output output/el-alamein/audio/original-score.wav
```

`--duration` together with `--cue-sheet` is an error unless `--scale-cues` is given, so a track never silently comes out at the wrong length.

The generator uses only standard Python libraries (no imported music samples); deterministic via `--seed`. Each exported track is an **original procedural instrumental bed**, not a clone of an existing score. Do not imply that all generated tunes in the universe are guaranteed dissimilar; review before release.

## Mix and compositing

```bash
python scripts/mix_audio.py \
  --voice output/el-alamein/audio/narration.mp3 \
  --music output/el-alamein/audio/original-score.wav \
  --output output/el-alamein/audio/documentary-mix.m4a
```

Add `--fit voice` to end the mix when the narration ends; the default keeps the full music bed.

- Requires FFmpeg; blends music below speech with dynamic sidechain ducking.
- `build_remotion_project.py` picks the audio track automatically, in this order: `audio/documentary-mix.m4a`, `audio/narration.mp3`, `audio/original-score.wav`. Rebuild with `--force` after making new audio.
- If TTS / mixing fails, **do not discard a successfully generated original music WAV**. Deliver each real output and report missing components honestly.

## Quality control

- Narration aligns with approved claim ledger and historical script; no unsupported additions.
- Validate first/last word, pacing, Egyptian proper-name pronunciation, incomplete sentences, odd pauses, clipping and silent regions.
- Verify music has a fade-in/out, does not mask speech, and matches the changing documentary moods; no copied themes/loops.
- Match music duration to shot timeline and verify the final mix. Keep pronunciation subtitles as text with correct RTL shaping.
