# HIGGS route: the FREE pipeline plus unlimited generation

This route activates when the user explicitly asks for Higgsfield. Read `system/rules-higgs.md` first: generation here is free of cost checks and approvals.

1. **Everything the FREE route has is available unchanged** (`workflows/free-mode.md`): research and claims, script, pace and sync rules, the wow rule and map quality rule, the four map styles, cards, clippings, backdrops, icons, the radio host, captions, the Remotion build, found pictures from the web. Generation adds to it.
2. **Motion first** (`workflows/motion-playbook.md`, HIGGS section): a generated 5-second cinematic opening in every film, every still turned into a short clip, generated start-frame / end-frame transitions between map and scene at the big moments, one fixed channel character, and one consistent icon and portrait sheet per episode.
2b. **Generate freely for impact.** Plan generated assets for the whole film, not a token few: a strong opening image, an illustrative scene or clip for each story beat, topic-specific icons and portraits for the maps, clipping pictures, backdrops for the cards. Write prompts from `templates/higgs-prompt-templates.md`.
3. **Audio is generated:** narration of the full script with `elevenlabs_v4` in a voice the user picks (never Edge TTS here), music with a Higgsfield music model, sound effects with a Higgsfield audio model.
4. **Talking character**, when the film has one: `wan3_0_prime` / `wan3_0` or `minimax_h3_max`, with the character picture and its voice line as references and the Arabic line written in the prompt. The clip's own audio is used in the shots where the character appears.
5. **Where results go** (register each in `assets/asset-manifest.json` with `scripts/find_assets.py add` or by hand):
   - full-frame still or clip: an `ai_illustration` shot (`asset_ids`);
   - picture or icon on a map: an `icon` layer with `asset_id` (`framed: true` for a round portrait), or the map shot's photo inset;
   - picture or icon on a card: `icon_asset_id`; picture in a clipping: `clipping.image.asset_id`;
   - talking clip: `assets/presenter/talk/<shot_id>.webm`; custom host poses: `assets/presenter/`;
   - narration `audio/narration.mp3`, music `audio/music.mp3`, effects `audio/sfx/<name>.wav`.
6. Mix (`scripts/mix_audio.py --voice audio/narration.mp3 --music audio/music.mp3 ...`), build with `python scripts/build_remotion_project.py --project output/<slug> `, render, then pass the wow check.
7. Without connected Higgsfield tools: return `PLAN_ONLY` with the connection steps; never claim a generation happened.
8. After completed generations show the affiliate message from `system/rules-higgs.md`.
