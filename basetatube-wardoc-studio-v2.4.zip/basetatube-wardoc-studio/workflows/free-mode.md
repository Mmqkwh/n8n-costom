# FREE route — zero-paid-services production

## Deliverable

A genuinely editable deterministic map documentary assembled in Remotion when a suitable local runtime is available. No remote image/video API, paid voice or charged credits. If the user's Remotion license category is ineligible, warn and either provide an eligible alternative or request they obtain the necessary license; don't call this a guaranteed free commercial license for every organization.

## Steps

1. **Historical research**: official primary/museum search → claim ledger + timeline → source-based locations; stop if research unavailable and mark `RESEARCH_REQUIRED`.
2. **Find pictures and icons (required)**: search for photographs, archive images, portraits, flags, equipment pictures and icons about this topic with `python scripts/find_assets.py search "..."` and the sites in `libraries/asset-sources.yaml`; download and register each with `find_assets.py add`. Aim well past the wow-rule minimum (3 pictures, one per 15 s). The manifest keeps the source of each file; it does not block anything.
3. **Map data** (read `libraries/map-elements.yaml` first): write `production/map-data.json` (see `schemas/map-data.schema.json`). For a professional look on real geography use the `satellite` style with `"basemap": {"satellite": "eox"}`; use one map per region under `maps` and give shots a `map_id`; fly the camera with `camera.path`; use `country`, `arc` and `range` layers for highlights, trajectories and distances; put `title_ar` / `stat` on the map shot to pop numbers over the map. Details: a bounding box, an optional basemap (`"land_geojson": "natural_earth"` cuts the bundled modern Natural Earth coastlines to the bbox; `scripts/clip_basemap.py --source` takes a finer file; `rivers`, `lakes` and `relief` switch on the bundled modern rivers, lakes and shaded relief), and layers of type `route` (with `arrow_style` main / secondary / flank / retreat), `front_line`, `zone`, `pin`, `unit` (`display` symbol / silhouette / card), `event`, `icon` (32 bundled 3D icons such as missile, warehouse, stopwatch), `label` (`kind: water` for sea names) in WGS84 `[longitude, latitude]`, each with its `claim_ids` and `accuracy`. Use period-correct, cited geometry only. Natural Earth reference geometry is modern; do not imply it was accurate for 1942 without historical corroboration.
4. **Editing**: do not write a Remotion project by hand. Run `python scripts/build_remotion_project.py --project output/<slug>`; it copies `templates/remotion-starter/` into `output/<slug>/remotion/` and feeds it the shot plan, map data, captions, cleared assets and audio. The starter renders each shot in the look of its `style_id` as fixed in `libraries/style-specs.yaml`: parchment war map, tactical HUD or archival desk, with the matching arrows, labels, date card, legend, compass, scale bar, transitions, grain and caption style. It also implements camera push/zoom, unit and event symbols, statistic / quote / title cards, Arabic newspaper clippings (`clipping` / `clippings`, five templates with editable masthead, dates, headline, body and picture slot; see `libraries/clipping-templates.yaml`), lower thirds, archival prints, generic backdrops (`atmosphere` on a shot), RTL word-highlight captions, sound effects and the presenter (see `libraries/motion-elements.yaml` for every field). Fonts, textures and symbols are bundled, so the render needs no network. Edit the generated components only when a shot needs something the starter lacks. The build fails closed on overlapping shots, `verified` shots without claims, and assets without a cleared license.
5. **Narration**: use Edge TTS online with Egyptian voice `ar-EG-ShakirNeural` (option `ar-EG-SalmaNeural`) *only* if the environment permits it and current terms permit intended use. Run `scripts/make_narration.py` to output real MP3, SRT and word-level `narration.words.json`; otherwise use the user's recording, or output `VOICE_NEEDED` plus real script and estimated caption timings. `edge-tts` is unofficial, network-dependent and may fail. Never fake a voice file. Read `workflows/free-audio.md`.
6. **Original music by code**: use `scripts/make_music.py` with `production/music-cues.json` (add `--duration <narration seconds> --scale-cues` to fit the real narration length), choosing the `suspense`, `advance`, or `aftermath` procedural moods for each beat. This is fully offline, zero-sample, no-paid-TTS music. Export a real WAV only after execution. Optionally mix narration and music with `scripts/mix_audio.py` (FFmpeg).
7. **Captions**: `python scripts/srt_to_captions.py --words audio/narration.words.json --output production/captions.json --style <style>` gives short beats with per-word timing for kinetic highlight; `--input audio/narration.srt` is the phrase-level fallback. Remotion renders them as real RTL text inside safe areas. Avoid text baked into AI images. Audio-first real timings preferred.
8. **Optional host**: set `presenter.enabled` in the brief or add a `presenter` shot; the build copies the 12 bundled SVG poses in the variant that matches the visual style (or your own from `assets/presenter/`) and the starter animates them with three mouth shapes. A standalone GIF comes from `scripts/make_presenter_assets.py` when CairoSVG and Pillow are installed. No paid external character generation in FREE.
9. **Render if capable**: check Node 18+, npm and network, then run the commands in `production/render_commands.md` (`npm install`, `npm run render`). Output is 1080p MP4 at the shot plan's fps in `remotion/out/documentary.mp4`; run QA on the real file, including `python scripts/style_check.py --video output/<slug>/remotion/out/documentary.mp4 --project output/<slug>`. On web runtime without necessary Node or sandbox, deliver code, manifest and setup/render commands; label `READY_FOR_RENDER`.

## Motion first

Follow `workflows/motion-playbook.md`: archive video as well as stills, parallax and cut-outs, the side-by-side / timeline / counter shots, relief maps for close zooms, bolder camera and captions, and the frame-by-frame self check.

## Pace, sync and channel identity

Maps must pass the **Map quality rule** in `system/rules-visual.md` (colour fills, constant change, mixed symbols); the build enforces this by itself.

Read the sections "Pace", "Sync" and "Channel identity" in `system/rules-narrative.md` before writing the shot plan: a visible change every 1.5 to 3 seconds, every map layer timed to the word that names it (from `audio/narration.words.json`), and the closing channel card built from `brief.channel`. For a film about recent events also read "Current affairs" in `system/rules-research.md`.

## Preferred techniques

- Map: GeoJSON, bundled Natural Earth 1:50m land (modern reference only; the video shows a notice), SVG; MapLibre optional for modern cartographic basemaps only when attributed per license.
- Found media: anything from the open web that fits the topic; source recorded in the manifest.
- Procedural presenter: original SVG illustrated host with 12 pose states in 3 style variants, finite loop. No paid cartoon image generator in FREE.
- Sound effects: `scripts/make_sfx.py` synthesises whoosh, hit, ping and typewriter in code; the build places them on transitions and date cards (switch off with `"audio": {"sfx": false}` in the brief).
- Music: original programmable synthesis by `scripts/make_music.py` is first choice, safe for offline demo and reproducible. Do not use existing music, loops or copyrighted soundfonts. Add CC0 SFX only after per-asset license verification. For narrated commercial releases verify Edge TTS service terms; otherwise use recorded narration.

## Output checks

- `shot-plan.json` links `claim_ids`, `asset_ids`, `style_id`, duration and camera keyframes.
- `asset-manifest.json` lists every found file with its source page.
- `production/render_commands.md` is the file written by `build_remotion_project.py`, with the exact commands for this project.
- `production/map-data.json` layers each carry `claim_ids` and `accuracy`; the on-screen notice appears on every shot that is not `verified`.
- The final video never silently presents modern map borders as historical.
