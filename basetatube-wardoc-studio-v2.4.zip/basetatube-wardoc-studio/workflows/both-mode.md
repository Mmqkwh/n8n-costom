# BOTH route — the same film in a FREE version and a HIGGS version

This route activates only when the user explicitly asks to compare the two routes (router result `both`) or sets `mode: both`. It is not a shortcut to paid generation: every HIGGS rule still applies to the paid half.

## Principle

One research base, one script, one shot plan, one map. The two versions differ only in the picture layer of the shots where generated imagery adds something.

## Steps

1. Do research, claims, script, `production/shot-plan.json`, `production/map-data.json`, narration, music and captions **once**, exactly as in `workflows/free-mode.md`.
2. Build and (if the runtime allows) render the FREE version first: `python scripts/build_remotion_project.py --project output/<slug>`. This version is complete on its own and costs nothing.
3. Decide which shots change in the HIGGS version. Good candidates: `ai_illustration` cutaways, atmospheric openers, the presenter. Never: `map_graphic` shots, date cards, captions. Those stay identical in both versions.
4. Copy the project folder to `output/<slug>-higgs/` and work on the paid version there, so neither version overwrites the other. In the copy, write `production/higgs-generation-queue.yaml` listing only the changed shots.
5. Run the HIGGS steps from `workflows/higgs-mode.md` on that queue: live model check, keyframes first, cost preflight, explicit approval, small batches. If the user declines the cost, stop here and deliver the FREE version with status `PLAN_ONLY` for the paid half.
6. Add each finished generation to `assets/asset-manifest.json` in the copy (`license_status: internal_original`, role `ai_illustration`), point the changed shots' `asset_ids` at them, and rebuild that copy with `--force`.
7. Deliver a comparison note `comparison.md` in the first folder: which shots differ, render status of each version, and what the viewer gains or loses. Report only what actually rendered.

## Checks

- Narration, music, captions, map layers and all `claim_ids` are identical in both versions.
- The FREE version contains no generated asset and triggered no paid call.
- Every AI shot in the HIGGS version carries the on-screen AI-illustration notice.
- Each version has its own QA report and its own status.
