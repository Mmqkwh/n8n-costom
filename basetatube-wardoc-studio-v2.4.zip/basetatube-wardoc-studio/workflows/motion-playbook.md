# Motion playbook: how to make the film impress

**The first priority in every route is impressive motion graphics.** This file is instructions for you, the model. Most items below are NOT ready-made in the starter: you carry them out yourself with the tools you have (FFmpeg, Python, the web, and edits to the generated video project). Where something already exists it says so.

## How to add what the starter lacks
1. Build first: `python scripts/build_remotion_project.py --project output/<slug>`.
2. Then edit the generated project in `output/<slug>/remotion/src/` (components are small React files; `MapShot.tsx`, `CardShot.tsx`, `MediaShot.tsx`, `Captions.tsx`, `Documentary.tsx`). Add fields to that project's `src/data/shot-plan.json` as you need them.
3. A later `--force` rebuild replaces `src/`. Keep every custom component and patch you write in `output/<slug>/production/custom/` and copy them back after a rebuild.
4. Never edit the skill's own `templates/` folder for one film.
5. Keep all motion frame-driven (`useCurrentFrame`, `interpolate`, `spring`) and seeded; no CSS animations, no random per render.
6. Render a still of each new shot (`npx remotion still ... --frame=N`) and look at it before the full render.

## For both routes

### Check your own work by eye (required before delivery)
After rendering, run `python scripts/wow_check.py measure --project output/<slug>`: it measures every shot and saves three frames of each in `qa/frames/`. Look at each one, score it in `qa/scores.json`, and run `wow_check.py verdict` (full rules in `system/rules-visual.md`, Wow check). Fix and re-render any shot where: the frame is nearly empty or a single flat colour; text overlaps text, the host or the caption bar; a label is cut off or unreadable; a picture is blurry, stretched or shows the wrong thing; nothing moved between the start and end of the shot; the map has no colour. Repeat until every shot passes. Write what you fixed in `qa-report.md`. A film that was not looked at is not delivered as finished.

### Episode templates
Pick the one that fits, then fill it. Shot lengths are guides; the pace and map quality rules still apply.

- **Battle** (60 to 90 s): hook picture + question (3 s) → where: wide map, camera flies in, countries coloured (8 s) → forces: two comparison cards or one side-by-side (8 s) → plan: map with units and arrows (10 s) → phase 1, phase 2, phase 3: one map shot each with a date card, broken up by an archive picture or clip (30 s) → turning point: quote or clipping (6 s) → outcome: map with the final line + statistic (8 s) → meaning + closing card (6 s).
- **Current crisis** (45 to 75 s): hook: the newest development over a satellite map (4 s) → who is involved: countries light up one by one (8 s) → timeline of the last days: animated timeline, 3 to 5 dated beats (12 s) → the key statement: quote card with source and date (6 s) → what it means on the map: ranges, arcs, routes that sources state (12 s) → what each side says: side-by-side (8 s) → what is unknown + as-of date + closing card (6 s).
- **Leader profile** (60 to 90 s): hook: portrait + the one line that defines them (4 s) → origins: map pin + date card + early picture (8 s) → rise: timeline with 3 beats (10 s) → the defining campaign: two or three map shots (25 s) → in their words: quote card (6 s) → downfall or legacy: clipping + statistic (10 s) → closing judgement stated as a view, with source (6 s).
- **Two armies compared** (45 to 75 s): hook: both flags or silhouettes face to face (3 s) → numbers: side-by-side counters, one category per beat: men, tanks, aircraft, ships (16 s) → geography: map with both countries coloured and distances (10 s) → strengths of each: icon rows (10 s) → a real clash or exercise as an example: map or picture (10 s) → the honest caveat: what numbers do not show (6 s) → closing card.

### Bolder camera
- **Shake on impact:** when an `explosion` icon, a `battle` event or a hit sound lands, shake the shot for 8 to 12 frames: translate by a decaying seeded offset of up to 0.6% of the frame. Never during readable text reveals.
- **Punch-in on the key word:** on the word a caption highlights, scale the shot 1.00 → 1.06 in 5 frames and ease back over 12. Exists already as slow moves through `camera.path`; the punch is yours to add as a wrapper around the shot.
- **Orbital opening:** open wide map shots with `camera.tilt_deg` 25 to 40 and a path that starts far (scale 1) and lands on the place (scale 1.8 to 2.4). `tilt_deg` and `camera.path` exist in the starter.
- **Whip between places:** for a jump between distant places, a 6-frame fast move with motion blur (`filter: blur`) at the midpoint.

### Stronger captions
- **One big word:** at the moment of emphasis (a number, a name, a verb), replace the caption line for 0.5 to 0.8 s with that single word at about 3 times the size, centred, with a spring pop. Add a field such as `"big": true` to that caption segment and handle it in `Captions.tsx`.
- **Icon beside the word:** show a bundled sprite (`Sprite` in `Icon.tsx`) or an emoji next to the highlighted word when one fits (missile, calendar, warning...).
- Keep whole words; never split Arabic letters. Keep captions inside the safe area and clear of the host.

## FREE route

### Archive video, not only pictures
Search for clips as well as stills: Internet Archive (`mediatype:movies`, newsreels), Wikimedia Commons (video files), NASA, and for recent topics DVIDS, Pexels and Pixabay video, official channels and agencies. Download with `python scripts/find_assets.py add --url <direct file url> --role archival_video`. Cut each clip to its shot with FFmpeg before registering (`ffmpeg -ss START -t LENGTH -i in.mp4 -an -vf scale=1920:-2 -c:v libx264 -crf 20 out.mp4`), choosing the most active seconds, then use it through `asset_ids` on an `archival_licensed` shot (the starter plays video muted). Aim for at least one moving clip per 20 seconds when the topic has footage.

### Depth inside still pictures (parallax)
For important photographs, separate the subject from the background and move them at different speeds:
1. Cut out the subject (see next item) to a transparent PNG.
2. Fill the hole in the background (`ffmpeg` with a blurred, slightly enlarged copy behind is enough for slow moves).
3. In the shot, scale the background 1.00 → 1.06 and the subject 1.00 → 1.12 with a small opposite drift, plus light grain.
When separation is not possible, at least pan and zoom toward the subject's face or the action, never a centred zoom.

### Cut-outs for the map
To put a person, weapon or vehicle on a map as its own element, remove the picture's background: use a background-removal library if you can install one (for example `rembg`), or key out a flat background with FFmpeg / Pillow, or pick pictures that already have plain backgrounds. Save as PNG with alpha, register it, and place it with an `icon` layer and `asset_id` (`"framed": true` gives a round portrait when a clean cut-out is not possible). Add a thin white outline and a soft shadow so it reads as a sticker on the map.

### New shot templates (build them in the project)
- **Side by side:** screen split in two with a diagonal or vertical divider, one side per party in its colour, each with a picture or silhouette, a name and one counter; counters run together; the larger value pulses at the end.
- **Animated timeline:** a line that draws across the screen, dated nodes popping in one by one on the narration, the current node enlarged with a one-line label, earlier nodes dimmed.
- **Counter:** a large number counting days, losses or distance with a small label and an icon, over a dimmed backdrop or over the map (over the map exists already: `stat` on a map shot).
Each one follows the film's visual style (fonts, colours, textures from `libraries/style-specs.yaml`).

### Stronger maps when zoomed in
A satellite picture of open desert or sea is flat and pale at close zoom. For close shots use a drawn style (`cinematic-war-map` or `modern-tactical`) with `"basemap": {"land_geojson": "natural_earth", "detail": "10m", "relief": true, "rivers": true}`: the shaded relief gives the terrain shape. Keep `satellite` for wide openings and coasts, cities and deltas where it has detail. Then fill the map as the map quality rule requires. For still more relief you may render your own hillshade from open elevation data and use it as the map's picture, lit from the upper left.

## HIGGS route
Everything above applies, and generation replaces the manual work where it is better.

1. **Generated cinematic opening (fixed rule):** every film opens with a generated 5-second cinematic shot that sets the place and mood, before the first map. Keyframe still first, then video. The hook line is narrated over it.
2. **No still stays still:** every still picture in the film, generated or archival, becomes a short clip (3 to 5 s) by image-to-video with the picture as the first frame: slow camera move plus natural motion in the scene (dust, smoke, flags, water, light). Archive photographs keep their content; only gentle motion is added, and the shot keeps its notice.
3. **Generated transitions between map and scene:** to go from a map to a live scene or back, generate a clip with a start frame and an end frame: start = a rendered still of the map at that place, end = the keyframe of the scene (or the reverse), camera diving in or pulling out. 2 to 3 seconds. Use it instead of a cut at the two or three biggest moments, not everywhere.
4. **One fixed character for the channel:** the host looks the same in every episode. Use one reference picture every time: the radio host (`python scripts/radio_pack.py --extract` gives `body_neutral`) or the user's own presenter. Save it as a persistent reference element when the tools offer that, and keep it as `assets/presenter/reference.png` in each project. Never redesign the character per episode.
5. **One icon and portrait sheet per episode:** generate the episode's own icons and portraits together, in one consistent style, as a single sheet on a transparent background (a grid with wide gaps), then cut it into cells and register each cell. One style across the film beats many mismatched single icons.
