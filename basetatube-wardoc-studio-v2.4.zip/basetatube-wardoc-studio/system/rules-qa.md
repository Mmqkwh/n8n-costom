# Mandatory quality gates (fail closed)

**Q1 Sources**: every consequential historical claim linked to direct evidence; no unverified statistic narrated as fact; unresolved conflict marked; source URLs accessible or listed as needs_manual_verification.

**Q2 Map**: verified place spelling, period-correct geography/control, source-backed routes/timing, explicit APPROXIMATE for uncertain positions, no fake georeferenced data.

**Q3 Assets**: every found or generated file is in `assets/asset-manifest.json` with where it came from (page / creator / licence when stated, or the generation job). Informational; nothing here blocks the build. Each picture shows what the narration says it shows.

**Q4 Arabic**: RTL ordering, shaping, no broken joining, contrast and safe-zone visibility, readable speed, synchronized timings if audio exists.

**Q5a Style**: each map shot's `style_id` matches the brief; `scripts/style_check.py` returns PASS on the rendered video (or the frame was compared with the style reference by eye and the result recorded). Live footage, photos or flags seen in a reference but absent from the free render are reported as a known limit, not hidden.

**Q5b Map quality**: the builder's `quality_gate` is PASS (colour on every map, something new at least every 3.5 s, three kinds of element with a symbol, no map shot over 12 s). A FAIL is a blocking issue, not a note.

**Q5 Motion & audio**: aspect, fps, duration and continuity; no frame clipping. For free output test original soundtrack file duration and envelope, no imported samples, original motifs only, voice intelligibility over music, proper Egyptian pronunciation, real SRT timestamp validity, and actual created files. Do not claim Edge TTS is an official commercial API. Audio QA is blocking when narration was promised; produce a music-only render or request voice if needed. No unlabelled synthetic archive.

**Q6 Route**: no paid calls in the FREE route. In HIGGS generation is unrestricted (no cost preflight or approval); narration is `elevenlabs_v4`, never Edge TTS; a talking clip uses its own audio. On tool absence use PLAN_ONLY and an actionable next step.

**Q6b Wow rule**: at least 3 pictures (one per 15 s) and 3 topic-specific elements in a film of 30 s or more; the builder's `quality_gate` covers it.

**Q6c Wow check (blocking)**: `wow_check.py measure` is PASS on the final render and `wow_check.py verdict` is PASS on honest scores of the frames (nothing under 7, average 8 or more, not below the reference). Without both, the status is `REVIEW_REQUIRED`, never `COMPLETED`.

**Q7 Deliverability**: files exist and parse, no pretend MP4. Status one of RESEARCH_REQUIRED | PLAN_ONLY | READY_FOR_RENDER | RENDERED | REVIEW_REQUIRED | GENERATION_PENDING | COMPLETED. `COMPLETED` requires validated deliverables actually present.

`qa-report.md`: provide pass/fail per gate, exact blocking issues, evidence checked, and next executable command. Never mark a pass based only on appearance of the reference style PNGs.
