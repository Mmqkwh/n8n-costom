# Historical research — mandatory before any script or graphic

## Source and citation protocol

Use live research only when actual web/search connectors are available. Start with primary archives and official museums relevant to the period; use specialist scholarship and peer-reviewed histories to evaluate bias and disputes. Official status is not automatic proof; a partisan wartime communique can be misleading. Aim for **two independent credible sources** for high-impact claims, but do not manufacture a second citation. Give each claim a stable `C-0001` identifier with `status: verified|contested|unverified`, direct URL(s), source title, publication/event date (when known), and quote/page/collection identifier. Capture retrieval date. Do not cite an entire archive's homepage for a fact unless the relevant fact is really on that page.

Always distinguish:
- **historical event time** (when the fact occurred), **archive item date**, and **page retrieval time**;
- period border/control boundaries vs contemporary national borders;
- confirmed event, plausible inference, disputed allegation, dramatization;
- a factual map datum vs an illustrative/generated artistic element.

## Research order

1. Normalize episode topic, period, geography, relevant commands/forces; ask one targeted question **only if work cannot proceed**; otherwise choose sensible defaults and label assumptions.
2. Query authoritative sources using proper nouns, local spellings and approximate dates. Use `libraries/sources.yaml` as a **directory of starting points**, not as pre-citations.
3. Extract chronology, people, place names, order of battle where substantiated, changes in control, logistics outcomes and civilian impact. Record which claims are supported and which are unverified/contested.
4. For every proposed map move: locate historical cartography/georeferenced material, cite it, and record start/end time and uncertainty. **Never** use AI-generated borders or arrows as evidence.
5. Pictures, icons and clips: search actively (`scripts/find_assets.py`, `libraries/asset-sources.yaml`), take what fits, and record page, creator and licence (when stated) in the manifest. This record never blocks use. Make sure a picture really shows the person, place or event it is used for.
6. Fill, under `research/`: `source-log.csv`, `claims.json`, `timeline.json`, `research-dossier.md`, and `research-open-questions.md` if evidence is incomplete.
7. Put `claim_ids` in storyboard shots and narrative segment metadata. Do not invent missing numbers, casualty counts, battle outcomes, dates, quotes, narration or URLs.

## Geographic integrity

- Natural Earth/OpenStreetMap commonly depict *modern* features. Mark modern reference geography when using it; obtain reconstructed period geography and claims before depicting control changes.
- Coordinate system WGS84/EPSG:4326 for GeoJSON unless explicitly converted, longitude/latitude order. Historical routes require verified waypoints and timestamps.
- For uncertain locations, show an approximate zone with uncertainty in captions, not false-precision pins.

## No browsing available?

Output a `RESEARCH_REQUIRED` brief, recommended primary source queries and the folders/templates only. Do not produce a plausible-sounding but unsourced battle history. User-provided authentic sources can be processed locally if available.

## Ethics and safety

Aim for historical education, never operational battlefield instruction, real-time targeting, active unit positions, or glorification. Label all generated war reenactments and composite archival montages. Respect civilians and avoid gratuitous violence.

## Current affairs (when `production-brief.json` has `"topic_kind": "current_affairs"`)

Everything above still applies. These rules are added because recent events change, are contested while they happen, and can hurt people if shown wrongly.

- **Sources.** Prefer the primary statement itself (official text, transcript, published order, court or UN document, the original post from the verified account), then two independent news agencies. An aggregator, a screenshot or an anonymous channel is never a source. Record for each source: publisher, exact URL, publication date and time with time zone, and retrieval time.
- **Status words.** Every claim gets one: `verified` (primary document or two independent agencies), `contested` (credible sources disagree; narrate both), `unverified` (one side says so). The narration must carry the attribution for anything not verified: "بحسب…", "أعلنت… ولم يتأكد ذلك من مصدر مستقل".
- **As-of date.** Write the cut-off in the dossier and show it on screen with `date_label_ar` on the first map or card ("حتى يوم …"). In the QA report, state that facts may have changed since then and list what to re-check before publishing.
- **Statement versus event.** "X said it will…" is a claim about a statement, not about the future. Never narrate a threat, plan or forecast as something that happened. Questions and analysis are allowed when worded as such.
- **Maps.** Draw only what a source states: a declared range, an announced route, a named city. Mark anything inferred as `accuracy: approximate` or `illustrative`. No live positions of units, bases, convoys or individuals, no targeting detail, no instructions; that limit in the ethics section is absolute here.
- **Numbers.** Casualty and damage figures: give the source and its date in the narration, prefer ranges when sources differ, and never average them.
- **People.** No private individuals. Public officials only in their public role, with exact quotes from the primary source or clearly marked paraphrase.
- **Tone.** No alarm for its own sake. If the honest answer to the film's question is "unknown", say so.
- **Before delivery.** Search once more for corrections or denials of each key claim published after your first pass, and update the claim status.
