# Arabic kinetic caption engine (RTL)

1. Source captions from **actual** voiceover transcript + timestamps when available; otherwise calculate estimated timings and label `unverified_timing`.
2. Sentence direction RTL; use correct Arabic shaping, bidirectional isolation for embedded numbers/English. Font fallback must cover Arabic glyphs. Never reverse the Arabic text string manually.
3. Aim 2–6 spoken words per visible beat, one or two lines maximum, no more than 1 emphasized word/phrase per beat except dramatic hooks. Keep punctuation and diacritics legible.
4. Visual choices: `bold-kinetic`, `cinematic-minimal`, `infographic-arabic` from `libraries/subtitle-styles.yaml`. Do not randomize style every sentence.
5. Animate lines/chunks, not isolated disconnected Arabic glyphs (joining breaks if each letter is separately animated). Typewriter effects need grapheme-aware segmentation with correct line shaping; never slice Unicode Arabic code points naively.
6. Sync keyframe emphasis to actual word timing where known; otherwise disclose approximate cues. Ensure captions are inside lower-third safe zone and never hide crucial strategic arrows.
7. Quality gate: Arabic spellcheck, punctuation, correct reading order, no clipped ligatures, no text collision; review one still per caption style and major scene.
8. Subtitle language and source audio language may differ; if asked for translation, mark it as translation and do not generate invented voice/dialogue.
