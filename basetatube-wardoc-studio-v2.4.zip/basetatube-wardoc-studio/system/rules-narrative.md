# Arabic documentary script & pacing

- Default `ar-EG` narration with historically appropriate proper-name spelling; use Modern Standard Arabic when user asks. Avoid slang that trivializes civilian loss.
- Opening frame starts immediately with a visual outcome or map move. No intro logos or long silence.
- Structure: HOOK (0–8s), SETUP, APPROACH, TURNING POINT, OUTCOME, CONSEQUENCE. Rebalance by requested length.
- Script cannot make factual claims unless each paragraph carries at least one verified/contested claim ID; nonfactual connective sentences are allowed. Mark disputed claims in narration where relevant.
- For historical figures/quotes, paraphrase instead of inventing dialogue. Label reenacted/synthetic clips clearly.
- All media including map moves must follow narrative chronology. Spoken dates must match the timeline.
- Prefer short lines for Arabic subtitles; avoid transliteration instructions being read out loud. Record pronunciation notes separately.
- Media mode and narrator voice cannot alter source facts. Higgsfield is not a replacement for research.
- Add `audio_notes` for narration, ambience and effects. If no audio tools exist, supply a recorded voiceover script; do not invent an audio file.

## Pace: something changes every 1.5 to 3 seconds (FREE and HIGGS)

Viewers leave when the picture stands still. Plan the shot list so a visible change lands every 1.5 to 3 seconds of narration. A change is any one of:

- a cut to the next shot (cards 2.5 to 4 s, media shots 3 to 5 s);
- a new map layer appearing (arrow, zone, pin, unit, event, label) inside a map shot;
- a statistic counting up, a date card, a lower third, a clipping dropping in;
- the camera arriving somewhere (`camera.path` keyframes, or `camera.focus` with `scale_end` above `scale_start`);
- a number or headline popping over the map (`stat` / `title_ar` on the map shot, timed with `overlay_at_sec`).

Rules:

- A map shot may run 6 to 12 s only if it carries at least one layer reveal per 2 to 3 s. A map shot with nothing new for 4 s must be split or shortened.
- Never hold a card longer than its text takes to read aloud plus one second.
- First 3 seconds: the strongest picture and the question the film answers. No logo, no greeting.
- One idea per shot. If the narration sentence has two facts, give it two reveals or two shots.
- Before building, read the shot plan top to bottom with the captions' timestamps and mark every gap longer than 3 s without a change; fix each one.
- Speed never overrides honesty: do not add a reveal that has no claim behind it just to fill a gap. Use a camera move, a card or a cut instead.

## Sync: each element appears on the word that names it (FREE and HIGGS)

The video already times every map layer. Use real word timestamps to set those times; do not guess.

1. Generate narration first, then `production/captions.json` from `audio/narration.words.json`. Each caption segment carries `words` with `start_sec` (seconds from the start of the film).
2. Set every shot's `start_sec` to the start of the first word spoken over it, minus 0.2 s, so cuts land just before the voice.
3. A `camera.path` keyframe's `at_sec` is also counted from the shot start: land the camera on a place 0.2 s before the word that names it.
3b. For each map layer, find the word that names it (the place, the unit, the verb of the move). Set the layer's `reveal_start_sec` to that word's `start_sec` minus the shot's `start_sec`, minus 0.15 s (never below 0). Set `reveal_end_sec` 0.5 to 0.9 s later for arrows and zones, 0.3 s later for pins, units and labels.
4. A timed layer must list exactly one shot in `shot_ids`; reveal times are measured from that shot's start.
5. Put `date_label_ar`, `stat`, `quote`, `lower_third` and `clipping` on the shot whose narration says them, and start that shot on the first word of the phrase.
6. Add `highlight_ar` to a caption segment for the one word that carries the fact (a number, a name, a verb).
7. Without real audio (`timing_status: estimated`), still follow steps 2 to 6 with the estimated times, and say in the QA report that sync must be redone after recording.
8. After any change to the narration text, regenerate audio and captions and redo these numbers; never reuse old timings.

## Channel identity (FREE and HIGGS)

When `production-brief.json` has a `channel` object, use the existing elements; nothing new is rendered:

- Closing shot: one `transition` shot of 3 to 4 s with `title_ar` set to `channel.cta_ar` and `lower_third` set to `{"name_ar": channel.name_ar, "role_ar": channel.handle}`. No historical claim on this shot; `data_status: illustrative`.
- Opening: never a logo card. If the user wants the name early, put the same `lower_third` on the first shot only.
- A fixed corner logo is not available in the starter; say so if asked rather than faking it with a label.
