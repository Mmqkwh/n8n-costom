# Visual direction & edit assembly

- Select one **primary map identity** per episode (`cinematic-war-map`, `modern-tactical`, `archival-atlas`) and one **editing identity** (`classic-documentary`, `kinetic-explainer`, `archival-collage`). Accent styles should complement, not scramble branding.
- The look of each style is fixed in `libraries/style-specs.yaml` and rendered by the Remotion starter; choose a style, do not improvise one. Use `assets/style-references/*.webp` solely as *style inspiration*. They may contain stylized/inaccurate geography or simulated labels; **never** use them as verified maps, exact military maneuvers, or archival photos.
- Map layers: validated base geometry → place labels → date and chapter header → verified markers/units → verified move arrows/controlled zones → legend and attribution → cinematic smoke/film treatment, separately editable.
- Transitions: route draw-on (0.6–1.4 s), camera push (1–3s), archive split/parallax (0.8–2s), callout pop (0.25–0.5s), or deliberate still hold. Avoid rapid motion on casualty/civilian imagery.
- Set `1920x1080`, `30fps` default; export at user's chosen ratio/resolution. Ensure chart, scale, map legend, and subtitles don't overlap. Maintain 7% safe edges.
- For facts/maps, generate text as vector layers with Arabic-safe shaping, not burned-in AI text. Maintain all figures/coordinates in structured data and preserve source IDs.
- Use stylized illustrative sequences from Higgsfield as intercuts only. Do not use generative edits to change authentic archival evidence.
- Choose visual details and duration shot-by-shot; avoid fake weapons movements and fake exact contemporary fronts.

## Map quality rule (mandatory, FREE and HIGGS)

A map that only shows a pin and a line is a failed shot. Every map shot must be coloured, layered and always changing. The builder checks this (`quality_gate` in its output); the build stops on a failing plan (use `--draft` only for a preview).

**1. Colour on every map.** Each map shot shows at least one coloured area: a `country` fill (the states involved, in the two side colours), a `zone` (held ground, minefield, contested area) or a `range`. A bare base picture with lines on it is not enough. Use red and blue consistently for the two sides through the whole film, `accent` for neutral highlights.

**2. Something new at least every 3.5 seconds, aim for 2.5.** Count the moments: a layer appearing, a camera keyframe arriving, a number or headline popping over the map. No stretch of a map shot may pass 3.5 s without one. Plan about one map element per 2.5 seconds of the shot.

**3. A mix of elements.** At least three different kinds per map shot, and at least one symbol (`unit` with silhouette or card, `event`, or a 3D `icon`). A good battle map layers: country or zone fills, the front line, main and secondary arrows or arcs, units of both sides, event or icon markers at the places named in the narration, place pins with labels, a legend.

**4. Motion detail everywhere.** Use what the video already animates: arrows that draw, arcs with travelling dashes and an icon riding the tip, range rings that grow, `emphasis` pins that pulse, `marching` borders, counters over the map (`stat`), a camera that travels (`camera.path`), date cards per phase.

**5. Limits.** A map shot runs 12 s at most; a card 7 s at most; a film of 30 s or more uses at least three kinds of shot and averages one shot every 4 to 6 seconds.

**6. Never at the cost of truth.** Every element still needs its claim or is marked `approximate` / `illustrative`. If the research cannot support enough elements, do more research, or enrich honestly with what is always true and available: colour the modern states involved (labelled as modern), name the seas and regions, pin the cities the narration mentions, show distances with a `range` or a `stat`, move the camera. Do not invent unit positions, arrows or numbers to satisfy this rule.

Before building, read the shot plan against this list; after building, fix every line in `quality_issues`.

## Wow rule (mandatory, FREE and HIGGS)

The aim of every film is to impress. Use the skill's bundle as a floor, not a ceiling, and bring in material made or found for THIS topic. You are free to design: choose styles per shot, combine elements, add pictures and icons from outside the skill.

Minimums for a film of 30 seconds or more (checked by the builder, blocking):
- **Pictures:** at least 3, and at least one per 15 seconds: photographs, archive images, clips, or generated illustrations. A film of maps and cards only fails.
- **Topic-specific elements:** at least 3: a newspaper clipping, a quote card, a statistic, or your own picture / icon placed on a map (a leader's portrait, the actual weapon, the real place).
- **Opening:** the first shot is the most striking picture or map move of the film.

FREE route: finding pictures and icons is a required task, not an option. Search with `python scripts/find_assets.py search "<topic words>"` (pictures) and `--source icons` (icons) and the sites in `libraries/asset-sources.yaml`, download and register with `find_assets.py add`, then place them: `asset_ids` on archival / media shots and map insets, `icon` layers with `asset_id` on maps, `icon_asset_id` on cards, `clipping.image.asset_id` in clippings, flags through `flag_asset_id`.

HIGGS route: generate what the search does not give, and anything else that raises impact.

Keep the source of every found file in the manifest (page, creator, licence when stated). These fields are information for the owner; they never block the build. What still holds: facts need sources, and a picture must show what the narration says it shows. Never present a picture of something else as the event.

## Wow check (mandatory gate before delivery, FREE and HIGGS)

A film is finished only when all three layers pass. None of them is optional and none can be replaced by a statement that the film "looks good".

1. **Plan gate (automatic).** `build_remotion_project.py` now stops on any map quality or wow rule problem by itself. `--draft` builds a preview that is never delivered.
2. **Measured check on the rendered video.** `python scripts/wow_check.py measure --project output/<slug>` measures every shot of the real video: movement, colour, how much is on screen, frozen stretches, and compares the film with the reference level (the built-in benchmark of a professional explainer, or the user's own film in `output/<slug>/reference/*.mp4` or `--reference`). A dead, flat, empty or frozen shot fails; a film well below the reference in movement or colour fails. Fix the listed shots, render again, measure again.
3. **Your verdict by eye, with scores.** The measure step saves three frames of every shot in `qa/frames/` (and reference frames in `qa/reference/`). LOOK at them. Score every shot from 0 to 10 in `qa/scores.json` on composition, readability, detail, motion and style; give `vs_reference` when a reference film exists; name the weakest shot and why. Then run `python scripts/wow_check.py verdict --project output/<slug>`. It fails when any score is under 7, the film average is under 8, the film is judged below the reference, a shot is unscored, every score is identical, or the video was rendered again after scoring.

How to score: be the critic, not the author. Compare with the reference frames side by side. If you hesitate between two scores, give the lower one and improve the shot. A 7 means "a viewer would not notice a weakness"; a 9 means "a viewer would pause to look". Scores are kept in the project so the owner can check them against the film.

When a shot fails, improve it for real: add colour fills, layers, pictures, camera movement, a stronger composition, or replace the shot. Do not add meaningless clutter and never invent facts to raise a score.

Status words: only a film with `qa/wow-verdict.json` = PASS may be called `COMPLETED`. Otherwise it is `REVIEW_REQUIRED`, with the failing items listed.
